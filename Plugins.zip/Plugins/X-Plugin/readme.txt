=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
  X-Plugin v1.0.1        for
  WinAmp 2.x, Winamp 3 Beta,
  Media Jukebox, and ModPlug
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=



This program is a Visualization-Plugin for WinAmp or ModPlug (or any
other program supporting plugins of that type) with the ability of
supporting user-definable Designs and animations as well as
Milkdrop presets.
It has been designed for Win95/98/2000 or later.

You are not allowed to change this file nor any of the files
delivered with the X-Plugin package.

This software is freeware. You may copy and redistribute this program as long
as all copyright notices remain intact and the files and product materials
delivered with this software package are not sold, disassembled,
reverse-engineered or modified in any way without the author's explicit
written permission.


If you are interrested in the Povray-3.1 scene source files I used to generate
the images for the Design "HiFi-X", please look on my website if they can be
downloaded from there or otherwise send me an e-mail.



Contents:
---------
  Installation
  System Requirements
  MAKING YOUR OWN DESIGNS FOR X-PLUGIN
  DISCLAIMER
  How To Contact The Author
  Donations
  Thanks to
  Some Notes
  Milkdrop Preset Notes
  Known Bugs
  HOW TO DELIVER YOUR DESIGN(S)
  History



Installation
============

Installation for Winamp 2.x:
----------------------------

X-Plugin comes along with an easy-to-use installer program (called PIMP-
installer which now is the default installer program for Winamp's
plugins).
Follow the steps of the installation procedure.
When finished, start Winamp.
Press Ctrl+K to open the dialog for selecting a visualization plugin.
Select the X-Plugin and press the Start- or Configure-button.

Installation for Winamp 3 Beta:
-------------------------------

Similar as for Winamp 2.x, but you will have to select the appropriate
destination directory (the one Winamp 3 Beta is installed on).
Then start Winamp 3 Beta, and in the Thinger (or in the popup-menu
by right-clicking on the Winamp window), select the "Classic
Visualization" Component. In there, you can select the X-Plugin
and start it.
It is recommended, to use the default Winamp 3 skin. With other skins,
there could possibly occur some problems or confusing behavior.
But I guess with most skins, it will work so far for the beta version
of Winamp 3.

Installation for ModPlug:
-------------------------

When you finished installation for Winamp, it is not necessary to install
it seperately for ModPlug. In that case it would be better to start
ModPlug and select the X-Plugin from the Winamp's plugins directory
where it should have been installed to.
X-Plugin will automatically detect, which music-player is running and
therefore will store different settings for each music-player,
one for Winamp and one for ModPlug.

Installation for Media Jukebox:
-------------------------------

First install X-Plugin to a directory of your choice, then start
Media Jukebox, and select the Plugin-Manager from the Settings.
In there, go to the visualizations and press the Add-Plugin button.
Go to the directory where you installed X-Plugin to and select
the "vis_xplg.dll".

Unfortunately I found out: Every time a new song is played in
Media Jukebox, the plugin is re-started. This is not a problem
of X-Plugin. It is a problem of Media Jukebox. I don't know why
the programmers did that.



System Requirements
===================

X-Plugin is designed for Win95/98/ME/2000 or later
with DirectX 8.0 or higher installed.



MAKING YOUR OWN DESIGNS FOR X-PLUGIN
====================================

At the moment, there exists no description on this because this
feature is not integrated completely and the definition on how
a design definition has to look like still is subject to change.

I intend to write a program which helps X-Plugin-design-developers to
make their own Designs for X-Plugin easily.
The first step on this is done already: The Designer Studio
included in the X-Plugin. It will have the function of both,
configuring the plugin for running as well as making and
managing own Designs.



DISCLAIMER
==========

  THE AUTHOR OF THIS SOFTWARE DISCLAIMS ALL WARRANTIES,
  EITHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED
  TO IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
  FOR A PARTICULAR PURPOSE, WITH RESPECT TO THE PRODUCT.
  AS WELL THE AUTHOR ACCEPTS NO RESPONSIBILITY FOR DAMAGES
  THAT ARE CAUSED BY THIS PROGRAM AND YOU, ITS USER, ASSUME
  THE ENTIRE RISK WHEN YOU USE IT.
  SHOULD THE PROGRAM PROVE DEFECTIVE, YOU, ITS USER,
  ASSUME THE RISK OF PAYING THE ENTIRE COST OF ALL
  NECESSARY SERVICING, REPAIR, OR CORRECTION AND ANY
  INCIDENTAL OR CONSEQUENTIAL DAMAGES.  IN NO EVENT THE
  AUTHOR WILL BE LIABLE FOR ANY DAMAGES WHATSOEVER
  (INCLUDING WITHOUT LIMITATION DAMAGES FOR LOSS OF
  BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS
  INFORMATION AND THE LIKE) ARISING OUT OF THE USE OR THE
  INABILITY TO USE THIS PRODUCT EVEN IF THE AUTHOR HAS BEEN
  ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

  Use of this product for any period of time constitutes
  your acceptance of this agreement and subjects you to its
  contents.



How To Contact The Author
=========================

Bug reports, improvements, ideas, suggestions, wishes or questions
please send to

Roman Komary
e-mail: thexagon@go.to

WebSite: http://go.to/thexagon


Copyright (c) 2002 Roman Komary



Donations
=========

Although X-Plugin is freeware I would be very thankful
for any kind of donations, because this would encourage me to
develop new versions of X-Plugin based upon your ideas.



Thanks to
=========

the programmers of WinAmp, ModPlug and Media Jukebox for writing such
wonderful tools for the ultimate sound experience.

Thanx to Ryan Geiss for making this wonderful Milkdrop plugin.

Thanx to Rovastar for allowing me to include his incredible
Milkdrop presets into the X-Plugin package.


Some Notes
==========

If you write your own Designs for X-Plugin, it would be nice of you
 to tell me about it and/or where I can download it (if possible)
 because I am interrested in how far X-Plugin will spread.
 But please, do *NOT* send me your design-package since my
 internet-account does not allow me to receive too large emails.
 The more poeple make Designs for X-Plugin, the more I will be
 encouraged to do new versions of X-Plugin.

How to write your own Designs for X-Plugin:
 Please excuse that I am not including a description for this in
 this X-Plugin package. At the moment it is not included because
 X-Plugin still is an early beta version and subject to changes.
 Therefore it is too early to write a detailed description on how
 to generate own Designs for X-Plugin.
 In addition, I intend to write a program which helps X-Plugin-design-
 developers to make their own Designs for X-Plugin easily.
 The first step on this is done already: The Designer Studio.
 But it does not have much funcionality at the moment.

If you want to offer your own design(s) to the public, you must read
 the section "HOW TO DELIVER YOUR DESIGN(S)" at the bottom of
 this file.



Milkdrop Preset Notes
=====================

Some features X-Plugin does not have (yet) included that Milkdrop have:
- Motion Vectors
- Hue Shader
- wave type 5
- drawing thick waveforms
- warp effect
- 3D stereo effect

Some features that work a bit different in X-Plugin
than in Milkdrop:
- Some wave types look slightly different in some special situations.
- waveform smoothing
- X-Plugin can access all the variables of a preset while Milkdrop
  only can handle some specific ones.
  E.g. you can also handle the gamma adjustment, inverting, etc.
  The names are exactly those as they listed in the milkdrop-preset-file
  (a *milk file) which is a simple textfile. So you can use e.g.
  "fGammaAdj" to access the gamma adjustment.
  Notice that there are for some parameters multiple variables of different
  name that access the same parameter. E.g.: "decay" and "fDecay" are
  the same parameter.
- bass, mid, treb, bass_att, mid_att, treb_att are somewhat differently
  calculated in X-Plugin. Some presets may act very different than in
  Milkdrop when they expect those variables to act exactly like in
  Milkdrop.

Some features that have been integrated into X-Plugin which are
not available in Milkdrop:
- Spectrum Analizer rendering
  This allows to draw spectrum analyzers. For all the supported
  variables, look in the preset "RKomary - Left Spectrum.milk"
  (which is a textfile) which comes along with the X-Plugin package.

Note:
Functionality outside the scope of a preset has mostly not been implemented
into X-Plugin. So there are no textual displays (like current song name etc.).

Also of course the keybindings of milkdrop are not used. Instead you have
a popup menu to each vis-animation (by right-clicking).
etc.



Known Bugs
==========

With 256 color screen resolution, X-Plugin will look like crap.
 This happens because I am not dealing with color palettes.
 Sorry about this. Maybe I will solve it in future.

Not all functionality of Milkdrop presets are supported.
 That's why some of them look very different on X-Plugin than
 they do on Milkdrop.



HOW TO DELIVER YOUR DESIGN(S):
============================

Please notice, that because X-Plugin still is an early beta version,
the following terms may change. At the moment they are not complete.

The following terms may be changed at any time by the author of
X-Plugin.

If you want ot offer your own design(s) for X-Pluginto the public, you
must accept and follow all of the following terms:

- You must include a "readme.txt" file for each design which must be
  included in your "*.xdn" file.
  You must include a readme.txt file for each design separately.

  In that readme you can write your text whatever you want, but with
  the following restrictions:

  > The readme must contain a note where X-Plugin can be
    retrieved (web-address).
  > and it must contain my name (the author of X-Plugin) and
    the email address and a copyright notice saying I (the author
    of X-Plugin) have copyright on X-Plugin.
  > you must not claim that X-Plugin is your creation.
    But you may include a copyright on your own design(s).

  Example:

        About X-Plugin:
        ---------------

          X-Plugin is written and copyright by
            Roman Komary
            thexagon@go.to
          You can find it at
            http://go.to/thexagon

          See "readme.txt" which should have been delivered with
          the X-Plugin package.

  The easiest way will be to take the example above and copy it
  into your design's readme(s).

  Of course you may include also other readme files in other locations
  if you want to, but you must not claim that X-Plugin is
  your product and you must not set your copyright on X-Plugin.

- In your design package, you must not include any of the files of the
  X-Plugin package, especially not the file "vis_xplg.dll".

- You are not allowed to include even one of my (the auther of X-Plugin)
  Designs in your design package. You also must not claim that one of my
  (the auther of X-Plugin) Designs is copyright on you.

- If you sell your design(s), no matter which form of payment this may
  include, you must not sell the X-Plugin package.
  Even any file contained in any version of a X-Plugin package may
  not be sold no matter if you bundle it together with other files or not.

  But you may sell your design(s) and all the necessary files for your
  design(s).

  As well you may be payed for the delivering and the transportation
  medium of a package.



History:
========

  v1.0.1
    Fixed a bug so that now the vis-animations work on all (hopefully)
    graphic cards. v1.0 did work only on nVidia cards.
    Thanx to Mr. Brian David Stevens for beta testing X-Plugin and
    supporting me with information about X-Plugin running on ATI cards.

  v1.0
    !! X-Plugin now does support Milkdrop (and own extended) presets and
    will display them in several screen areas.

    I hope that now all users will see X-Plugin in the list of available
    plugins (in winamp) because I changed the name from vis_xplg.dll to
    vis_xplugin.dll. I don't know why, but this seems to be the solution.

  v0.2.3
    The installer from v0.2.2 had an error. So I made a new installer.

  v0.2.2
    Just changed the DLL name internally in the hope, it can
    be installed now correctly.

  v0.2.1
    v0.2 did work only on Windows 2000 or Windows XP.
    This has been corrected now.

  v0.2
    Still a beta release.
    The engine I have made completely new. Also a first version of
    the Designer Studio is implemented.
    Besides the default Design "HiFi-X", also a wooden version is
    included.

  v0.1b
    The first release.
    It is still an early beta version and does not support many
    of the animations (especially 3D-animations) which I intend
    to implement for the first final release.
