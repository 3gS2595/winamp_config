The contents of this folder is completely optional to use.

The images are for the display of the example AJAX enabled requester page for your listeners.

The file "bpwjai.php" (BogProg WebJockey AJAX Interface) is a php script that acts as an intermediary between the client browser's AJAX object and the WebJockey control port.  It has a built-in security filter for password protection and to help to prevent hijacking although more might be required depending on your environment.  It process additional commands for authentication that are not present in WebJockey itself for security reasons.

The file "bpwebjockeyexample.php" is half php (for when JavaScript is not available), half AJAX and is an example of what is presented to your listeners/potential requesters.  It uses the file "bpwjai.php" for communication with the WebJockey port.  It also contains documentation for the WebJockey control commands.

The files "bpwjdjcp.html", "bpwjdjcp.css", "bpwjdjcp.js", "jsbn2.js", "jsbn.js", "prng4.js", "rng.js", "rsa2.js", and "rsa.js" are an example pure AJAX WebJockey DJ Control Panel system that also uses the "bpwjai.php" file for communication with the WebJockey port.  It allows extreme control over the WebJockey funtions and is probably going to be the place where you as the broadcasting Hostmaster/Webmaster/DJ will spend the most time in.




Have fun.