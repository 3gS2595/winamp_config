<?php $WebJockeyPort=62187; $WebJockeyIP="127.0.0.1";$NumPerPage=15;$errno=0;$errstr="";$WJTimeout=1.0;
error_reporting(0);
function getRealIpAddr()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
    {
      $ip=$_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
    {
      $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    else
    {
      $ip=$_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}
function formatTimeDisp($t,$ForceHour=false)
{
	$st=$t%60;
	$tmt=($t-$st)/60;
	$mt=$tmt%60;
	$ht=($tmt-$mt)/60;
	if($st<10){$st="0$st";}else{$st="$st";}
	if($ht>0 || $ForceHour)
	{
		if($mt<10){$mt="0$mt";}else{$mt="$mt";}
	}else{$mt="$mt";}
	if($ht>0 || $ForceHour){$t="$ht:$mt:$st";}else{$t="$mt:$st";}
	return $t;
}
if($NumPerPage<=0){$NumPerPage=0;}
function formatTimeDispE($t)
{
	$st=$t%60;
	$tmt=($t-$st)/60;
	$mt=$tmt%60;
	$ht=($tmt-$mt)/60;
	$t="";
	$p="";
	if($ht!=0)
	{
		if($t!=""){$t.=" ";}
		if($ht==1){$p="";}else{$p="s";}
		$t.="$ht hour$p";
	}
	if($mt!=0)
	{
		if($t!=""){$t.=" ";}
		if($mt==1){$p="";}else{$p="s";}
		$t.="$mt minute$p";
	}
	if($st!=0)
	{
		if($t!=""){$t.=" ";}
		if($st==1){$p="";}else{$p="s";}
		$t.="$st second$p";
	}
	return $t;
}
 ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
<meta name="robots" content="noindex">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<!--
BogProg WebJockey 1.6 Beta for Winamp

Note: This documentation is best viewed using a monospaced font style.


------------------- What is WebJockey? --------------------------

WebJockey is a Winamp plugin DLL that allows scripts on webpages
to present to your vistors your current playlist and allows them
to request entries (audio, video, or anything available in a
Winamp playlist) and que them.  The major feature of this plugin
is that it allows you to set limits and enforces those limits.
This gives everyone that visits your playlist a chance to request
the item they want within reason.


------------------- Intended users ------------------------------

This plug-in is for hostmasters/webmasters that want to allow
their vistors to make media requests from their Winamp playlists
and to allow the management and creation of an automated station
and manage it over the internet.

------------------- 2.2 Changes ---------------------------------

Added StopSets Program history commands.  SEVERELY upgraded
the DJ Conrol Panel along with updates for bpwjai.php to support
the upgrades.  To login you will need to include additional PHP
support modules that support encryption at the php language
level.  Even over an unsecure [HTTP] channel the password will be
asymmetrically encrypted.  It's not perfect but at least it's not
transmitting your password in complete plaintext.  Fixed issues
with Date/Time.

------------------- 2.1 Changes ---------------------------------

Added code for hopefull work-around on VLC's improper handling of
file names in the playlist files it generates.  Fixed a very rare
crash issue with skinned windows.

------------------- 2.0 Changes ---------------------------------

Removed Borland VCL framework.  Fixed a large number of
intermittent and random crash/hang issues.  Added ability to add
stop set files by folder path, which includes monitoring and
shuffling of media files in the folder automatically.  Added
function to allow metadata for stop set files marked with
"Advert:" to show through, thus allowing Radionomy monetization.
Added rudimentary playlist editor window with a number of
functions and features from the Winamp Playlist implemented.

------------------- 1.6 Beta Changes ----------------------------

Unicode support added.  Moved log files to subdirectory in user's
"My Documents" folder.

------------------- 1.5 Beta Changes ----------------------------

This version of WebJockey presents a radical change of design and
functionality that allow station automation.  All of the old
commands are still available and any webpages created or designed
around previous WebJockey versions will still function as
originally intended.  In addition to providing DJs and/or
hostmasters the ability to add to the active internal playlist,
they can also; browse the local filesystem; view recent requests;
view recently played; queue new playlists; skip a currently
playing song immediately; make DJ requests that override setting
limits and previous requests; view and manage request, stopset,
request, and playlist histories; change WebJockey settings; and
view file information and metadata.


------------------- 1.5 Alpha Changes (incomplete) --------------

This section of the documentation is incomplete.  This version of
WebJockey attempts to assist you in creating a web radio that is
automated!  The new "PagedList" command documentation is
incomplete.  This plugin takes over the playlist handling for
your radio.  It will only allow and keep 3 entries in the
playlist.


------------------- 1.4 Changes ---------------------------------

Added ability to temporarily deactivate WebJockey from the status
display window to allow for changes of the playlist during live
playback. (DO NOT LEAVE WEBJOCKEY DEACTIVATED)

Implemented delay of subclassing the Winamp main window for
compatibility with broken Wine environments. *#*#*#*#*#*#*#*#*#*#
#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#
#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#
#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#
#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#
PLEASE DO NOT USE THIS DELAY UNLESS YOU ARE EXPERIENCING PROBLEMS
WITH WEBJOCKEY (ie. WebJockey not keeping Shuffle, Repeat, and
Manual Playlist advance locked; entries not being shown/detected
as played; etc...) *#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#
#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#
#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#
#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#
#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#
#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#

------------------- 1.3 Changes ---------------------------------

Added an optional status display window.  It will show the
recently requested and played entries.  To display, open the
configuration and check the box for displaying it.

Added server logging.  The log files are silently stored in the
main install folder of Winamp. (eg. C:\Program Files\Winamp\)
When the log file size approaches the hardcoded value of 102400
bytes, WebJockey will automatically rotate the logs, indexed 001-
010

Fixed uninstall flaw where the main configuration file was not
being removed.

------------------- 1.2 Changes ---------------------------------

Added per client connection threading.

Added the ability to specify a single adapter IPv4 address to
bind.  Specifying 0.0.0.0 will bind to all adapters.
(Note: An incorrectly specified address will not generate an
error message from WebJockey.)

Bug fix for hangs during entry playback transition during a
request or refresh.


------------------- 1.1 Changes ---------------------------------

Added the option to sort the output of the "List" command so that
the currently playing entry is at the top of the list.  Option is
enabled by default and can be disabled from the configuration
page.

Added the automatic/silent disabling of manual playlist advances
and shuffling and the automatic/silent enabling of playlist
repeating.  Without these settings set correctly, WebJockey will
probably phail in epic proportions.  :>


------------------- Requirements --------------------------------

The WebJockey plug-in itself requires Winamp 5.61 or higher to
function properly.  The website server that the scripts run from
must be on the same computer OR the same Local Area Network that
Winamp runs on.  Your webpage scripts need to have the ability to
open TCP/IP ports to the computer that Winamp runs from.  DO NOT
forward or expose to your public internet address the port
WebJockey is configured to use to communicate with your webpage
scripts.  If you do, malicious visitors will be able to hog the
request que.


------------------- Operation -----------------------------------

Your webpage scripts communicate with WebJockey by opening a
TCP/IP connection to the port opened by WebJockey.  This port is
configurable by opening the configuration window from the Winamp
plug-in preferences window.  WebJockey defaults to port 62187.
All communication done with WebJockey is "call and response"
styled and, therefore, sessionless.  Your script sends a message
and Webjockey responds and closes the connection immediately.
Because WebJockey does not directly communicate with a visitor's
computer, the webpage scripts need to provide the IP address or
some such simmilar differentiating information that allows
WebJockey to track and manage requests per visitor.  WebJockey
uses internally randomly generated ID text strings to represent
entries on your playlist.  The IDs consist of only letter and
number sequences [0] through [9], [a] to [z], and [A] to [Z].
These generated IDs persist until Winamp is restarted or playlist
entries are removed/changed.  The usage of these unique IDs helps
to prevent misques on changing entry indices and prevents your
entry filenames from being broadcasted to every hacker on the
internet.  It also keeps POST and GET values from becoming
mangled and unusable versus playlist entry filenames or titles
which can potentially include strange characters that would need
additional processing by your scripts.  Limmiting factors for
vistors viewing your playlist are also configured from the
configuration window accessible from Winamp plug-in preferences
menu.  These factors are time (in seconds), maximum number of que
requests, and maximum numer of IP requests.  The time
configuration determines how long WebJockey remembers an entry
was recently played and the period of time used to limit
requests.  For example, if time is set to 3600 and Max Requests
Per IP is set to 3 (the defaults), that means that WebJockey will
limit visitors to 3 requests every hour progressively.  Total Max
Requests determines how many requests can be made by everyone
(total number of max queable requests.)  For example, if Total
Max Requests is 20 (the default), only 20 entries can be qued at
any one time and the current entry must finish before 1 more
request can be fullfilled.  This feature is usefull to keep your
playlist from being completely overrun with requests.  The
recommendation of this setting is 1 less than half the number of
entries in your playlist or less.  At the very least set it to 1
less than the length of your playlist.


------------------- Command convention --------------------------

All script communication with WebJockey is a simple format using
Windows style CR/LF delimited Ansi text commands and parameters.
WebJockey cannot recognize command strings in Unicode/MBCS.  When
a command string message is received, if recognized, it will
process it and return a similar CR/LF delimited Ansi text reply
indicating what was done with the command and (if any) additional
data.  All commands must end with a final extra CR/LF sequence to
indicate the end of the command string.  If commands are not
terminated in this fashion, behavior cannot be predicted or
guaranteed.  For example, the format of the "Request" command is
as follows in a php style string:

 |-----|    |-------|    |------------------| 
"Request\r\n127.0.0.1\r\nkmeTf4K8Hktd1os29OPK\r\n\r\n"
    --- or ---
"Request\r\n\                  //The command
127.0.0.1\r\n\                 //IP address of requester
kmeTf4K8Hktd1os29OPK\r\n\      //Playlist entry ID
\r\n"                          //Command string terminating CR/LF

The command is given first (Request) then a CR/LF delimiter, then
the IP address of the requester followed another CR/LF delimiter,
then the entry ID of a playlist entry (obtained by the "List"
command earlier), and finally 2 more CR/LF delimiters the first
one indicating the end of the second parameter and the second one
indicating the end of the entire command.



------------------- Commands ------------------------------------

For bare minimum functionality, only two commands are required:
	List
	Request

The "List" command is required because your script needs to tell
your visitors what's in your playlist and know the entry IDs for
the entries to request.
The "Request" command is required for obviouse reasons.  :>

List:
	Format: "List\r\n\r\n"
The "List" command will trigger WebJockey to dump the contents of
your playlist entries into its reply in the following format:

	Listing\r\n
	Entry ID\r\nEntry Title (eg: entry title)\r\nEntry Length in
			seconds\r\n
	...
	Entry ID\r\nEntry Title (eg: entry title)\r\nEntry Length in
			seconds\r\n
	EndListing\r\n
	\r\n

ListLength:
	Format: "ListLength\r\n\r\r"
The "ListLength" command will trigger WebJockey to reply with the
total number of playlist entries in the following format:
	ListLengthReply\r\n[Num of entries]\r\n\r\n

PagedList:
	Format: "PagedList\r\nNumber of entries per page\r\nPage # 
	(zero indexed)\r\n\r\n"
The "PagedList" command will trigger WebJockey to dump paged
version the of the contents of the current playlist into its
reply in the following format:
	PagedListing\r\n
	Entry ID\r\nEntry Title (eg: entry title)\r\nEntry Length in
			seconds\r\n
	...
	Entry ID\r\nEntry Title (eg: entry title)\r\nEntry Length in
			seconds\r\n
	EndPagedListing\r\n
	\r\n
Note: this command will always send [Number of entries per page]
for every [Page #] regardless of the remainder of the last page.
For example, if you make a 20 entry paged request and you have
225 entries, by calculation of modulus the last page (page 12
index 11) would have only 5 entries but WebJockey will send
spaces to fill the next 15 to fill the page.  Requests for [Page
#] that are out of range will result in an empty list reply.

Search:
	Format: "Search\r\n
		[list of search terms seperated with spaces]\r\n
		\r\n"
The "Search" command will cause WebJockey to query its internal
playlist titles database with for each entry in the playlist that
has a title that contains the requested search term or terms and
reply with the following format:
	SearchListing\r\n
	Entry ID\r\nEntry Title\r\nEntry length in seconds\r\n
	...
	Entry ID\r\nEntry Title\r\nEntry length in seconds\r\n
	EndSearchListing\r\n
	\r\n
Note: This command will not reply the same entry ID twice.  For
example, if an entry title contains the terms "thinktink", and
"Retro" and a search is made containing both terms it will return
that entry only once.  Entry titles cannot be pattern matched and
WebJockey can not process or parse wildcards, patterns, nor do
the search results make partial matches (i.e. searching for "a"
will not return entries with titles that have terms that start
with or contain the letter "a".)

Request:
	Format: "Request\r\nIP Address\r\nEntry ID\r\n\r\n"
The "Request" command will trigger WebJockey to check the IP
address, Max Total Requests, and time limits of the request and
if satisfied will que the requested entry.  The response garnered
depends on those constraints:
	RequestReply\r\n
	MaxIPRequests\r\n  //Indicates that the requester has made
			the maximum number of requests for the time alloted.
	  ..or..
	Queued\r\n  //Indicates that the request was allowed and the
			entry was properly queued.
	  ..or..
	AlreadyRequestedPlayed\r\n  //Indicates that the entry was
			already requested or had played within the time
			period configured.
	  ..or..
	AlreadyPlayedOrQueued\r\n  //Indicates that the entry IS
			already playing or is already next to be played (but
			was not requested.)
	  ..or..
	RequestIDError\r\n  //Indicates that the entry ID could not
			be found (invalid entry ID.)
	  ..or..
	MaxTotalRequests\r\n  //Indicates that the maximum number of
			requests for all visitors to WebJockey has been made.
	  ..or..
	RequestFormatError\r\n  //Indicates that you (generally) made
			a boo-boo in your script.
	\r\n

NowPlaying:
	Format: "NowPlaying\r\n\r\n"
The "NowPlaying" command will trigger WebJockey to reply with the
currently playing entry ID, it's title, and the time in seconds
the entry has been playing:

	NowPlayingReply\r\n  //Reply indicator.
	EntryID\r\n  //Entry ID of the currently playing entry.
	EntryTitle\r\n  //Title of the currently playing entry.
	PlayedTime\r\n  //Ammount of time (in seconds) that the entry
			has played.
	\r\n  //Reply terminating CR/LF.

Version:
	Format: "Version\r\n\r\n"
The "Version" command will trigger WebJockey to reply with the
current name and version strings of the installed WebJockey
plug-in:

	VersionReply\r\n  //Reply indicator
	BogProg WebJockey for Winamp\r\n  //Name of plug-in
	1.1\r\n  //Current version of plug-in
	\r\n  //Reply terminating CR/LF.

Settings:
	Format: "Settings\r\n\r\n"
The "Settings" command will trigger WebJockey to reply with the
the current configuration/settings (as set in the configuration
window.)  The order in which the settings are sent can change so
it would be wise to put the reply in some kind of hash or query
table:

	SettingsReply\r\n  //Reply indicator.
	TotalMaxRequests\r\n20\r\n  //Maximum number of requests that
			can be queued until another entry is played.
	IPMaxRequests\r\n3\r\n  //Maximum number of requests per IP
			address.
	SkipVoteCount\r\n30\r\n  //Number of times an entry needs to
			be voted to be skipped.
	TimeLimit\r\n3600\r\n  //Period of time (in seconds) used for
			recently played entries and requested entry history.
	\r\n  //Reply terminating CR/LF.
	
RequestList:
	Format: "RequestList\r\nIP Address\r\n\r\n"
The "RequestList" command will trigger WebJockey dump the list of
recently requested entries by the IP address provided:

	RequestListReply\r\nRequestFormatError\r\n\r\n  //You
			(generally) made a boo-boo in your script.
	  ..or..
	RequestListListing\r\n  //Reply indicator/listing start.
	EntryID\r\nTime\r\n  //Entry ID followed by the amount of
			time since it was requested in seconds.
	  ...
	EntryID\r\nTime\r\n
	EndRequestListListing\r\n  //Listing end indicator
	\r\n  //Reply terminating CR/LF.

SkipVote:
	Format: "SkipVote\r\nIP Address\r\nEntry ID\r\n\r\n
The "SkipVote" command will trigger WebJockey to record the vote
from the IP address, reject it if the visitor already voted,
tally the vote count, and then skip to the next entry if the
tally meets the skip vote count setting:

	SkipVoteReply\r\n
	SkipVoteAccepted\r\n  //The vote was accepted and tallied.
	  ..or..
	SkipVoteDisabled\r\n  //Voting to skip entries is disabled.
	  ..or..
	NotPlaying\r\n  //The entry ID referes to an entry not
			currently being played.
	  ..or..
	IPAlreadyVoted\r\n  //The visitor already voted to skip the
			entry.
	  ..or..
	SkipVoteIDError\r\n  //The entry ID could not be found.
	  ..or..
	SkipVoteFormatError\r\n  //You (generally) made a boo-boo in
			your script.
	\r\n

DJ:NowPlaying:
	Format: "DJ:NowPlaying\r\n\r\n"
The "DJ:NowPlaying" command will return information in the format
similar to the regular "NowPlaying" command except that it
doesn't hide the currently playing stop set item if one is
playing and includes an entry length parameter.  Format:
	DJ:NowPlayingReply\r\n
	[EntryID] or [Full path and filename of StopSet item]\r\n
	[Title of playing entry]\r\n
	[Current playback time]\r\n
	[Length of the currently playing entry]\r\n
	\r\n

DJ:ShuffleList:
	Format: "DJ:ShuffleList\r\n\r\n"
The "DJ:ShuffleList" command will trigger WebJockey to perform a
true shuffle of the internal playlist.  The effect is not
immediate for all entries but is slowly phased in to the active
playlist for all items not recently played or not currently
playing.  WebJockey will reply with an acknowledgement of the
command in the following format:
	DJ:ShuffleListAck\r\n
	\r\n

DJ:ClearStopSet:
	Format: "DJ:ClearStopSet\r\n\r\n"
The "DJ:ClearStopSet" command will trigger WebJockey to clear the
current stop set queue.  The effect is not immediate and takes
internal processing to execute.  The response is just an
acknowledgement of the command in the following format:
	DJ:ClearStopSetAck\r\n\r\n

DJ:StopSetList:
	Format: "DJ:StopSetList\r\n\r\n"
The "DJ:StopSetList" command will trigger WebJockey to dump the
current stop set queue in the following format:
	DJ:StopSetListing\r\n
	[Full path and filename of stop set item]\r\n
		[Title (hopefully) of stop set item]\r\n
		[Length of stop set item]\r\n
	...
	[Full path and filename of stop set item]\r\n
		[Title (hopefully) of stop set item]\r\n
		[Length of stop set item]\r\n
	DJ:StopSetEndListing\r\n
	\r\n

DJ:StopSet:
	Format: "DJ:StopSet\r\n[Full path and file name of stop
			set text file]\r\n\r\n"
The "DJ:StopSet" command will trigger WebJockey to additionally
queue the passed text file of stop set items.  Stop sets require
additional internal processing and so the reply to this command
can be one of any of the following:
	DJ:StopSetUnAuth\r\n\  //Indicates that the requested
		file is outside the permitted range of files.
	  ..or..
	DJ:StopSetAck\r\n  //Indicates command acknowledgement
	r\n

DJ:AddStopSetItem:
	Format: "DJ:AddStopSetItem\r\n[Full path and filename of
		media]\r\n\r\n"
The "DJ:AddStopSetItem" command will trigger WebJockey to queue
as an additional stop set item the passed parameter.  Stop sets
require additional internal processing and so the reply to this
command can be one of any of the following:
	DJ:AddStopSetItemUnAuth\r\n  //Indicates that the
		requested file is outside the permitted range of
		files.
	  ..or..
	DJ:AddStopSetItemAck\r\n  //Indicates command
		acknowledgement.
	\r\n

DJ:LoadStopSetsProgram:
	Format: "DJ:LoadStopSetsProgram\r\n[Full path and
		filename of stop set program file (*.bpwjssp)]
		\r\n\r\n"
The "DJ:LoadStopSetsProgram" command will queue WebJockey to load
the specified BogProg WebJockey StopSets Program file and respond
with one of the following:
	DJ:LoadStopSetsProgramUnAuth\r\n\r\n  //Indicates that
		the requested program file is outside the
		permitted range of files.
	  ..or..
	DJ:LoadStopSetsProgramAck\r\n\r\n  //Inidicates command
		acknowledgement.

DJ:RequestsList:
	Format: "DJ:RequestsList\r\n\r\n"
The "DJ:RequestsList" command will trigger WebJockey to reply
with the entries recently requested in the following format:
	DJ:RequestsListing\r\n
	[Entry ID]\r\n[IP of requester]\r\n[Date/Time request was
		made in seconds]\r\n[Title]\r\n
	...
	[Entry ID]\r\n[IP of requester]\r\n[Date/Time request was
		made in seconds]\r\n[Title]\r\n
	DJ:RequestsEndListing\r\n
	\r\n

DJ:Played:
	Format: "DJ:Played\r\n\r\n"
The "DJ:Played" command will trigger WebJockey to reply with the
list of entries that have recently been played in the following
format:
	DJ:PlayedListing\r\n
	[Entry ID]\r\n[IP of requester (if requested)]\r\n[Number
		of seconds since played]\r\n
	...
	[Entry ID]\r\n[IP of requester (if requested)]\r\n[Number
		of seconds since played]\r\n
	DJ:PlayedEndListing\r\n
	\r\n
Note: If a played entry did not have a requester the IP parameter
is filled with a single space " ".

DJ:PurgePlayed:
	Format: "DJ:PurgePlayed\r\n\r\n"
The "DJ:PurgePlayed" command will trigger WebJockey to
immediately clear the recently played cache and reply in the
following format:
	DJ:PurgePlayedDone\r\n
	\r\n

DJ:PurgeRequests:
	Format: "DJ:PurgeRequests\r\n\r\n"
The "DJ:PurgeRequests" command will trigger WebJockey to
immediately clear the requests queue regardless if an entry was
played or not.  WebJockey will respond once the command is
finished executing in the following format:
	DJ:PurgeRequestsDone\r\n
	\r\n

DJ:PurgeOpenRequests:
	Format: "DJ:PurgeOpenRequests\r\n\r\n"
The "DJ:PurgeOpenRequests" command will trigger WebJockey to
immediately clear the requests queue of unplayed requests and
will respond with the following format:
	DJ:PurgeOpenRequestsDone\r\n
	\r\n

DJ:QueuePlaylist:
	Format: "DJ:QueuePlaylist\r\n[Full path and filename of
		M3U/PLS playlist file]\r\n\r\n"
The "DJ:QueuePlaylist" command will trigger WebJockey to start
the process of internally updating the current playlist.
Depending on current settings WebJockey will reply in the
following format:
	DJ:QueuePlaylistUnAuth\r\n  //Indicates that the
		requested playlist file is outside the permitted
		range of files.
	  ..or..
	DJ:QueuePlaylistError\r\n  //Indicates the playlist file
		either does not exist or is corrupted on the
		filesystem.
	  ..or..
	DJ:QueuePlaylistSent\r\n  //Indicates that the playlist
		file will be processed.
	\r\n

DJ:SkipNow:
	Format: "DJ:SkipNow\r\n[IP of requester]\r\n[Full path
		and filename of entry or Entry ID]\r\n\r\n"
The "DJ:SkipNow" command is similar in format as the "SkipVote"
command except that it also allows referencing the entry to be
skipped by file name and when received it will skip the indicated
entry if it is playing immediately.  WebJockey will reply with
one of the following indicators in the following format:
	DJ:SkipNowReply\r\n
	SkipNowAccepted\r\n  //Indicates that the entry will be
		skipped now.
	  ..or..
	NotPlaying\r\n  //Indicates that the entry to be skipped
		is not currently playing
	  ..or..
	SkipVoteIDError\r\n  //Indicates that the entry ID or the
		file name sent cannot be found in the current
		playlist.
	\r\n

DJ:Request:
	Format: "DJ:Request\r\n[IP of requester]\r\n[Entry ID or full path and filename of media]\r\n"
The "DJ:Request" is similar to the "Request" command except that
it will trigger WebJockey to queue the entry as very next
regardless of whether it was recently played, recently requested,
or exceeds the maximum requests settings.  It also allows the use
of file names inplace of Entry IDs to allow requests for media
that are not in the current playlist.  The command will reply
with the following format:
	DJ:RequestReply\r\n
	RequestUnAuth\r\n  //Indicates that the requested file is
		outside the permitted range of files.
	  ..or..
	RequestDone\r\n  //Indicates that the requested file was
		queued.
	  ..or..
	AlreadyNowPlaying\r\n  //Indicates that the requested
		file is now playing and the request was rejected.
	  ..or..
	NotFound\r\n  //Indicates that WebJockey could not find
		the media requested whether by ID or file name.
	\r\n

DJ:StopSetFileHistoryList:
	Format: "DJ:StopSetFileHistoryList\r\n\r\n"
The "DJ:StopSetFileHistoryList" command will trigger WebJockey to
dump the list of all stop set text files ever queued since
installation.  Stop set text file reuse is highly encouraged.
WebJockey will reply with the following format:
	DJ:StopSetFileHistoryListing\r\n
	[Full path and filename of stop set text file]\r\n
	...
	[Full path and filename of stop set text file]\r\n
	DJ:StopSetFileHistoryEndListing\r\n
	\r\n
Note: This is not a MRU list.  The size of this list is limited
only by the ammount of memory and harddrive space your computer
has before crashing.

DJ:RemoveStopSetFileHistoryItem:
	Format: "DJ:RemoveStopSetFileHistoryItem\r\n[Full path
		and filename of stop set text file to remove]\r\n
		\r\n"
The "DJ:RemoveStopSetFileHistoryItem" command will trigger
WebJockey to remove the passed file from the list.  WebJockey
will reply with the following format:
	DJ:RemoveStopSetFileHistoryItemReply\r\n
	Done\r\n  //Indicates that the item was removed.
	  ..or..
	NotFound\r\n  //Indicates that the item was not found in
		the list
	  ..or..
	FormatError\r\n  //Indicates that the request was
		malformed or the file parameter was missing.
	\r\n

DJ:StopSetItemHistoryList:
	Format: Same as "DJ:StopSetFileHistoryList"
The "DJ:StopSetItemHistoryList" is the exact same as the
"DJ:StopSetFileHistoryList" command except that it deals with
individual media used as stop set items.  The reply is similar to
that of the reply to the "DJ:StopSetFileHistoryList" command also
except "DJ:StopSetItemHistoryListing" and
"DJ:StopSetItemHistoryEndListing" are used in the reply to
delineate the start and end of the list.

DJ:RemoveStopSetItemHistoryItem:
	Format: Same as "DJ:RemoveStopSetFileHistoryItem"
The "DJ:RemoveStopSetFileHistoryItem" command is the same as the
"DJ:RemoveStopSetFileHistoryItem" command except that it deals
with the history list of individual media used as stop set items.

DJ:RequestHistoryList:
	Format: You're kidding right?
Yadda yadda yadda, so on and so forthe.  Replies with
"DJ:RequestHistoryListing" and "DJ:RequestHistoryEndListing"
respectively.

DJ:RemoveRequestHistoryItem:
	Format: You're kidding right?
Yadda yadda yadda, so on and so forthe.  Replies with
"DJ:RemoveRequestHistoryItemReply" instead.

DJ:PlaylistHistoryList:
	Format: You're kidding right?
Yadda yadda yadda, so on and so forthe.  Replies with
"DJ:PlaylistHistoryListing" and "DJ:PlaylistHistoryEndListing"
respectively.

DJ:RemoveRequestHistoryItem:
	Format: You're kidding right?
Yadda yadda yadda, so on and so forthe.  Replies with
"DJ:RemoveRequestHistoryItemReply" instead.

DJ:StopSetsProgramHistoryList:
	Format: You're kidding right?
Yadda yadda yadda, so on and so forthe.  Replies with
"DJ:StopSetsProgramHistoryListing" and "DJ:StopSetsProgramHistoryEndListing"
respectively.

DJ:RemoveStopSetsProgramHistoryItem:
	Format: You're kidding right?
Yadda yadda yadda, so on and so forthe.  Replies with
"DJ:RemoveStopSetsProgramHistoryItemReply" instead.

DJ:SetSettings:
	This command has several formats with a variable number
		of selectable parameters in the following format:
	DJ:SetSettings\r\n
	TotalMaxRequests\r\n[Total number of maximum requests]\r\n
	  ..and/or..
	IPMaxRequests\r\n[Maximum number of requests per IP]\r\n
	  ..and/or..
	SkipVoteCount\r\n[Number of votes to skip a playing 
		entry]\r\n
	  ..and/or..
	TimeLimit\r\n[Period of time (in seconds) used for
		recently played entries and requested entry
		history]\r\n
	\r\n
The "DJ:SetSettings" command, if allowed by the current settings
will the render changes the above specified settings.  WebJockey
will reply with the following format:
	DJ:SetSettingsUnAuth\r\n  //Indicates that the current
		settings do not permit changing the settings from
		within these protocols.
	  ..or..
	DJ:SetSettingsDone\r\n  //Indicates that the settings
		have been changed and applied
	\r\n

DJ:DrivesList:
	Format: "DJ:DrivesList\r\n\r\n"
The "DJ:DrivesList" command will trigger WebJockey to reply with
the list of drives selectable on the system with the following
format:
	DJ:DrivesListing\r\n
	[Drive letter (does not inlude the driver letter colon
		delinieation character)]\r\n
	...
	[Drive letter (does not inlude the driver letter colon
		delinieation character)]\r\n
	DJ:DrivesEndListing\r\n
	\r\n
Note: If the DJ Path is restricted, only the drive letter of the
set restricted-to path will be listed.

DJ:AuthBrowsePath:
	Format: "DJ:AuthBrowsePath\r\n\r\n"
The "DJ:AuthBrowsePath" will trigger WebJockey to return the full
path of the folder or drive that DJ filesystem browsing commands,
requests, and other filesystem operations are limited to in the
following format:
	DJ:AuthBrowsePathReply\r\n
	[Full path to DJ restricted folder or drive]\r\n
	\r\n
Note: If the restrited-to path is left blank in the configuration
then the connected browser can view and list all drives, folders,
and files on the local filesystem.  It is highly recommended that
unless you know your webserver or other connection to WebJockey
is very secure, to configure this path, though it is not required
for proper operation.

DJ:Browse:
	Format: "DJ:Browse\r\n[Full path to filesystem folder or
		drive resource]\r\n[Search pattern]\r\n\r\n"
The "DJ:Browse" command will trigger WebJockey to dump the list
of files and folders in the specified filesystem resource (if
allowed by the current settings) in the reply with the following
format:
	DJ:BrowseReply\r\n
	UnAuth\r\n    //Indicates that the requested filesystem
		resource is outside the permitted range of
		resources.
	  ..or..
	NotFound\r\n  //Indicates that the requested filesystem
		resource could not be located or is currently
		inaccesible.
	  ..or..
	BrowseListing\r\n
	D\r\n[(Sub)directory name]\r\n  //Is a folder.
	...
	LD\r\n[Resource link identifier]  //Is a link to a folder
		or a filesystem drive.
	...
	F\r\n[File name]  //Is a file on the filesystem.
	...
	LF\r\n[Resource link identifier]  //Is a link to a file
		somewhere on the filesystem.
	BrowseEndListing\r\n
	\r\n
Note: The directory, link, and file names are all returned
relative to the path or drive letter specified in the command.
Folders are always listed first, then links to folders, then
files, and then links to files.  Files and links to files matched
with multiple patterns specified in the patterns parameter are
listed in the order of the specified patterns.  Do not specify an
ending folder deliniating character "\" at any time.  All
requests are treated as a folder (or root filesystem drive).

DJ:ResolveLink:
	Format: "DJ:ResolveLink\r\n[Full path and filename to LNK file]\r\n\r\n"
The "DJ:ResolveLink" command will trigger WebJockey to reply with
the full path and filename or folder that the specified link file
resolves to with the following format:
	DJ:ResolveLinkReply\r\n
	UnAuth\r\n  //Indicates that the requested link file is
		outside the permitted range of files.
	  ..or..
	NotALink\r\n  //Indicates the requested link file is not
		actually a LNK file.
	  ..or..
	NotFound\r\n  //Indicates the requested link file does
		not exist.
	  ..or..
	Broken\r\n  //Indicates the requested link file resolves
		to a file or folder resource that either does not
		exist, has moved or been removed, or is itself
		corrupted.
	  ..or..
	Resolved\r\n[Full path to file, folder or root filesytem
		drive resource]\r\n
	\r\n
Note: Please be mindfull that the reply to this command has a
variable number of reply parameters.

DJ:FileInfo:
	Format: "DJ:FileInfo\r\n[Full path and filename or Entry
		ID or url/uri of resource]\r\n[type or metadata
		name of information to retrieve (or leave empty
		for all known information/metadata)]\r\n\r\n"
The "DJ:FileInfo" command will trigger WebJockey to query Winamp
for the requested information and reply with the following
format:
	FileInfoFormatError\r\n  //Indicates that the required
		filename parameter is missing from the command.
	  ..or..
	DJ:FileInfoListing\r\n
	[data/field name]\r\n[status (will be one of "filled",
		"blank", or "unsupported")]\r\n[uri encoded
		data]\r\n
	...
	[data/field name]\r\n[status (will be one of "filled",
		"blank", or "unsupported")]\r\n[uri encoded
		data]\r\n
	DJ:FileInfoEndListing\r\n
	\r\n
Note: If the status of a returned entry is marked as "filled"
then the information is available in uri encoded format.  If it's
marked as "blank" then it means that the field is supported but
there is no data for that entry.  If it's marked as "unsupported"
then the field is currently unsupported for the entry requested.

DJ:AdvanceToEntry (Broken):
	Format: "DJ:AdvanceToEntry\r\n[Full path and filename or
		Entry ID]\r\n\r\n"
The internal function for this command is impotent.  For this
reason the intended function of this command will remain, for the
time being, undocumented.  It is here only for referance and
completness of documention.

DJ:SeekToTime:
	Format: "DJ:SeekToTime\r\n[Time in seconds (negative or
		positive)]\r\n\r\n"
When the parameter is a positive value the command will trigger
WebJockey to seek the currently playing file to the time
specified in seconds.  If the parameter indicates a negative
value the command will trigger WebJockey to seek the currently
playing file from the end.  For example, if you have a 1 minute
song and you specify -10, WebJockey will seek the song to time
position 0:50.
------------------- Have fun ------------------------------------
-->
<script language="javascript" type="text/javascript">
<!--
var lastWindowMoving=null;
var xmlhttp;
var npd;
var npnd;
var nptd;
var tid;
var onps="";
var watabled;
var std;
var skipbutton;
var skipd;
var bpwjs = new Array();
var bpwjsl = false;
var WebJockeyAI="bpwjai.php";
var WebJockeyPort = "<?php echo $WebJockeyPort; ?>";
var WebJockeyIP = "<?php echo $WebJockeyIP; ?>";
var CommonWebJockeyAIURL="IP="+WebJockeyIP+"&Port="+WebJockeyPort;
var wjct="Content-type",wjctt="application/x-www-form-urlencoded";
var rlTime;
var rlA = new Array();
var rlB = new Array();
var ilnpd;
var Total=0;
var oNPP=<?php echo $NumPerPage; ?>;
var NPP=oNPP;
var CurPage=0;
var PageCount=1;
var prevpagebutton;
var nextpagebutton;
var pspan;
var searchbutton;

var HelperEnabled=true;
var Helper;
var HelperScrollCheckerTimerID;
var HelperTitleBar;
var Hx=0;
var Hy=0;
var Hwd=false;
var Ox=0;
var Oy=0;


var makeWindowMovable=function(target, handle)
{
	handle.target=target;
	target.handle=handle;
	function WindowHandleOnTouchStart(w)
	{
		var event=w || window.event;
		if(event.targetTouches.length!=1)return;
		var target=this.target;
		var handle=target.handle;
		var touch=event.targetTouches[0];
		target.OldZIndex=target.style.zIndex;
		target.OldCursor=target.style.cursor;
		target.style.cursor="grabbing";
		target.style.zIndex="100";
		lastWindowMoving=target;
		var initialXOffset=0;
		var initialYOffset=0;
		if(event.preventDefault)
		{
			event.preventDefault();
		}
		if("pageX" in touch)
		{
			initialXOffset=target.offsetLeft - touch.pageX;
			initialYOffset=target.offsetTop - touch.pageY;
		}
		else
		{
			initialXOffset=target.offsetLeft - touch.clientX;
			initialYOffset=target.offsetTop - touch.clientY;
		}
		function WindowHandleOnTouchMove(w)
		{
			var event=w || window.event;
			if(event.targetTouches.length!=1)
			{
				WindowHandelOnTouchEnd.call(document,w);
				return;
			}
			var touch=event.targetTouches[0];
			var x=0,y=0;
			if("pageX" in touch)
			{
				x=(touch.pageX + initialXOffset);
				y=(touch.pageY + initialYOffset); 
			}
			else
			{
				x=(touch.clientX + initialXOffset);
				y=(touch.clientY + initialYOffset); 
			}
			if(x<0){x=0;}
			if(y<0){y=0;}
			lastWindowMoving.style.left=x+"px";
			lastWindowMoving.style.top=y+"px";
		}
		function WindowHandelOnTouchEnd(w)
		{
			document.removeEventListener("touchmove",WindowHandleOnTouchMove);
			document.removeEventListener("touchend",WindowHandelOnTouchEnd);
			if(event.preventDefault)
			{
				event.preventDefault();
			}
			if(lastWindowMoving)
			{
				lastWindowMoving.style.cursor="";
				lastWindowMoving.style.zIndex="";
				delete lastWindowMoving.OldCursor;
				delete lastWindowMoving.OldZIndex;
				lastWindowMoving=null;
			}
		}
		document.addEventListener("touchmove",WindowHandleOnTouchMove);
		document.addEventListener("touchend",WindowHandelOnTouchEnd);
		return false;
	}
	handle.addEventListener("touchstart",WindowHandleOnTouchStart);
	function WindowHandleOnMouseDown(w)
	{
		var event=w || window.event;
		var target=this.target;
		var handle=target.handle;
		target.OldZIndex=target.style.zIndex;
		target.OldCursor=target.style.cursor;
		target.style.cursor="grabbing";
		target.style.zIndex="100";
		lastWindowMoving=target;
		var initialXOffset=0;
		var initialYOffset=0;
		if(event.preventDefault)
		{
			event.preventDefault();
		}
		if("pageX" in event)
		{
			initialXOffset=target.offsetLeft - event.pageX;
			initialYOffset=target.offsetTop - event.pageY;
		}
		else
		{
			initialXOffset=target.offsetLeft - event.clientX;
			initialYOffset=target.offsetTop - event.clientY;
		}
		function WindowHandleOnMouseMove(w)
		{
			var event=w || window.event;
			var target=lastWindowMoving;
			if(!target){WindowHandleOnMouseUp.call(document,w);}
			var x=0,y=0;
			if("pageX" in event)
			{
				x=(event.pageX + initialXOffset);
				y=(event.pageY + initialYOffset); 
			}
			else
			{
				x=(event.clientX + initialXOffset);
				y=(event.clientY + initialYOffset); 
			}
			if(x<0){x=0;}
			if(y<0){y=0;}
			target.style.left=x+"px";
			target.style.top=y+"px";
		}
		function WindowHandleOnMouseUp(w)
		{
			document.removeEventListener("mousemove",WindowHandleOnMouseMove)
			document.removeEventListener("mouseup",WindowHandleOnMouseUp)
			if(lastWindowMoving)
			{
				lastWindowMoving.style.cursor=lastWindowMoving.OldCursor;
				lastWindowMoving.style.zIndex=lastWindowMoving.OldZIndex;
				delete lastWindowMoving.OldCursor;
				delete lastWindowMoving.OldZIndex;
				lastWindowMoving=null;
			}
		}
		document.addEventListener("mousemove",WindowHandleOnMouseMove);
		document.addEventListener("mouseup",WindowHandleOnMouseUp);
		return false;
	}
	handle.addEventListener("mousedown",WindowHandleOnMouseDown);
}
function Helper_mousedown(e)
{
	var e = e || window.event;
	Hwd=true;
	Ox=parseInt(Helper.style.left)*1;
	Oy=parseInt(Helper.style.top)*1;
	Hx=e.clientX;
	Hy=e.clientY;
}
function Helper_mouseout()
{
	Hwd=false;
}
function Helper_mousemove(e)
{
	if(!Hwd){return;};
	var e = e || window.event;
	Dx=e.clientX-Hx;
	Dy=e.clientY-Hy;
	Nx = ((Ox + Dx));
	Ny = ((Oy + Dy));
	Helper.style.left = Nx+"px";
	Helper.style.top = Ny+"px";
	Ox=Nx;
	Oy=Ny;
	Hx=e.clientX;
	Hy=e.clientY;
}
function Helper_mouseup()
{
	Hwd=false;
}
function ShowHelper()
{
	if(!HelperEnabled){return;}
	Helper.style.display="";
	document.onscroll=HelperKeepInView;
	window.onscroll=HelperKeepInView;
	HelperScrollCheckerTimerID=setInterval("HelperKeepInView()",200);
};
function HideHelper()
{
	if(!HelperEnabled){return;}
	Helper.style.display="none";
	document.onscroll=null;
	window.onscroll=null;
	clearInterval(HelperScrollCheckerTimerID); //good Lord God Almighty that's a long variable name!
};
function HelperKeepInView()
{
	if(Hwd){return;}
	ht=parseInt(Helper.style.top);
	hh=parseInt(Helper.clientHeight);
	hb=ht+hh;
	vb=document.documentElement.clientHeight+document.documentElement.scrollTop;
	nt=ht;
	if(hb+3>vb && !(ht<document.documentElement.scrollTop))
	{
		nt=(vb-3)-parseInt(Helper.clientHeight);
		hb=nt+hh;
		if(nt<document.documentElement.scrollTop)
		{
			nt=document.documentElement.scrollTop;
			hb=nt+hh;
		}
	}
	if(ht<document.documentElement.scrollTop)
	{
		nt=document.documentElement.scrollTop;
		hb=nt+hh;
	}
	if(nt!=ht){Helper.style.top=nt+"px";}
}

function stu(du)
{
	var b;
	if(du){b="true";}else{b="false";}
	tid=setTimeout("npt("+b+")",990);
};

function ctu()
{
	clearTimeout(tid);
};

function formatTimeDispE(t)
{
	st=t%60;
	tmt=(t-st)/60;
	mt=tmt%60;
	ht=(tmt-mt)/60;
	t="";
	p="";
	if(ht!=0)
	{
		if(t!=""){t+=" ";}
		if(ht==1){p="";}else{p="s";}
		t+=ht+" hour"+p;
	}
	if(mt!=0)
	{
		if(t!=""){t+=" ";}
		if(mt==1){p="";}else{p="s";}
		t+=mt+" minute"+p;
	}
	if(st!=0)
	{
		if(t!=""){t+=" ";}
		if(st==1){p="";}else{p="s";}
		t+=st+" second"+p;
	}
	return t;
}
function formatTimeDisp(t)
{
	st=t%60;
	tmt=(t-st)/60;
	mt=tmt%60;
	ht=(tmt-mt)/60;
	if(st<10){st="0"+st;}else{st=st;}
	if(ht>0)
	{
		if(mt<10){mt="0"+mt;}else{mt=mt;}
	}else{mt=mt;}
	if(ht>0){t=ht+":"+mt+":"+st;}else{t=mt+":"+st;}
	return t;
}
function onprevpagebuttonClick()
{
	var t=CurPage;
	t=t-1;
	if(t<0){t=0;}
	if(CurPage!=t)
	{
		CurPage=t;
		pspan.innerHTML="Please wait...";
		rlist();
	}
}
function onnextpagebuttonClick()
{
	var t=CurPage;
	t=t+1;
	if(t>=PageCount){t=PageCount-1;}
	if(CurPage!=t)
	{
		CurPage=t;
		pspan.innerHTML="Please wait...";
		rlist();
	}
}
function onsearchbuttonClick()
{
	prevpagebutton.style.display="none";
	nextpagebutton.style.display="none";
	ctu();
	var tokens=document.getElementById("searchedit").value;
	if(tokens=="")
	{
		rlist();
		prevpagebutton.style.display="inline";
		nextpagebutton.style.display="inline";
		stu(false);
		return false;
	}
	CurPage=0;
	pspan.innerHTML="Please wait...";
	xmlhttp.abort();
	xmlhttp.open("POST",WebJockeyAI,false);
	xmlhttp.setRequestHeader(wjct,wjctt);
	xmlhttp.send(CommonWebJockeyAIURL+"&Command=Search&Param1="+tokens);
	var rt=xmlhttp.responseText;
	xmlhttp.abort();
	xmlhttp.open("POST",WebJockeyAI,false);
	xmlhttp.setRequestHeader(wjct,wjctt);
	xmlhttp.send(CommonWebJockeyAIURL+"&Command=RequestList&Param1=i");
	var rl=xmlhttp.responseText;
	if(rt==""){return false;}
	if(rl==""){return false;}
	var lt=rt.split("\r\n");
	var rt=rl.split("\r\n");
	var lr=lt.shift();
	if(lr!="SearchListing"){return false;}
	if(lt.pop()!=""){return false;}
	if(lt.pop()!=""){return false;}
	lr=lt.pop();
	if(lr!="EndSearchListing"){return false;}
	if(rt.shift()!="RequestListListing"){return false;}
	if(rt.pop()!=""){return false;}
	if(rt.pop()!=""){return false;}
	if(rt.pop()!="EndRequestListListing"){return false;}
	var c=lt.length;
	var d=rt.length;
	if(c%3!=0){return false;}
	if(d%2!=0){return false;}
	delete rlA;
	delete rlB;
	rlA = new Array();
	rlB = new Array();
	//if(c<1){return false;}
	var tt="<table summary=\"\" class=\"watable\" style=\"background: #000000; color: #00FF00; font-family: arial; font-size: 8pt\">";
	cl1="";
	cl2="";
	var rlc=0;
	for(i=0;i<c;i+=3)
	{
		if(lt[i]==" " && lt[i+1]==" " && lt[i+2]==" ")continue;
		wr=0;
		wrta=0;
		for(j=0;j<d;j+=2)
		{
			if(lt[i]==rt[j]){wr=1;wrta=rt[j+1];break;}
		}
		/*if(lt[i]==npim)
		{
			cl1="\"clin\"";
			cl2="\"clirn\"";
		}
		else*/
		{
			cl1="\"cli\"";
			cl2="\"clir\"";
		}
		tt+="<tr>";
		tt+="<td class="+cl1+">"+((((i) / 3)+1)+(NPP*CurPage))+". "+lt[i+1]+"</td>";
		tt+="<td class="+cl2+">"+formatTimeDisp(lt[i+2])+"</td>";
		/*if(lt[i]==npim)
		{
			tt+="<td class="+cl1+"><b>Now Streaming</b> <span id=\"ilnpd\">"+formatTimeDisp(npts)+"</span></td>";
		}
		else
		if(wr==1)
		{
			tt+="<td class="+cl1+">Your request</td>";
		}
		else*/
		{
			tt+="<td class="+cl1+"><input type=\"button\" name=\"Submit\" value=\"Request\" class=\"wab\" onclick=\"return onRequstButtonClick('"+lt[i]+"')\"/>";
		}
		if(wr==1)
		{
			tt+="<td class="+cl2+">&nbsp;&nbsp;<span id=\"inrd"+rlc+"\">"+formatTimeDisp(wrta)+"</span></td>";
			rlA.push("inrd"+rlc);
			rlB.push(wrta*1);
			rlc++;
		}
		else
			tt+="<td class="+cl2+">&nbsp;&nbsp;</td>";
		tt+="</tr>";
	}
	if(c<1)
	{
		tt+="<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td style=\"width: 250px;\" class=\"clir\">No results.</td></tr>";
	}
	tt+="</table>";
	watabled.innerHTML=tt;
	for(j=0;j<d;j+=2)
	{
		rlA[j/2]=document.getElementById(rlA[j/2]);
	}
	ilnpd=document.getElementById("ilnpd");
	pspan.innerHTML="Search results:";
	stu(true);
	return false;
}
function onSkipButtonClick()
{
	ctu();
	xmlhttp.abort();
	xmlhttp.open("POST",WebJockeyAI,false);
	xmlhttp.setRequestHeader(wjct,wjctt);
	xmlhttp.send(CommonWebJockeyAIURL+"&Command=SkipVote&Param1=IP&Param2="+onps);
	var rt=xmlhttp.responseText;
	if(rt==""){stu(false);return;}
	var svra=rt.split("\r\n");
	if(svra[0]!="SkipVoteReply"){stu(false);return;}
	RR=svra[1];
	temp="Unknown response from server.  Please inform the webmaster immediately.";
	if(RR=="SkipVoteDisabled"){temp="Voting to skip songs is disabled.";}
	if(RR=="SkipVoteAccepted"){temp="Your request has resulted in a successful vote to skip!";}
	if(RR=="IPAlreadyVoted"){temp="You already voted to skip the song.";}
	if(RR=="NotPlaying"){temp="The song you voted to be skipped is not playing.";}
	if(RR=="SkipVoteIDError"){temp="The server could not find the song you want skipped.  Please refresh the play list and try again.";}
	if(RR=="SkipVoteFormatError"){temp="The server received an improperly formatted request!  Please inform the webmaster immediately!";}
	std.innerHTML="<b>"+temp+"</b>";
	stu(false);
};

function onRequstButtonClick(id)
{
	ctu();
	xmlhttp.abort();
	xmlhttp.open("POST",WebJockeyAI,false);
	xmlhttp.setRequestHeader(wjct,wjctt);
	xmlhttp.send(CommonWebJockeyAIURL+"&Command=NowPlaying");
	var rt=xmlhttp.responseText;
	if(rt==""){stu(false);return;}
	var npra=rt.split("\r\n");
	if(npra[0]!="NowPlayingReply"){stu(false);return;}
	xmlhttp.open("POST",WebJockeyAI,false);
	xmlhttp.setRequestHeader(wjct,wjctt);
	xmlhttp.send(CommonWebJockeyAIURL+"&Command=Request&Param1=i&Param2="+id);
	var rt=xmlhttp.responseText;
	temp="Unknown response from server.  Please inform the webmaster immediately.";
	var a=rt.split("\r\n");
	if(a[0]!="RequestReply"){stu(false);return;}
	RR=a[1];
	if(RR=="MaxIPRequests"){temp="You have reached the limit for requesting songs at your IP address.";}
	if(RR=="Queued")
	{
		temp="Your request has resulted in a successful queue!";
		rwtd(npra[1],npra[3]);
	}
	if(RR=="AlreadyRequestedPlayed"){temp="The song you requested has already been requested or has been recently played.";}
	if(RR=="AlreadyPlayedOrQueued"){temp="The song you requested is already playing or is next to be played.";}
	if(RR=="MaxTotalRequests"){temp="The server has reached a maximum request limit.  Please try again after a few songs have been played.";}
	if(RR=="RequestIDError"){temp="The server could not find the song you requested.  Please refresh the play list and try again.";}
	if(RR=="RequestFormatError"){temp="The server received an improperly formatted request!  Please inform the webmaster immediately!";}
	std.innerHTML="<b>"+temp+"</b>";
	stu(false);
};

function onBodyLoad()
{
	loadXMLDoc();
	rlTime = new Date();
	if(xmlhttp==null){return;}
	npd=document.getElementById("npd");
	npd.innerHTML="<font color=\"#FFFFFF\">Now Streaming --"+"> <b><span name=\"npnd\" id=\"npnd\" style=\"display: inline;\">[Please Wait...]</span></b>&nbsp;<span name=\"nptd\" id=\"nptd\" style=\"display: inline;\">-:--</span></font>";
	npnd=document.getElementById("npnd");
	nptd=document.getElementById("nptd");
	watabled=document.getElementById("watabled");
	std=document.getElementById("std");
	skipd=document.getElementById("skipd");
	skipd.innerHTML="<input name=\"Skip\" value=\"\" class=\"wab\" type=\"button\" id=\"skipbutton\" />";
	skipbutton=document.getElementById("skipbutton");
	skipbutton.disabled=true;
	skipbutton.value="Skip";
	prevpagebutton=document.getElementById("prevpagebutton");
	//prevpagebutton.disabled=true;
	prevpagebutton.value="<- Prev";
	nextpagebutton=document.getElementById("nextpagebutton");
	//nextpagebutton.disabled=true;
	nextpagebutton.value="Next ->";
	prevpagebutton.onclick=onprevpagebuttonClick;
	nextpagebutton.onclick=onnextpagebuttonClick;
	pspan=document.getElementById("pspan");
	pspan.innerHTML="";
	searchbutton=document.getElementById("searchbutton");
	//searchbutton.onclick=onsearchbuttonClick;
	var searchform=document.getElementById("searchform");
	searchform.action="";
	searchform.method="POST";
	searchform.onsubmit=onsearchbuttonClick;
	if(HelperEnabled)
	{
		Helper=document.getElementById('Helper');
		HelperTitleBar=document.getElementById('HelperTitleBar');
		/*HelperTitleBar.onmousedown=Helper_mousedown;
		HelperTitleBar.onmousemove=Helper_mousemove;
		HelperTitleBar.onmouseup=Helper_mouseup;
		HelperTitleBar.onmouseout=Helper_mouseout;*/
		Helper.style.left="550px";
		Helper.style.top="100px";
		ShowHelper();
		makeWindowMovable(Helper, HelperTitleBar);
	}
	npt(false);
}
function loadbpwbsettings()
{
	bpwjsl=false;
	xmlhttp.abort();
	xmlhttp.open("POST",WebJockeyAI,false);
	xmlhttp.setRequestHeader(wjct,wjctt);
	xmlhttp.send(CommonWebJockeyAIURL+"&Command=Settings");
	var rt=xmlhttp.responseText;
	if(rt!="")
	{
		var st=rt.split("\r\n");
		if(st.shift()=="SettingsReply")
		{
			if(st.pop()=="")
			{
				if(st.pop()=="")
				{
					var c=st.length;
					bpwjsl=true;
					for(i=0;i<c;i+=2)
					{
						bpwjs[st[i]]=st[i+1];
					}
				}
			}
		}
	}
};
function rwtd(npim,npts)
{
	loadbpwbsettings();
	if(!bpwjsl)
		skipbutton.disabled=false;
	else
		if(bpwjs["SkipVoteCount"]>0)
			skipbutton.disabled=false;
		else
			skipbutton.disabled=true;
	xmlhttp.abort();
	xmlhttp.open("POST",WebJockeyAI,false);
	xmlhttp.setRequestHeader(wjct,wjctt);
	xmlhttp.send(CommonWebJockeyAIURL+"&Command=ListLength");
	Total=xmlhttp.responseText;
	Total=Total.split("\r\n");
	if(Total[0]!="ListLengthReply"){return;}
	Total=Total[1];
	Total=Total*1;
	Total=Total+0;
	if(NPP>0)
	{
		PageCount=Total%NPP;
		if(PageCount>0)
		{
			PageCount=((Total-PageCount)/NPP)+1;
		}
		else
		{
			PageCount=Total/NPP;
		}
	}
	else
	{
		NPP=0;
		PageCount=1;
	}
	if(PageCount<1){PageCount=1;}
	if(CurPage>=PageCount){CurPage=PageCount-1;}
	xmlhttp.abort();
	xmlhttp.open("POST",WebJockeyAI,false);
	xmlhttp.setRequestHeader(wjct,wjctt);
	if(NPP>0)
	{
		xmlhttp.send(CommonWebJockeyAIURL+"&Command=PagedList&Param1="+NPP+"&Param2="+CurPage);
	}
	else
	{
		xmlhttp.send(CommonWebJockeyAIURL+"&Command=List");
	}
	var rt=xmlhttp.responseText;
	xmlhttp.abort();
	xmlhttp.open("POST",WebJockeyAI,false);
	xmlhttp.setRequestHeader(wjct,wjctt);
	xmlhttp.send(CommonWebJockeyAIURL+"&Command=RequestList&Param1=i");
	var rl=xmlhttp.responseText;
	if(rt==""){return;}
	if(rl==""){return;}
	var lt=rt.split("\r\n");
	var rt=rl.split("\r\n");
	var lr=lt.shift();
	if(lr!="PagedListing" && lr!="Listing"){return;}
	if(lt.pop()!=""){return;}
	if(lt.pop()!=""){return;}
	lr=lt.pop();
	if(lr!="EndPagedListing" && lr!="EndListing"){return;}
	if(rt.shift()!="RequestListListing"){return;}
	if(rt.pop()!=""){return;}
	if(rt.pop()!=""){return;}
	if(rt.pop()!="EndRequestListListing"){return;}
	var c=lt.length;
	var d=rt.length;
	if(c%3!=0){return;}
	if(d%2!=0){return;}
	delete rlA;
	delete rlB;
	rlA = new Array();
	rlB = new Array();
	if(c<1){return;}
	var tt="<table summary=\"\" class=\"watable\" style=\"background: #000000; color: #00FF00; font-family: arial; font-size: 8pt\">";
	cl1="";
	cl2="";
	var rlc=0;
	for(i=0;i<c;i+=3)
	{
		if(lt[i]==" " && lt[i+1]==" " && lt[i+2]==" ")continue;
		wr=0;
		wrta=0;
		for(j=0;j<d;j+=2)
		{
			if(lt[i]==rt[j]){wr=1;wrta=rt[j+1];break;}
		}
		if(lt[i]==npim)
		{
			cl1="\"clin\"";
			cl2="\"clirn\"";
		}
		else
		{
			cl1="\"cli\"";
			cl2="\"clir\"";
		}
		tt+="<tr>";
		tt+="<td class="+cl1+">"+((((i) / 3)+1)+(NPP*CurPage))+". "+lt[i+1]+"</td>";
		tt+="<td class="+cl2+">"+formatTimeDisp(lt[i+2])+"</td>";
		if(lt[i]==npim)
		{
			tt+="<td class="+cl1+"><b>Now Streaming</b> <span id=\"ilnpd\">"+formatTimeDisp(npts)+"</span></td>";
		}
		else
		if(wr==1)
		{
			tt+="<td class="+cl1+">Your request</td>";
		}
		else
		{
			tt+="<td class="+cl1+"><input type=\"button\" name=\"Submit\" value=\"Request\" class=\"wab\" onclick=\"return onRequstButtonClick('"+lt[i]+"')\"/>";
		}
		if(wr==1)
		{
			tt+="<td class="+cl2+">&nbsp;&nbsp;<span id=\"inrd"+rlc+"\">"+formatTimeDisp(wrta)+"</span></td>";
			rlA.push("inrd"+rlc);
			rlB.push(wrta*1);
			rlc++;
		}
		else
			tt+="<td class="+cl2+">&nbsp;&nbsp;</td>";
		tt+="</tr>";
	}
	tt+="</table>";
	watabled.innerHTML=tt;
	for(j=0;j<d;j+=2)
	{
		rlA[j/2]=document.getElementById(rlA[j/2]);
	}
	ilnpd=document.getElementById("ilnpd");
	pspan.innerHTML="Page "+(CurPage+1)+" of "+PageCount;
};

function rlist()
{
	xmlhttp.abort();
	xmlhttp.open("POST",WebJockeyAI,false);
	xmlhttp.setRequestHeader(wjct,wjctt);
	xmlhttp.send(CommonWebJockeyAIURL+"&Command=NowPlaying");
	var rt=xmlhttp.responseText;
	if(rt==""){return;}
	var npra=rt.split("\r\n");
	if(npra[0]!="NowPlayingReply"){return;}
	onps=npra[1];
	rwtd(onps,npra[3]);
}

function npt(du)
{
	delete now;
	var now = new Date();
	xmlhttp.abort();
	xmlhttp.open("POST",WebJockeyAI,false);
	xmlhttp.setRequestHeader(wjct,wjctt);
	xmlhttp.send(CommonWebJockeyAIURL+"&Command=NowPlaying");
	var rt=xmlhttp.responseText;
	if(rt==""){return;}
	var npra=rt.split("\r\n");
	if(npra[0]!="NowPlayingReply"){return;}
	npnd.innerHTML=npra[2];
	nptd.innerHTML=formatTimeDisp(npra[3]);
	if(onps!=npra[1] && !du)
	{
		onps=npra[1];
		rwtd(onps,npra[3]);
		skipbutton.onclick=onSkipButtonClick;
	}
	if(ilnpd!=null)
	{
		ilnpd.innerHTML=formatTimeDisp(npra[3]);
	}
	var rto=now.valueOf()-rlTime.valueOf();rto=(rto/1000).toFixed(0)*1;
	if(rlA!=null && rlA!=undefined)
	{
		for(i=0;i<rlA.length;i++)
		{
			if(rlA[i]!=null && rlA[i]!=undefined)
			{
				rlA[i].innerHTML=formatTimeDisp(rlB[i]+rto);
			}
		}
	}
	stu(du);
}
function loadXMLDoc()
{
	if (window.XMLHttpRequest)
	{
		xmlhttp=new XMLHttpRequest();
	}
	else
	{
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
}
window.onload=onBodyLoad;
-->
</script>
<title>BogProg WebJocky Example Radio Request Page</title>
<style type="text/css">
input { display: inline; }
button { display: inline; }
form { display: inline; }
td.BPWJWATD{
	border: 0px solid #000000;
	margin: 0px;
	border-collapse: collapse;
	border-spacing: 0px;
	padding: 0px;
}
tr.BPWJWATR{
	border: 0px solid #000000;
	margin: 0px;
	border-collapse: collapse;
	border-spacing: 0px;
}
td.BPWJWATD img{
	display: block;
}
.wae{
	border-left: 0px solid #000000;
	border-top: 0px solid #000000;
	border-right: 1px solid #75748B;
	border-bottom: 1px solid #75748B;
	background-color: black;
	font-family: arial;
	font-size: 8pt;
	padding: 0px;
	margin: 0px;
	height: 13px;
	display: inline;
	color: #00FF00;
}
table.BPWJWATABLE{
	border: 0px solid #000000;
	margin: 0px;
	border-collapse: collapse;
	border-spacing: 0px;
	background-color: black;
	color: #00FF00;
	font-family:"Arial", Arial, sans-serif;
	font-size: 11px;
}
.watable {
        border-top: #000000 solid 0px;
        border-left: #000000 solid 0px;
        border-bottom: #000000 solid 0px;
        border-right: #000000 solid 0px;
		padding: 0px;
		spacing: 0px;
		margin: 0px;
		cell-padding: 0px;
		cell-spacing: 0px;
		cell-margin: 0px;
	border-collapse: collapse;
	border-spacing: 0px;
}
.wab {
        border-right: #7B8494 solid 2px;
        border-top: #EFFFFF solid 1px;
        border-left: #EFFFFF solid 1px;
        border-bottom: #7B8494 solid 2px;
        background-color: #BDCED6;
		color: #2F374D;
		font-family: arial;
		font-size: 7pt;
		padding: 0px;
		margin: 0px;
		height: 15px;
		display: inline;
}
.cli {
	color: #00FF00;
	background: #000000;
	padding-right: 5px;
}
.clin {
	color: #FFFFFF;
	background: #000090;
	padding-right: 5px;
}
.clir {
	color: #00FF00;
	background: #000000;
	text-align: right;
}
.clirn {
	color: #FFFFFF;
	background: #000090;
	text-align: right;
}
</style>
</head>
<body>
<h1>BogProg WebJockey Example Radio Request Page</h1><br />
<br />
<?php
$fp = @fsockopen($WebJockeyIP,$WebJockeyPort,$errno,$errstr,$WJTimeout);
$JockeyName="";
$JockeyVersion="";
if($fp)
{
	$mess="";
	fwrite($fp,"Version\r\n\r\n");
    while (!feof($fp)) {
        $temp = @fgets($fp, 128);
		if(is_string($temp)){$mess = $mess . $temp;}
    }
	fclose($fp);
	$r=explode("\r\n",$mess);
	$JockeyName=$r[1];
	$JockeyVersion=$r[2];
}
?><h4>Song Request Interface Powered by <?php if($JockeyName!=""){ echo $JockeyName; }else { ?> BogProg WebJockey for Winamp<?php } ?> <?php if($JockeyVersion!=""){ echo $JockeyVersion; }else { ?>1.5<?php } ?></h4>
<?php
echo "Your reported IP address is <b>".getRealIpAddr(); ?></b><br />
<div class="Helper" style="background-color: #000000; position: absolute; display: none; width: 302px; " name="Helper" id="Helper">
<span id="HelperTitleBar" style="position: absolute; left: 1px; top: 1px; padding: 0px; spacing: 0px; display: inline-block; width: 300px; height: 15px; background: #BABAC6;"></span><br />
&nbsp;<span name="skipd" id="skipd" style="display: inline;"><form name="skipform" id="skipform" method="post" action="<?php echo $_SERVER['SCRIPT_NAME'] ?>"><input id="skipbutton" class="wab" type="submit" name="Submit" value="Skip" /><input type="hidden" name="Skip" value="<?php echo $npid ?>" /></form></span>&nbsp;<?php echo "<span style=\"display: inline;\" name=\"npd\" id=\"npd\">Now Streaming --> <b>Please wait...</b>&nbsp;</span>&nbsp;";?><?php echo "\n";?><br />
<br /><font color="#FFFFFF">
<span sytle="display: inline;" name="std" id="std"></font><br />
</div><?php
if($fp && isset($_POST['Request']))
if($_POST['Request']!="")
{
	$fp = @fsockopen($WebJockeyIP,$WebJockeyPort,$errno,$errstr,$WJTimeout);
	if($fp)
	{
		$Res="";
		fwrite($fp,"Request\r\n".getRealIpAddr()."\r\n".$_POST['Request']."\r\n\r\n");
		while (!feof($fp)) {
			$temp = @fgets($fp, 128);
			if(is_string($temp)){$Res = $Res . $temp;}
		}
		$r=explode("\r\n",$Res);
		$RR=ltrim(rtrim($r[1]));
		$temp="Unknown response from server.  Please inform the webmaster immediately.";
		if($RR=="MaxIPRequests"){$temp="You have reached the limit for requesting songs at your IP address.";}
		if($RR=="Queued"){$temp="Your request has resulted in a successful queue!";}
		if($RR=="AlreadyRequestedPlayed"){$temp="The song you requested has already been requested or has been recently played.";}
		if($RR=="AlreadyPlayedOrQueued"){$temp="The song you requested is already playing or is next to be played.";}
		if($RR=="MaxTotalRequests"){$temp="The server has reached a maximum request limit.  Please try again after a few songs have been played.";}
		if($RR=="RequestIDError"){$temp="The server could not find the song you requested.  Please refresh the play list and try again.";}
		if($RR=="RequestFormatError"){$temp="The server received an improperly formatted request!  Please inform the webmaster immediately!";}
		echo "<b>".$temp."</b><br /><br />";
		fclose($fp);
	}else echo "Service unavailable.<br /><br />";
}else if($_POST['Skip']!="")
{
	$fp = @fsockopen($WebJockeyIP,$WebJockeyPort,$errno,$errstr,$WJTimeout);
	if($fp)
	{
		$Res="";
		fwrite($fp,"SkipVote\r\n".getRealIpAddr()."\r\n".$_POST['Skip']."\r\n\r\n");
		while (!feof($fp)) {
			$temp = @fgets($fp, 128);
			if(is_string($temp)){$Res = $Res . $temp;}
		}
		$r=explode("\r\n",$Res);
		$RR=ltrim(rtrim($r[1]));
		$temp="Unknown response from server.  Please inform the webmaster immediately.";
		if($RR=="SkipVoteDisabled"){$temp="Voting to skip songs is disabled.";}
		if($RR=="SkipVoteAccepted"){$temp="Your request has resulted in a successful vote to skip!";}
		if($RR=="IPAlreadyVoted"){$temp="You already voted to skip the song.";}
		if($RR=="NotPlaying"){$temp="The song you voted to be skipped is not playing.";}
		if($RR=="SkipVoteIDError"){$temp="The server could not find the song you want skipped.  Please refresh the play list and try again.";}
		if($RR=="SkipVoteFormatError"){$temp="The server received an improperly formatted request!  Please inform the webmaster immediately!";}
		echo "<b>".$temp."</b><br /><br />";
		fclose($fp);
	}else echo "Service unavailable.<br /><br />";
}//else echo " <br /><br />";
?></span><a href="<?php echo $_SERVER['SCRIPT_NAME']; ?>">Refresh</a><?php
$fp = @fsockopen($WebJockeyIP,$WebJockeyPort,$errno,$errstr,$WJTimeout);
$np="";
$npid="";
if($fp)
{
	$mess="";
	fwrite($fp,"NowPlaying\r\n\r\n");
    while (!feof($fp)) {
        $temp = @fgets($fp, 128);
		if(is_string($temp)){$mess = $mess . $temp;}
    }
	fclose($fp);
	?><br /><?php
	$r=explode("\r\n",$mess);
	$np=rtrim($r[2]);
	$npid=rtrim($r[1]);
	$npt=formatTimeDisp(rtrim($r[3])*1);
}
$RequestedSongsHash;
$RequestCount=0;
?><?php
if($fp)
$fp = @fsockopen($WebJockeyIP,$WebJockeyPort,$errno,$errstr,$WJTimeout);
if($fp)
{
	$Res="";
	fwrite($fp,"RequestList\r\n".getRealIpAddr()."\r\n\r\n");
    while (!feof($fp)) {
        $temp = @fgets($fp, 128);
		if(is_string($temp)){$Res = $Res . $temp;}
    }
	fclose($fp);
	$RL=explode("\r\n",$Res);
	if($RL[0]=="RequestListListing")
	{
		$i=1;
		while($RL[$i]!="EndRequestListListing")
		{
			$RequestedSongsHash[$RL[$i]]=$RL[$i+1];
			$RequestCount++;
			$i+=2;
		}
	}
}
if($fp)
$fp = @fsockopen($WebJockeyIP,$WebJockeyPort,$errno,$errstr,$WJTimeout);
if($fp)
{
	?><form method="post" name="searchform" id="searchform" action="<?php echo $_SERVER['SCRIPT_NAME'] ?>"><input class="wae" type="edit" name="searchedit" id="searchedit" /><input class="wab" type="submit" name="searchbutton" id="searchbutton" value="Search" /></form><br />
	<input class="wab" type="button" name="prevpagebutton" id="prevpagebutton" value="<- Prev"/><span name="pspan" id="pspan">Page 1 of 1</span><input class="wab" type="button" name="nextpagebutton" id="nextpagebutton" value="Next ->"/><br/><table class="BPWJWATABLE">
<tr class="BPWJWATR"><td class="BPWJWATD" colspan="3" style="min-width: 275px;">
<table class="BPWJWATABLE" width="100%"><tr class="BPWJWATR"><td class="BPWJWATD" style="background-image: url('WATS.gif');"><img src="WATL.gif" /></td><td class="BPWJWATD" align="center" style="background-image: url('WATS.gif');"><img src="WATC.gif" /></td><td class="BPWJWATD" align="right" style="background-image: url('WATS.gif');"><img src="WATR.gif" /></td></tr></table>
</td></tr>
<tr class="BPWJWATR"><td class="BPWJWATD" style="width: 11px;background-image: url('WAL.gif');"><img src="WAL.gif" /></td>

<td class="BPWJWATD" style="background-image: url('WABG.gif');vertical-align: top; min-width: 245px; min-height: 58px;" nowrap="nowrap"><span style="display: inline;" id="watabled" name="watabled"><table summary="" class="watable" style="background: #000000; color: #00FF00; font-family: arial; font-size: 8pt">
<?php
	$mess="";
	fwrite($fp,"List\r\n\r\n");
    while (!feof($fp)) {
        $temp = @fgets($fp, 128);
		if(is_string($temp)){$mess = $mess . $temp;}
    }
	fclose($fp);
	$r=explode("\r\n",$mess);
	$i=1;
	$plsn=1;
	while($r[$i]!="EndListing")
	{
		$cli=" class=\"cli\"";
		$cli2=" class=\"clir\"";
		$id=rtrim($r[$i]);
		$inp=($npid==$id);
		$title=rtrim($r[$i+1]);
		$time=formatTimeDisp(trim($r[$i+2]));
		$rst="";
		if(isset($RequestedSongsHash[$id]))
		{
			$rst=formatTimeDisp($RequestedSongsHash[$id]);
		}
		$rbc="";
		if($inp){$cli=" class=\"clin\"";$cli2=" class=\"clirn\"";}
		echo "<tr><td$cli>$plsn. $title</td><td$cli2>$time</td><td$cli>";
		if($inp)
		{
			?><b>Now Streaming</b> <?php echo "$npt";
		}
		else if(isset($RequestedSongsHash[$id])){echo "Your request";} else
		{
			?><form method="post" action="<?php echo $_SERVER['SCRIPT_NAME'] ?>"><input type="submit" name="Submit" value="Request" class="wab" /><input type="hidden" name="Request" value="<?php echo $id ?>" /></form><?php 
		}
		echo "</td><td$cli2>&nbsp;&nbsp;$rst</td></tr>\n";
		$i+=3;
		$plsn++;
	}
	?></table></span></td>

<td class="BPWJWATD" style="width: 19px;background-image: url('WAR.gif');" align="right"><img src="WAR.gif" /></td></tr>
<tr class="BPWJWATR"><td class="BPWJWATD" colspan="3">
<table class="BPWJWATABLE" width="100%"><tr class="BPWJWATR"><td class="BPWJWATD" style="height: 38px;background-image: url('WABS.gif');"><img src="WABL.gif" /></td><td class="BPWJWATD" style="height: 38px;background-image: url('WABS.gif');" align="right"><img src="WABR.gif" /></td></tr></table>
</td></tr>
</table><?php
}
if($fp)
$fp = @fsockopen($WebJockeyIP,$WebJockeyPort,$errno,$errstr,$WJTimeout);
if($fp)
{
	$Res="";
	fwrite($fp,"Settings\r\n".getRealIpAddr()."\r\n\r\n");
    while (!feof($fp)) {
        $temp = @fgets($fp, 128);
		if(is_string($temp)){$Res = $Res . $temp;}
    }
	fclose($fp);
	$SL=explode("\r\n",$Res);
	$SettingsHash;
	if($SL[0]=="SettingsReply")
	{
		$i=1;
		while($SL[$i]!="")
		{
			$SettingsHash[$SL[$i]]=$SL[$i+1];
			$i+=2;
		}
		if($RequestCount>=$SettingsHash['IPMaxRequests'])
		{
			if($SettingsHash['IPMaxRequests']!=0){$more="more";}
			echo "<b>You can not make any$more requests at this time.</b><br />\r\n";
		}
		else if($RequestCount<$SettingsHash['IPMaxRequests'] && $RequestCount!=0)
		{
			echo "<b>You can make ".($SettingsHash['IPMaxRequests']-$RequestCount)." more request(s).</b><br />\r\n";
		}
		else
		{
			echo "<b>You can make ".($SettingsHash['IPMaxRequests']-$RequestCount)." request(s).</b><br />\r\n";
		}
		if(isset($RequestedSongsHash) && is_array($RequestedSongsHash))
		{
			$in=1;
			$RequestTimes = array_values($RequestedSongsHash);
			sort($RequestTimes,SORT_NUMERIC);
			while(count($RequestTimes)>$SettingsHash['IPMaxRequests']){array_pop($RequestTimes);$in++;}
			rsort($RequestTimes,SORT_NUMERIC);
			$in+=($SettingsHash['IPMaxRequests']-$RequestCount);
			foreach($RequestTimes as $RequestTime)
			{
				$i=$SettingsHash['TimeLimit']-$RequestTime;
				echo "You can make $in more request(s) in ".formatTimeDispE($i)."<br />\r\n";
				$in++;
			}
		}
		//echo $SettingsHash['IPMaxRequests']."<br />\r\n";
		//echo $SettingsHash['TimeLimit']."<br />\r\n";
	}
}
/*$r=@$scinfo["SHOUTCASTSERVER"]["REPORTEDLISTENERS"];
if(!isset($r)){$r="0";}
if($fp)
{
	echo "Current number of listeners: $r";
}*/
?>
</body>
</html>
