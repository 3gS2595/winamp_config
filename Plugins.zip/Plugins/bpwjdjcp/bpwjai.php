<?php
//error_reporting(0);
session_start();
$djpw=(array_key_exists("djpw",$_SESSION)?$_SESSION["djpw"]:"");
if(!file_exists("bpwjdjcpconfig.php"))
{
	$salt=generatePassword();
	$password=strtoupper(sha1($salt."changeme"));
	if(!setDjSalt($salt))
	{
		echo "Error\r\n\r\n";
		return;
	}
	if(!setDjPassword($password))
	{
		echo "Error\r\n\r\n";
		return;
	}
}
require 'bpwjdjcpconfig.php';
$djauth=($djpw==$djpassword);
if(!isset($opensslcnffile) || $opensslcnffile=="" || !is_file($opensslcnffile))
{
	$rr=IncludeTrailingPathDelimiter(realpath(__DIR__));
	$rf=$rr."openssl.cnf";
	if(!is_file($rf))
	{
		CreateCNF($rf);
		if(!is_file($rf))
		{
			return;
		}
	}
	setopensslcnffile($rf);
	$opensslcnffile=$rf;
}
if(!array_key_exists("RSAPrivKey",$_SESSION))
{
	$config=array(
		"digest_alg" => "sha512",
		"private_key_bits" => 2048,
		"private_key_type" => OPENSSL_KEYTYPE_RSA,
	);
	if(isset($opensslcnffile) && $opensslcnffile!="")
	{
		$config["config"]=$opensslcnffile;
	}
	$arf=openssl_pkey_new($config);
	function to_hex($data)
	{
		return strtoupper(bin2hex($data));
	};
	if($arf!==FALSE)
	{
		$_SESSION["RSAPrivKey"]=$arf;
		$privKey="";
		$pubKey="";
		openssl_pkey_export($arf,$privKey,NULL,$config);
		$_SESSION["RSAPrivKey"]=$privKey;
		$pub=openssl_pkey_get_details($arf);
		$pub1=to_hex($pub['rsa']['n']);
		$pub2=to_hex($pub['rsa']['e']);
		$pub="$pub1,$pub2";
		$_SESSION["RSAPubKey"]=$pub;
	}
}
function RSADecryptText($encrypted)
{
	if(!array_key_exists("RSAPrivKey",$_SESSION))
	{
		return NULL;
	}
	$privKeyRes=openssl_pkey_get_private($_SESSION["RSAPrivKey"]);
	if($privKeyRes===FALSE)
	{
		return NULL;
	}
	$encrypted=pack('H*',$encrypted);
	$res="";
	$suc=openssl_private_decrypt($encrypted,$res,$privKeyRes);
	if(!$suc)
	{
		return NULL;
	}
	return $res;
}
if(isset($_GET['file']))
{
	if($_GET['file']=="favicon")
	{
		$ol=base64_decode("AAABAAMAMDAAAAEAIACoJQAANgAAACAgAAABACAAqBAAAN4lAAAQEAAAAQAgAGgEAACGNgAAKAAAADAAAABgAAAAAQAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEm28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/0m28P9ftvD/dqXY/3al2P92pdj/dqXY/2CGr/8vQVb/LT9S/y0/Uv8tP1L/LT9S/y0/Uv8tP1L/LT9S/zRJYP9sl8b/dqXY/3ak1/9EX33/LT9S/y0/Uv8tP1L/LT9S/y0/Uv8tP1L/LT9S/y0/Uv8/WXT/dKLV/3al2P92pdj/cqDR/2WOuv9ObY7/RF99/y9BVv8tP1L/OE5m/05tjv9iibT/c6HT/3al2P92pdj/dqXY/3al2P92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+NksD/jZLA/0tNZv8AAAD/AAAA/wAAAP8AAAD/AAAA/wAAAP8AAAD/AAAA/wICA/9gZIP/jZLA/4WKtf8bGyT/AAAA/wAAAP8AAAD/AAAA/wAAAP8AAAD/AAAA/wAAAP8SExn/f4St/4uQvv9fYoL/Jyg1/w4PFP8BAQH/AAAA/wAAAP8AAAD/AAAA/wEBAf8LCw7/LC07/2Zpi/+LkL7/jZLA/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/l36l/y4nM/8BAQH/VmBm/36Mlf9+jJX/foyV/36Mlf9+jJX/QkpO/wAAAP8/NUX/mYCo/39qjP8LCg3/Jist/3uIkf9+jJX/foyV/36Mlf9+jJX/eIaO/x4iJP8FBAX/cF57/1pLY/8IBwn/BQUG/zA1OP9WYGb/e4iR/36Mlf9+jJX/dYKK/0BITP8TFRf/AAAA/w0LDv9tW3f/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/lmKC/xUOE/8OERL/obrI/8Lg8P/C4PD/wuDw/8Lg8P/C4PD/h5yo/wMEBP8hFRz/m2aG/2ZDWf8BAAH/W2lx/8Lg8P/C4PD/wuDw/8Lg8P/C4PD/wuDw/1BcY/8AAAD/NCIt/wgGB/8YGx3/dIaQ/7fU4//C4PD/wuDw/8Lg8P/C4PD/wuDw/7/c7P+husj/Tlpg/wgJCf8ZEBX/fmmK/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/glVw/wgEBf8iKSz/sNLj/7re8P+63vD/ut7w/7re8P+63vD/p8fY/xgdH/8HBAX/g0JY/zkdJv8DAwT/gpuo/7re8P+63vD/ut7w/7re8P+63vD/ut7w/3OJlP8AAAD/BgME/wQFBv94kJv/ut7w/7re8P+63vD/ut7w/7re8P+63vD/ut7w/7re8P+63vD/ttnq/2p+iP8EBQb/KSIt/4CErv92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/YkBV/wAAAP8/Tlb/sNrv/7Hb8P+x2/D/sdvw/7Hb8P+x2/D/rtjs/zhGTP8AAAD/UiAr/xkKDf8XHB//n8XY/7Hb8P+x2/D/sdvw/7Hb8P+x2/D/sdvw/4ytvf8JCwz/AAAA/yw2O/+nz+P/sdvw/7Hb8P+x2/D/sdvw/7Hb8P+x2/D/sdvw/7Hb8P+x2/D/sdvw/6fP4/8sNjv/AQEB/1dadv92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+Yf6f/Oycz/wAAAP9jgI3/qdnw/6nZ8P+p2fD/qdnw/6nZ8P+p2fD/qdnw/2eFk/8BAQH/DwUG/wMBAf8zQkj/ptbs/6nZ8P+p2fD/qdnw/6nZ8P+p2fD/qdnw/5zJ3v8cJSj/AwME/26NnP+p2fD/qdnw/6nZ8P+p2fD/qdnw/5nF2f+bx9z/qdnw/6nZ8P+p2fD/qdnw/6nZ8P9hfYr/AAAA/zg6TP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ReZ//HxUb/wcJCv99qLv/oNfw/6DX8P+g1/D/oNfw/6DX8P+g1/D/oNfw/4WzyP8MEBL/AAAA/wAAAP9XdIL/oNfw/6DX8P+g1/D/oNfw/6DX8P+g1/D/oNfw/5/W7/83SVL/DBAS/4e1yv+g1/D/oNfw/6DX8P+g1/D/j8DX/yUyOP8yQ0v/ms/n/6DX8P+g1/D/oNfw/6DX8P93n7L/BQcI/yssOv90otX/X7bw/0m28P9ftvD/dqXY/42SwP9/aoz/DAgL/xQcH/+Jv9j/mNXw/5jV8P+Y1fD/mNXw/5jV8P+Y1fD/mNXw/5LN5/8mNTz/AAAA/wgLDP94qL3/mNXw/5jV8P+Y1fD/mNXw/5jV8P+Y1fD/mNXw/5jV8P9QcX//Fh8j/3ipvv+QyeP/kczm/5jV8P+Y1fD/ZIye/wEBAf8LEBL/gLTK/5jV8P+Y1fD/mNXw/5jV8P99r8X/CAsM/xYXHv9tmcj/X7bw/0m28P9ftvD/dqXY/42SwP9lVG//AQAB/ytASP+N0Oz/j9Pw/4/T8P+P0/D/j9Pw/4/T8P+P0/D/j9Pw/4/T8P9DY3H/AAAA/xgkKP+Ew97/j9Pw/4/T8P+P0/D/j9Pw/4/T8P+P0/D/j9Pw/4/T8P9qnLL/BQcI/wsQEv8ZJCn/Hy41/zVOWP9DY3H/N1Fc/wAAAP8HCwz/da3F/4/T8P+P0/D/j9Pw/4/T8P98uNH/DhUY/wgIC/9iibP/X7bw/0m28P9ftvD/dqXY/42SwP9IPE//AAAA/0Bicf+H0PD/h9Dw/4fQ8P+H0PD/h9Dw/4XO7f+H0PD/h9Dw/4fQ8P9kmrL/BAcI/zBKVv+Gz+//h9Dw/4fQ8P+H0PD/hc7t/4fQ8P+H0PD/h9Dw/4fQ8P92tdH/DRQY/wMAAP8LAAD/CAAA/wAAAP8AAAD/AAAA/wAAAP8HCwz/b6rF/4fQ8P+H0PD/h9Dw/4fQ8P+AxeT/GCYr/wcHCv9hh7H/X7bw/0m28P9ftvD/dqXY/4mNuv8oISv/AgME/1iQqP9+zvD/fs7w/37O8P9+zvD/eMPk/2Oivf9+zvD/fs7w/37O8P9xudj/Ex8k/01+k/9+zvD/fs7w/37O8P92wOD/Z6jE/37O8P9+zvD/fs7w/37O8P96yOj/ITU+/wQAAP+SAAD/vQAA/54AAP94AAD/XAAA/xEAAP8GCwz/Z6nF/37O8P9+zvD/fs7w/37O8P94w+T/FyUr/wcHCv9hh7H/X7bw/0m28P9ftvD/dqXY/3t/p/8QDRH/DBQY/2ey0f92zPD/dszw/3bM8P92zPD/Y6zK/zNYaP92y+//dszw/3bM8P92y+//N15v/2KqyP92zPD/dszw/3bM8P9dob3/Pmp9/3bM8P92zPD/dszw/3bM8P92zPD/OGBx/wAAAP94AAD//wAA//8AAP//AAD/8gAA/y4AAP8GCgz/YafF/3bM8P92zPD/dszw/3bM8P9wwuT/FSUr/wcHCv9hh7H/X7bw/0m28P9ftvD/dqXY/2lsjv8FBAX/GCw1/2nB5v9uyvD/bsrw/27K8P9uyvD/TY2o/xUmLf9mu97/bsrw/27K8P9uyvD/WqbF/2jA5P9uyvD/bsrw/27K8P9Bd43/HDQ+/2vE6P9uyvD/bsrw/27K8P9uyvD/SIWe/wABAf9NAAD/+wAA//8AAP//AAD/8gAA/y4AAP8GCgz/WqbF/27K8P9uyvD/bsrw/27K8P9owOT/FCQr/wcHCv9hh7H/X7bw/0m28P9ftvD/dqXY/0tNZv8AAAD/KlJj/2bI8P9myPD/Zsjw/2bI8P9myPD/Nmp//wUKDP9Qnr3/Zsjw/2bI8P9myPD/Zcbt/2bI8P9myPD/Zsjw/2bH7/8kR1b/DRof/1y02P9myPD/Zsjw/2bI8P9myPD/VabI/wgPEv8fAAD/2gAA//cAAP//AAD/8gAA/y4AAP8FCgz/VKTF/2bI8P9myPD/Zsjw/2bI8P9hvuT/EiQr/wcHCv9hh7H/X7bw/0m28P9ftvD/dqTX/zAyQv8AAAD/OXqU/13G8P9dxvD/Xcbw/13G8P9cw+z/HDxI/wAAAP83dI3/Xcbw/13G8P9dxvD/Xcbw/13G8P9dxvD/Xcbw/1Sy2P8NHCL/BAkK/0mbu/9dxvD/Xcbw/13G8P9dxvD/WLvj/xEkLP8CAQH/JAoK/1kICP/3AAD/8gAA/y4AAP8FCgz/TKLF/13G8P9dxvD/Xcbw/13G8P9YvOT/ESQr/wcHCv9hh7H/X7bw/0m28P9ftvD/bZnI/xgZIP8ECgz/Q5q9/1XE8P9VxPD/VcTw/1XE8P9Ptd7/DR8m/wAAAP8bPkz/VMHs/1XE8P9VxPD/VcTw/1XE8P9VxPD/VcTw/z+Rsv8DBgj/AAAA/zJzjf9VxPD/VcTw/1XE8P9VxPD/VcPv/x5GVv8AAAD/MDAw/ygMDP/yAAD/8gAA/y4AAP8ECgz/RqHF/1XE8P9VxPD/VcTw/1XE8P9RuuT/DyMr/wcHCv9hh7H/X7bw/0m28P9ftvD/XYKq/wcHCv8NISj/R7Te/03C8P9NwvD/TcLw/03C8P8/ncP/BAsN/wAAAP8KGR//Ra7Y/03C8P9NwvD/TcLw/03C8P9NwvD/TcLw/ylnf/8AAAD/AAAA/x5LXP9NwvD/TcLw/03C8P9NwvD/TcLw/y1yjf8AAAD/JSUl/ygMDP/yAAD/8gAA/y4AAP8ECgz/P5/F/03C8P9NwvD/TcLw/03C8P9JuOT/DiMr/wcHCv9hh7H/X7bw/0m28P9ftvD/SWaF/wAAAP8YQlL/Rb/v/0XA8P9FwPD/RcDw/0XA8P8se5r/AAEB/wAAAP8CBgj/M46y/0XA8P9FwPD/RcDw/0XA8P9FwPD/RL3s/xU6SP8AAAD/AAAA/w8qNf9CuOb/RcDw/0XA8P9FwPD/RcDw/zaWu/8DCAr/FBQU/yYLC//yAAD/8gAA/y4AAP8ECgz/OZ3F/0XA8P9FwPD/RcDw/0XA8P9BtuT/DCMr/wcHCv9hh7H/X7bw/0m28P9ftvD/MURZ/wAAAP8gZX//PL7w/zy+8P88vvD/PL7w/zy+8P8ZUGb/AwMD/xEREf8AAAD/IGV//zy+8P88vvD/PL7w/zy+8P88vvD/NqvY/wgZH/8AAAD/AQAA/wYTGP80pdH/PL7w/zy+8P88vvD/PL7w/zar2P8IGR//CAgI/yEKCv/yAAD/8gAA/y4AAP8DCgz/MZzF/zy+8P88vvD/PL7w/zy+8P85tOT/CyIr/wcHCv9hh7H/X7bw/0m28P9brub/GiQv/wIGCP8kg6j/MbLk/zGy5P8xsuT/MbLk/zCt3P8NLzz/Dg4O/05OTv8AAAD/DzhI/zCv3/8xsuT/MbLk/zGy5P8xsuT/JYWq/wIGCP8EAwP/FQEB/wEDBP8ifZ//MbLk/zGy5P8xsuT/MbLk/zCv3/8PNUT/AAAA/xoICP/yAAD/8gAA/y4AAP8DCgz/KJG5/zGy5P8xsuT/MbLk/zGy5P8vqdj/CSAp/wcHCv9hh7H/X7bw/0m28P9TntH/DBEW/wABAf8HHCT/CCIr/wgiK/8IIiv/CCIr/wggKf8BBQf/JSUl/4qKiv8CAgL/AQUH/wggKf8IIiv/CCIr/wgiK/8IIiv/BRQa/wAAAP8UEhL/KAQE/wAAAP8FFBr/CCIr/wgiK/8IIiv/CCIr/wgiK/8DDBD/AAAA/xMGBv/yAAD/8gAA/y4AAP8AAQH/Bxwk/wgiK/8IIiv/CCIr/wgiK/8IICn/AQUH/wcHCv9hh7H/X7bw/0m28P9Eg6z/CAwP/wcHCv8IBwn/BwUG/wEBAf8JCQn/CwsL/wsLC/8LCwv/TExM/7S0tP8LCAj/BgAA/wEBAf8ICAj/CQkJ/wkJCf8ICAj/CAgI/wsLC/8pJib/PQcH/xEAAP8CAQH/BwcH/wsLC/8LCwv/CwsL/woKCv8KCgr/BgYG/wwEBP/qAAD/8gAA/zoAAP8MAQH/DAIC/wsCA/8KAwT/CgQF/wkFBv8IBgf/CAcJ/w4PFP9iibP/X7bw/0m28P9ZquD/YYex/3R4nf99aYr/b0lh/xEPEP+YmJj/tra2/7Ozs/+urq7/uLi4/8HBwf8hGhr/WwQE/xIKCv99fX3/lJSU/4+Pj/+Li4v/h4eH/4SEhP87Njb/VwoK/8gAAP8kDQ3/c3Nz/7a2tv+wsLD/rKys/6mpqf+lpaX/ZGRk/yMLC//xAAD//gAA/9kAAP/GDBD/vBkh/7ImMf+nMkL/nT5S/5NLYv+IWXb/fWmK/3V5n/9zoNL/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xUSE/+9vb3/4+Pj/97e3v/a2tr/1NTU/8TExP8mHh7/bwUF/xYMDP+cnJz/ubm5/7W1tf+vr6//qqqq/6Kiov8yLi7/cA0N//IAAP8tERH/j4+P/+Li4v/e3t7/19fX/9LS0v/Ozs7/fX19/yoODv/yAAD//wAA//8AAP/yDxT/5R4o/9kuPP/MPVD/v0xk/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xYTFP/BwcH/5+fn/+Pj4//e3t7/2tra/8nJyf8nHx//bwUF/xYMDP+fn5//vr6+/7m5uf+1tbX/r6+v/6Ghof8iGhr/rQgI//IAAP8tERH/kpKS/+fn5//i4uL/3t7e/9fX1//S0tL/gICA/xkICP+ZAAD/yQAA/+wAAP/mDhP/5B4o/9kuPP/MPVD/v0xk/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xYTFP/FxcX/6+vr/+fn5//j4+P/3t7e/8/Pz/8oICD/UAYG/xoREf+np6f/wsLC/76+vv+5ubn/tbW1/5GRkf8kFBT/3QIC//IAAP8tERH/lZWV/+vr6//n5+f/4uLi/97e3v/X19f/qKio/zMlJf8nFhb/JxYW/ywXF/8rERH/VhYZ/6olL//MPVD/v0xk/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xYTFP/IyMj/8PDw/+vr6//n5+f/4+Pj/9vb2/9mXl7/NCMj/3RwcP/Jycn/xsbG/8LCwv++vr7/ra2t/1ZOTv8+DAz/9wAA//IAAP8uEhL/l5eX//Dw8P/r6+v/5+fn/+Li4v/e3t7/19fX/8nJyf/Dw8P/tbW1/5qamv92dnb/Pzg4/yATFP+ZMj//v0xk/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xcUFf/MzMz/9PT0//Dw8P/r6+v/5+fn/+Pj4//b29v/0dHR/9TU1P/Pz8//y8vL/8HBwf+MjIz/MCws/yELC/+oAQH//wAA//IAAP8uEhL/mpqa//T09P/w8PD/6+vr/+fn5//i4uL/3t7e/9fX1//S0tL/zs7O/8nJyf/FxcX/uLi4/19dXv8sGBv/r0Zc/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xYTFP/R0dH/+fn5//T09P/w8PD/6+vr/+fn5//j4+P/3t7e/9ra2v/U1NT/z8/P/46Ojv8NCgr/IQkJ/7kBAf//AAD//wAA//IAAP8uEhL/nZ2d//n5+f/09PT/8PDw/+vr6//n5+f/4uLi/97e3v/X19f/0tLS/87Ozv/Jycn/xcXF/5ubm/8UDxD/nEBT/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xYTFP/Nzc3///////n5+f/09PT/8PDw/+vr6//g4OD/19fX/9vb2//a2tr/1NTU/7+/v/9ycXH/KiEh/ywREf+kBgb//wAA//IAAP8tERH/m5ub//39/f/5+fn/9PT0//Dw8P/r6+v/vLy8/1tSUv93dHT/0tLS/9LS0v/Ozs7/ycnJ/7Kysv8dGRr/hTlJ/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xYTFP/Jycn/+vr6///////5+fn/9PT0/+jo6P9YUlL/LyEh/2pnZ//b29v/2tra/9TU1P/Pz8//vb29/2xqav8xEhL/7gAA//IAAP8tERH/mJiY//r6+v/9/f3/+fn5//T09P/w8PD/kpKS/wEAAP8TDQ3/ubm5/9fX1//S0tL/zs7O/8DAwP8sKCn/bjVB/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xUSE//FxcX/9fX1//r6+v//////+fn5/+jo6P8sJCT/UAcH/x8WFv/Gxsb/3t7e/9ra2v/U1NT/z8/P/7Gxsf8gFxf/xwcH//IAAP8tERH/lZWV//X19f/6+vr//f39//n5+f/09PT/lZWV/xoJCf8aDQ3/lZWV/97e3v/X19f/0tLS/87Ozv9LSEj/TCcv/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xUSE//BwcH/8PDw//X19f/6+vr//////+zs7P8tJSX/cAYG/xgODv+9vb3/4+Pj/97e3v/a2tr/1NTU/8bGxv8uKCj/kg8P//IAAP8sEBD/kpKS//Dw8P/19fX/+vr6//39/f/5+fn/l5eX/yAMDP8gDAz/j4+P/+Li4v/e3t7/19fX/9LS0v9PTEz/SiYt/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xUSE/+9vb3/6+vr//Dw8P/19fX/+vr6//Ly8v8tJSX/cAYG/xkPD//BwcH/5+fn/+Pj4//e3t7/2tra/9TU1P9OSUn/YQ0N//IAAP8sEBD/j4+P/+vr6//w8PD/9fX1//r6+v/9/f3/mpqa/yAMDP8gDAz/kpKS/+fn5//i4uL/3t7e/9fX1/9PTU3/SiYt/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xQREv+5ubn/5+fn/+vr6//w8PD/9fX1/+3t7f8tJib/agwO/xkQEP/FxcX/6+vr/+fn5//j4+P/3t7e/9fX1/9CNzf/Zg0P/+YOE/8rEhL/jIyM/+fn5//r6+v/8PDw//X19f/6+vr/nZ2d/x4NDv8dDw//mJiY/+vr6//n5+f/4uLi/97e3v9RS0z/SiQs/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xQREv+1tbX/4uLi/+fn5//r6+v/8PDw/+np6f8sJib/Pw0P/xoTFP/Ozs7/8PDw/+vr6//n5+f/4+Pj/9LS0v8mICD/ihge/9kcJv8oEhT/iYmJ/+Li4v/n5+f/6+vr//Dw8P/19fX/m5ub/wYCA/8WDxD/xMTE//Dw8P/r6+v/5+fn/97e3v9COjv/Wicy/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xQREv+xsbH/3d3d/+Li4v/n5+f/6+vr/+jo6P9OSkv/Jh0e/5aSkv/29vb/9PT0//Dw8P/r6+v/5+fn/7a2tv8XExP/oycx/84sOf8nFBb/hoaG/93d3f/i4uL/5+fn/+vr6//w8PD/sbGx/yQfIP9wamr/7+/v//T09P/w8PD/6+vr/9ra2v8mIiL/dzRC/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xQQEf+rq6v/2NjY/93d3f/i4uL/5+fn/+vr6//c3Nz/3d3d//n5+f//////+fn5//T09P/w8PD/6urq/2poaf81HSD/wTpM/8I6TP8lFRf/g4OD/9jY2P/d3d3/4uLi/+fn5//r6+v/7e3t/9vb2//5+fn//f39//n5+f/09PT/8PDw/7Gxsf8VEBH/jztM/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xQQEf+np6f/0dHR/9jY2P/d3d3/4uLi/+fn5//r6+v/8PDw//X19f/6+vr///////n5+f/q6ur/ioqK/xYREv93M0H/v0xk/7VIX/8jFxn/fn5+/9PT0//Y2Nj/3d3d/+Li4v/n5+f/6+vr//Dw8P/19fX/+vr6//39/f/5+fn/6Ojo/01JSv9EJiz/uElg/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xQQEf+ampr/wsLC/8bGxv/Nzc3/0tLS/9bW1v/d3d3/6+vr/+bm5v/p6en/4eHh/8fHx/9eXF3/FBAR/2c4R/+sV3P/s1t4/6pWcv8hFxv/dHR0/8LCwv/IyMj/zc3N/9LS0v/W1tb/29vb/+rq6v/m5ub/6enp/+fn5/+6urr/T01O/yEZHP+US2P/s1t4/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/jFx5/xAND/8cGhv/IyEj/yMhI/8kIiT/JSMk/yYkJf8vLS7/TkpN/zEvMP8tKy3/KCUn/x4ZHP8zJy7/eVFp/6Rsjv+mbZD/pm2Q/59oiv8pICX/FRQU/yIgIv8jISP/JCIk/yUjJP8mJCX/Kigp/0hFR/8xLzD/MC4v/y4qLf8YFRf/QDE6/4NXcv+mbZD/pm2Q/6ZtkP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/l36m/29eef9gUWn/YFFp/2BRaf9hUmn/YVJp/2FSaf9hUmr/YVJq/2FTav9uXXj/fmqL/4Vvkv+UfKP/mYCo/5mAqP+ZgKj/mYCo/5mAqP97Z4f/YFFp/2BRaf9gUWn/YVJp/2FSaf9hUmn/YVJq/2FSav9hU2r/dWN//35qi/+BbI7/lX2k/5mAqP+ZgKj/mYCo/5mAqP+ZgKj/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+NksD/jZLA/42SwP+NksD/jZLA/42SwP+NksD/jZLA/42SwP+NksD/jZLA/42SwP+NksD/jZLA/42SwP+NksD/jZLA/42SwP+NksD/jZLA/42SwP+NksD/jZLA/42SwP+NksD/jZLA/42SwP+NksD/jZLA/42SwP+NksD/jZLA/42SwP+NksD/jZLA/42SwP+NksD/jZLA/42SwP+NksD/jZLA/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/3al2P92pdj/dqXY/3al2P92pdj/dqXY/3al2P92pdj/dqXY/3al2P92pdj/dqXY/3al2P92pdj/dqXY/3al2P92pdj/dqXY/3al2P92pdj/dqXY/3al2P92pdj/dqXY/3al2P92pdj/dqXY/3al2P92pdj/dqXY/3al2P92pdj/dqXY/3al2P92pdj/dqXY/3al2P92pdj/dqXY/3al2P92pdj/dqXY/3al2P92pdj/X7bw/0m28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/wAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/SgAAAAgAAAAQAAAAAEAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABLtvD/ULbw/1C28P9QtvD/S63k/0qr4f9Kq+H/Sanf/0qq4f9Kq+H/S63k/0+07v9Osuv/Sqvi/0qr4f9Jqd//Sqvh/0qr4f9Kq+H/TbHp/1C28P9QtvD/T7Tu/02x6f9Kq+H/S6vi/0+z7f9Qte//ULbw/1C28P9QtvD/ULbw/1C28P9pruX/bqrg/2un2/8pR17/HjdJ/x43Sf8cNEX/HTZI/x43Sf8qSWH/YJbF/0x6oP8gOkz/HjdJ/xw0Rf8eN0n/HjdJ/x44Sv9DbpD/a6fb/1uQvP84X33/KEhf/x43Sf8fOUz/MVVw/0t5n/9ppNj/bqrg/26q4P9ksur/ULbw/26q4P+OkL3/fXmf/wUFB/8TFRb/Ki4x/youMf8qLjH/HCAh/wkJDP9hX33/NjVG/wgJCv8pLTD/Ki4x/youMf8oLTD/BgcI/yQkMP86Ok3/BwgK/xQWF/8kKCv/Ki4x/ygsL/8QEhP/AwMD/y0uPP93dZr/hZjI/2aw6P9QtvD/bqrg/5GMuP9tVXD/AwQE/11rc/+rxNH/q8TR/6vE0f+Dl6H/AgID/0UyQ/8cFRv/MDg8/6rD0P+rxNH/q8TR/6rC0P8qMDT/CQcK/wsKDP86Qkf/kKay/6a+y/+rxNH/qcHP/4mdqP9IU1n/BgYH/zIqN/+Bk8L/ZrDo/1C28P9uquD/joq1/0s6TP8OERP/g5+t/7fd8P+33fD/t93w/63S5P8XHB7/CwUH/wYFBv9gdH//t93w/7fd8P+33fD/t93w/1Nkbf8BAQH/OEVL/6fK2/+33fD/t93w/7fd8P+33fD/t93w/7Xa7f9abXb/BggI/05ffP9lruX/ULbw/26q4P+Gg6z/LyYz/x0lKP+Ptsj/q9nw/6vZ8P+r2fD/q9nv/zpKUv8AAAD/DRET/3ucrP+r2fD/q9nw/6vZ8P+r2fD/a4mW/wgKDP9ykaH/qtju/6vZ8P+r2fD/oczh/6jV6/+r2fD/q9nw/4qwwv8aISX/KTdI/2Cn3f9QtvD/bqrg/3d2nP8ZFRz/MkRM/5PJ4f+d1vD/ndbw/53W8P+d1vD/YoaW/wYJCv8iLjT/ibvR/53W8P+d1vD/ndbw/53W8P99q7//Hyow/4q80v+a0+z/ndbw/4q70v8dJyv/bZSm/53W8P+d1vD/kcXd/yw8Q/8aJTD/WZ3P/1C28P9uquD/ZmiI/wwKDf9GZnP/j9Ds/5LT8P+S0/D/ktPw/5LT8P9zp73/Exsf/zdQWv+My+b/ktPw/5LT8P+S0/D/ktPw/4G81f8nOUH/NUtU/0Ngbf9Zf5D/TnB//wMEBP9TeYn/ktPw/5LT8P+KyeT/MUhR/xIZIf9RksH/ULbw/26q4P9KTWX/AwMD/1yQp/+Ez/D/hM/w/4LM7f99xOP/hM/w/3rB3/8oQEv/UoGW/4PP7/+Dze7/fcTj/4TP8P+Ez/D/f8jo/zRTYP8CAAD/EgAA/w0AAP8EAAD/AgME/0p0h/+Ez/D/hM/w/4HL7P85Wmj/DxUb/06Ou/9QtvD/bqrg/y8wP/8FCQv/abPS/3jM8P94zPD/brzc/1SPqP94zO//d8rt/0Nyhv9kq8n/eMzw/3LB4v9Ujab/eMzw/3jM8P94zO//SHqP/wYAAP91AAD/qgAA/28AAP8CAwT/RHOH/3jM8P94zPD/dsnr/zRZaP8PFRv/To67/1C28P9po9b/ExQa/xQlLf9pxev/a8nw/2vJ8P9Smbb/Kk5d/2fB5v9ryfD/Yrjc/2jE6v9ryfD/WqjI/yE/S/9nwuf/a8nw/2vJ8P9Wo8L/AgME/1ABAf/VAQH/vQAA/wEDBP88cYf/a8nw/2vJ8P9pxuz/Lldo/w8VG/9Ojrv/ULbw/12SwP8EBQf/IkhX/2DG8P9gxvD/X8bv/zhzi/8WLTf/Va/U/2DG8P9fxu//YMbw/2DG8P9Ciab/Cxcc/1Sv0/9gxvD/YMbw/1q64f8JExf/EAwM/3YHB/+6AAD/AQME/zZvh/9gxvD/YMbw/17D6/8pVmj/DxUb/06Ou/9Qte//Q26Q/wIFB/8vcoz/UsPw/1LD8P9Pu+f/H0la/wcQFP87ja3/UsPw/1LD8P9Sw/D/UsPw/yVYbf8AAQH/OISj/1LD8P9Sw/D/UsLv/xc4Rf8GBgb/ZwYG/7oAAP8BAwT/Lm6H/1LD8P9Sw/D/UcDs/yNVaP8PFRv/To67/06y6/8uT2n/BhIW/zWPsv9HwPD/R8Dw/0Ct1/8RLzv/AQQF/ydphP9HwPD/R8Dw/0fA8P9Hv+7/EjA8/wAAAP8kYXn/R77t/0fA8P9HwPD/Il10/wECAv9hBQX/ugAA/wEDBP8obIf/R8Dw/0fA8P9Gvev/H1Ro/w8VG/9Ojrv/R6XZ/xkvPv8LJjD/MKHM/zi67P84uuz/LJG4/wcXHf8AAAD/ETlI/zi56v84uuz/OLrs/zOn1P8EDA//AAAA/xI7S/80rt3/OLrs/zi67P8mfqD/AwsO/1cCAv+4AAD/AQME/x9ohP84uuz/OLrs/ze26P8YUWb/DxUb/06Ou/8+k8L/DRoi/wYWHP8US2D/FVJo/xVSaP8PO0v/AQYI/wAAAP8DDhP/FVBm/xVSaP8VUmj/EUFU/wABAf8AAAD/BRMY/xNJXf8VUmj/FVJo/xA+T/8CCAv/TAAA/7EAAP8AAQH/DC46/xVSaP8VUmj/FVBm/wkjLf8PFRv/To67/zR+pv8SHSb/EhEX/xINEf8JCQn/Gxsb/xsbG/8fHx//Pj4+/wsBAf8IBwf/FhYW/xYWFv8VFRX/EhIS/xcGBv8WAAD/DQwM/xwcHP8bGxv/Ghoa/xMTE/9DAQH/sAAA/x8AAP8dAwT/GwYI/xgJC/8WDBD/Ew8U/x4lMf9RksH/SKbb/1iIsv9zb5L/cFFq/z48Pf+srKz/srKy/6+vr/+DgYH/RQoK/zUwMP+NjY3/kZGR/4uLi/9gXl7/ZQ0N/4sEBP9YUVH/tbW1/7CwsP+oqKj/enp6/0UEBP+7AAD/uwMF/7YTGv+oKDT/mzhK/4pNZf98YH//bX2k/2Gp3v9QtvD/bqrg/5GMuP+NZob/UE5P/9/f3//n5+f/4eHh/6Cenv9DHBz/YFtb/729vf+9vb3/tbW1/2JXV/+oBgb/sAUF/3Jpaf/r6+v/5eXl/93d3f/CwsL/YVdX/1dMTP9MPT3/Sico/5EnMv+9RVv/rmGA/515oP+FmMj/ZrDo/1C28P9uquD/kYy4/41mhv9SUFH/5eXl/+zs7P/n5+f/0dDQ/6Sfn/+8u7v/ysrK/7W1tf9wbm7/ThcX/9QBAf+wBgb/dWxs//Hx8f/r6+v/4+Pj/93d3f/Q0ND/yMjI/7S0tP+Yl5f/TDg7/5M6TP+uYYD/nXmg/4WYyP9msOj/ULbw/26q4P+RjLj/jWaG/1NRUv/s7Oz/9PT0/+7u7v/m5ub/3d3d/9jY2P/S0tL/eXh4/ycaGv+mBAT/9AAA/7AFBf93bm7/+Pj4//Ly8v/r6+v/29vb/7Oxsf/JyMj/zc3N/8fHx/90cnL/ai87/65hgP+deaD/hZjI/2aw6P9QtvD/bqrg/5GMuP+NZob/UlBQ/+vr6//7+/v/9PT0/8fGxv9xaWn/qKen/9jY2P/Dw8P/mJWV/1Y3N/+/BAT/sAUF/3Vra//7+/v/+Pj4//Hx8f+6urr/JiIi/5KQkP/T09P/zc3N/4mIiP9bLzn/rmGA/515oP+FmMj/ZrDo/1C28P9uquD/kYy4/41mhv9PTU3/4+Pj//r6+v/7+/v/qqen/0sQEP9UTU3/1tbW/9nZ2f/S0tL/hoSE/4UQEP+wBQX/cWho//X19f/6+vr/+Pj4/7W1tf8cCgr/a2Zm/93d3f/V1dX/o6Ki/0syN/+uYYD/nXmg/4WYyP9msOj/ULbw/26q4P+RjLj/jWaG/01LTP/d3d3/8/Pz//r6+v+vrKz/WRAQ/1BJSf/Z2dn/39/f/9nZ2f+gnp7/Yh0d/7AFBf9uZWX/7u7u//X19f/7+/v/ubm5/yAMDP9rZGT/4+Pj/93d3f+op6f/SzI3/65hgP+deaD/hZjI/2aw6P9QtvD/bqrg/5GMuP+NZob/SkhJ/9bW1v/r6+v/8fHx/6ypqf9PERH/U01N/+Dg4P/n5+f/4eHh/6Gdnf9iFRb/rQgJ/2tiYv/m5ub/7Ozs//X19f+7u7v/GAoK/3hzc//r6+v/5eXl/62rq/9OLzb/rmGA/515oP+FmMj/ZrDo/1C28P9uquD/kYy4/41mhv9IRkf/z8/P/+Xl5f/r6+v/sa+v/zUjI/+WkpL/7+/v/+zs7P/n5+f/iYeH/3UWGv+hFRv/Z19g/+Dg4P/m5ub/7u7u/8HBwf8sJyf/sa6v//Hx8f/r6+v/oqCg/1gtNv+uYYD/nXmg/4WYyP9msOj/ULbw/26q4P+RjLj/jWaG/0VDQ//Hx8f/3d3d/+Pj4//m5ub/4uLi//n5+f/7+/v/8/Pz/9bV1v9OPD7/ois3/5MnMf9iXF3/2NjY/97e3v/m5ub/6+vr/+np6f/6+vr/+Pj4//Dw8P9sZmf/dTE//65hgP+deaD/hZjI/2aw6P9QtvD/bqrg/5GMuP+NZob/Qj9A/7m5uf/Ozs7/1dXV/93d3f/p6en/7Ozs/+zs7P++vr7/VlNU/2wtOv+5RFn/hzRD/1tWV//Jycn/0NDQ/9jY2P/e3t7/6+vr/+3t7f/j4+P/nJqb/0ssMv+oQ1j/rmGA/515oP+FmMj/ZrDo/1C28P9uquD/kYy4/5Vrjf8zJS3/OCsz/zotNf87Ljb/PjE4/1BBSv9ENz7/SDZA/0szP/98SmD/rWB//65hgP+JT2f/OCgx/zosNP87LjX/PC82/z4xOP9OP0f/RzlB/0g1P/9WOUj/nVl0/65hgP+rZYX/nXmg/4WYyP9msOj/ULbw/26q4P+RjLj/m3ui/4xukf+IbI7/iGyO/4htjv+IbY7/iW2O/4pukP+Rcpb/mHab/5x5n/+deaD/nXmg/5l3nP+LbpD/iGyO/4hsjv+IbY7/iG2O/4ltjv+NcJL/lHOX/5l3nP+deaD/nXmg/515oP+afaX/hZjI/2aw6P9QtvD/bqrg/4WYyP+FmMj/hZjI/4WYyP+FmMj/hZjI/4WYyP+FmMj/hZjI/4WYyP+FmMj/hZjI/4WYyP+FmMj/hZjI/4WYyP+FmMj/hZjI/4WYyP+FmMj/hZjI/4WYyP+FmMj/hZjI/4WYyP+FmMj/hZjI/4WYyP+AnM3/ZrDo/1C28P9ksur/ZrDo/2aw6P9msOj/ZrDo/2aw6P9msOj/ZrDo/2aw6P9msOj/ZrDo/2aw6P9msOj/ZrDo/2aw6P9msOj/ZrDo/2aw6P9msOj/ZrDo/2aw6P9msOj/ZrDo/2aw6P9msOj/ZrDo/2aw6P9msOj/ZrDo/2aw6P9htO3/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoAAAAEAAAACAAAAABACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVbTt/16v5v83dZv/M3CT/zRwlf9JkL7/QYSu/zNvk/80cZX/PoCp/1qo3v8/g63/NHGW/0eOu/9erub/XLLq/1+w6P+CeqH/HiIl/2p5gf9danH/LCc0/yMjKv9qeIH/aniA/xcZHf8hJCv/XGhw/2l4gP85QUb/NzVF/3Wj1v9fsOj/ZFt4/09jbP+x2/D/rtjs/xcbHv87SlH/sdvw/7Hb8P8yPkT/f56t/7Hb8P+u1+v/sNrv/0FRWf9Pe6L/X7Do/0E/U/9nkaP/l9Tw/5fU8P87VF//W4GR/5fU8P+X1PD/UXKB/2eOoP9zoLT/OE5Y/5fU8P9ehJX/NVt4/1+w6P8gIi3/cLjW/3vJ6v9zu9r/V4+n/2yy0P9xuNb/fs7w/12Ysf8kAAD/SgAA/yQ7Rf9+zvD/WZKq/y5Ra/9ZqN3/EyIp/2XH7v9Vp8j/P3uT/2PD6v9lxu7/MmJ1/2HA5v9fu+H/GwkK/7ECAv8dOUX/Zcjw/0iOqv8uUWv/RIm1/xtGV/9NwfD/MHiV/xtCUv9NwfD/TMHv/w4iKv89mr7/TcHv/xAnMP+PAwP/FjhF/03B8P82iar/LlFr/ytgf/8VSl7/J4aq/xE6Sv8FEhf/JoWp/yR9n/8BAwT/F1Fn/yeGqv8PNEL/gwAA/wsmMf8nhqr/G154/y5Ra/85cpb/QjdJ/0RDQ/9nZ2f/RDMz/zg3N/9SUlL/PCEh/0IYGP9nZ2f/VFRU/30BAf9rBgn/Xhwk/0wyQv9Pd53/X7Do/494n/+amZn/5+fn/5aKiv+pp6f/pqWl/4sdHf+SODj/6+vr/9jY2P+Uj4//eWxs/4s4Rf+mbZD/dqTY/1+w6P+PeJ//n56e//T09P+/vb3/y8rK/356ev+sEBD/kzk5//f39//c3Nz/jYuL/83Nzf9xVlz/pm2Q/3ak2P9fsOj/j3if/5eWlv/4+Pj/f11d/5SRkf/Z2dn/g1RU/5A2Nv/09PT/2NjY/0Q4OP/d3d3/eGtu/6ZtkP92pNj/X7Do/494n/+OjY3/6+vr/3hjY/+uq6v/5+fn/4BUVf+IODn/5ubm/9jY2P9bVVX/6+vr/31qbv+mbZD/dqTY/1+w6P+PeJ//goCB/9nZ2f/k5OT/8/Pz/7e2tv+FNkL/dkNK/9TU1P/i4uL/7+/v/9rZ2v91Qkz/pm2Q/3ak2P9fsOj/lH+n/2BLYP9iTWL/aFNo/2pTaf9/W3b/pW2P/3lXcf9hTWH/Y05j/2tVav9zVm//oWuN/6B1mv92pNj/XLLq/3Wk1/91pNf/daTX/3Wk1/91pNf/daTX/3Wk1/91pNf/daTX/3Wk1/91pNf/daTX/3Wk1/91pNf/a6zi/wAArEEAAKxBAACsQQAArEEAAKxBAACsQQAArEEAAKxBAACsQQAArEEAAKxBAACsQQAArEEAAKxBAACsQQAArEE=");
		$l=strlen($ol);
		header("Cache-Control: no-cache, must-revalidate");
		header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
		//header("Content-type: text/plain;charset=UTF-8");
		header("Content-type: image/icon");
		header("Content-length: $l");
		echo $ol;
		die;
	}
}
header("Cache-Control: no-cache, must-revalidate");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
header("Content-type: text/plain");
/*function encodeURIComponent($str) {
    $revert = array('%21'=>'!', '%2A'=>'*', '%27'=>"'", '%28'=>'(', '%29'=>')');
    return strtr(rawurlencode($str), $revert);
}*/
function encodeURIComponent($string) {
   $result = "";
   $c=strlen($string);
   for ($i = 0; $i < $c; $i++) {
      $result .= encodeURIComponentbycharacter(urlencode($string[$i]));
   }
   return $result;
}

function encodeURIComponentbycharacter($char) {
   if ($char == "+") { return "%20"; }
   if ($char == "%21") { return "!"; }
   //if ($char == "%27") { return '"'; }
   if ($char == "%28") { return "("; }
   if ($char == "%29") { return ")"; }
   if ($char == "%2A") { return "*"; }
   if ($char == "%7E") { return "~"; }
   if ($char == "%80") { return "%E2%82%AC"; }
   if ($char == "%81") { return "%C2%81"; }
   if ($char == "%82") { return "%E2%80%9A"; }
   if ($char == "%83") { return "%C6%92"; }
   if ($char == "%84") { return "%E2%80%9E"; }
   if ($char == "%85") { return "%E2%80%A6"; }
   if ($char == "%86") { return "%E2%80%A0"; }
   if ($char == "%87") { return "%E2%80%A1"; }
   if ($char == "%88") { return "%CB%86"; }
   if ($char == "%89") { return "%E2%80%B0"; }
   if ($char == "%8A") { return "%C5%A0"; }
   if ($char == "%8B") { return "%E2%80%B9"; }
   if ($char == "%8C") { return "%C5%92"; }
   if ($char == "%8D") { return "%C2%8D"; }
   if ($char == "%8E") { return "%C5%BD"; }
   if ($char == "%8F") { return "%C2%8F"; }
   if ($char == "%90") { return "%C2%90"; }
   if ($char == "%91") { return "%E2%80%98"; }
   if ($char == "%92") { return "%E2%80%99"; }
   if ($char == "%93") { return "%E2%80%9C"; }
   if ($char == "%94") { return "%E2%80%9D"; }
   if ($char == "%95") { return "%E2%80%A2"; }
   if ($char == "%96") { return "%E2%80%93"; }
   if ($char == "%97") { return "%E2%80%94"; }
   if ($char == "%98") { return "%CB%9C"; }
   if ($char == "%99") { return "%E2%84%A2"; }
   if ($char == "%9A") { return "%C5%A1"; }
   if ($char == "%9B") { return "%E2%80%BA"; }
   if ($char == "%9C") { return "%C5%93"; }
   if ($char == "%9D") { return "%C2%9D"; }
   if ($char == "%9E") { return "%C5%BE"; }
   if ($char == "%9F") { return "%C5%B8"; }
   if ($char == "%A0") { return "%C2%A0"; }
   if ($char == "%A1") { return "%C2%A1"; }
   if ($char == "%A2") { return "%C2%A2"; }
   if ($char == "%A3") { return "%C2%A3"; }
   if ($char == "%A4") { return "%C2%A4"; }
   if ($char == "%A5") { return "%C2%A5"; }
   if ($char == "%A6") { return "%C2%A6"; }
   if ($char == "%A7") { return "%C2%A7"; }
   if ($char == "%A8") { return "%C2%A8"; }
   if ($char == "%A9") { return "%C2%A9"; }
   if ($char == "%AA") { return "%C2%AA"; }
   if ($char == "%AB") { return "%C2%AB"; }
   if ($char == "%AC") { return "%C2%AC"; }
   if ($char == "%AD") { return "%C2%AD"; }
   if ($char == "%AE") { return "%C2%AE"; }
   if ($char == "%AF") { return "%C2%AF"; }
   if ($char == "%B0") { return "%C2%B0"; }
   if ($char == "%B1") { return "%C2%B1"; }
   if ($char == "%B2") { return "%C2%B2"; }
   if ($char == "%B3") { return "%C2%B3"; }
   if ($char == "%B4") { return "%C2%B4"; }
   if ($char == "%B5") { return "%C2%B5"; }
   if ($char == "%B6") { return "%C2%B6"; }
   if ($char == "%B7") { return "%C2%B7"; }
   if ($char == "%B8") { return "%C2%B8"; }
   if ($char == "%B9") { return "%C2%B9"; }
   if ($char == "%BA") { return "%C2%BA"; }
   if ($char == "%BB") { return "%C2%BB"; }
   if ($char == "%BC") { return "%C2%BC"; }
   if ($char == "%BD") { return "%C2%BD"; }
   if ($char == "%BE") { return "%C2%BE"; }
   if ($char == "%BF") { return "%C2%BF"; }
   if ($char == "%C0") { return "%C3%80"; }
   if ($char == "%C1") { return "%C3%81"; }
   if ($char == "%C2") { return "%C3%82"; }
   if ($char == "%C3") { return "%C3%83"; }
   if ($char == "%C4") { return "%C3%84"; }
   if ($char == "%C5") { return "%C3%85"; }
   if ($char == "%C6") { return "%C3%86"; }
   if ($char == "%C7") { return "%C3%87"; }
   if ($char == "%C8") { return "%C3%88"; }
   if ($char == "%C9") { return "%C3%89"; }
   if ($char == "%CA") { return "%C3%8A"; }
   if ($char == "%CB") { return "%C3%8B"; }
   if ($char == "%CC") { return "%C3%8C"; }
   if ($char == "%CD") { return "%C3%8D"; }
   if ($char == "%CE") { return "%C3%8E"; }
   if ($char == "%CF") { return "%C3%8F"; }
   if ($char == "%D0") { return "%C3%90"; }
   if ($char == "%D1") { return "%C3%91"; }
   if ($char == "%D2") { return "%C3%92"; }
   if ($char == "%D3") { return "%C3%93"; }
   if ($char == "%D4") { return "%C3%94"; }
   if ($char == "%D5") { return "%C3%95"; }
   if ($char == "%D6") { return "%C3%96"; }
   if ($char == "%D7") { return "%C3%97"; }
   if ($char == "%D8") { return "%C3%98"; }
   if ($char == "%D9") { return "%C3%99"; }
   if ($char == "%DA") { return "%C3%9A"; }
   if ($char == "%DB") { return "%C3%9B"; }
   if ($char == "%DC") { return "%C3%9C"; }
   if ($char == "%DD") { return "%C3%9D"; }
   if ($char == "%DE") { return "%C3%9E"; }
   if ($char == "%DF") { return "%C3%9F"; }
   if ($char == "%E0") { return "%C3%A0"; }
   if ($char == "%E1") { return "%C3%A1"; }
   if ($char == "%E2") { return "%C3%A2"; }
   if ($char == "%E3") { return "%C3%A3"; }
   if ($char == "%E4") { return "%C3%A4"; }
   if ($char == "%E5") { return "%C3%A5"; }
   if ($char == "%E6") { return "%C3%A6"; }
   if ($char == "%E7") { return "%C3%A7"; }
   if ($char == "%E8") { return "%C3%A8"; }
   if ($char == "%E9") { return "%C3%A9"; }
   if ($char == "%EA") { return "%C3%AA"; }
   if ($char == "%EB") { return "%C3%AB"; }
   if ($char == "%EC") { return "%C3%AC"; }
   if ($char == "%ED") { return "%C3%AD"; }
   if ($char == "%EE") { return "%C3%AE"; }
   if ($char == "%EF") { return "%C3%AF"; }
   if ($char == "%F0") { return "%C3%B0"; }
   if ($char == "%F1") { return "%C3%B1"; }
   if ($char == "%F2") { return "%C3%B2"; }
   if ($char == "%F3") { return "%C3%B3"; }
   if ($char == "%F4") { return "%C3%B4"; }
   if ($char == "%F5") { return "%C3%B5"; }
   if ($char == "%F6") { return "%C3%B6"; }
   if ($char == "%F7") { return "%C3%B7"; }
   if ($char == "%F8") { return "%C3%B8"; }
   if ($char == "%F9") { return "%C3%B9"; }
   if ($char == "%FA") { return "%C3%BA"; }
   if ($char == "%FB") { return "%C3%BB"; }
   if ($char == "%FC") { return "%C3%BC"; }
   if ($char == "%FD") { return "%C3%BD"; }
   if ($char == "%FE") { return "%C3%BE"; }
   if ($char == "%FF") { return "%C3%BF"; }
   return $char;
}
function decodeURIComponent($str)
{
	$str = preg_replace("/%u([0-9a-f]{3,4})/i","&#x\\1;",urldecode($str));
	return html_entity_decode($str,NULL,'UTF-8');;
}
function CheckLogin()
{
	global $djpassword;
	if(!isset($_SESSION["djpw"]))
	{
		return FALSE;
	}
	$curP=$_SESSION["djpw"];
	if($curP=="" || $curP!=$djpassword)
	{
		return FALSE;
	}
	return TRUE;
}
$WebJockeyPort=62187; $WebJockeyIP="127.0.0.1"; $errno=0;$errstr="";
$pc=count($_POST);
if($pc<1){return;}
$g=(array_key_exists('Command',$_POST)?$_POST['Command']:"");
if($g==""){return;}
if($g=="Touch")
{
	if(array_key_exists("Expired",$_SESSION))
	{
		unset($_SESSION["Expired"]);
		echo "LoginExpired\r\n\r\n";
		return;
	}
	else if(!CheckLogin())
	{
		echo "UnAuth\r\n\r\n";
		return;
	}
	echo "TouchReply\r\nAck\r\n\r\n";
	return;
}
if($g=="GetPubKey")
{
	if(!array_key_exists("RSAPubKey",$_SESSION))
	{
		echo "GetPubKeyReply\r\nUnavailable\r\n\r\n\r\n";
		return;
	}
	$pub=$_SESSION["RSAPubKey"];
	$pub=encodeURIComponent($pub);
	echo "GetPubKeyReply\r\nAvailable\r\n$pub\r\n\r\n";
	return;
}
if($g=="DumpEncryptionKeys")
{
	unset($_SESSION["RSAPrivKey"]);
	unset($_SESSION["RSAPubKey"]);
	echo "DumpEncryptionKeysReply\r\nSuccess\r\n\r\n";
	return;
}
if($g=="Request"){$_POST['Param1']=getRealIpAddr();}
if($g=="RequestList"){$_POST['Param1']=getRealIpAddr();}
if($g=="SkipVote"){$_POST['Param1']=getRealIpAddr();}
if($g=="DJ:Request"){$_POST['Param1']="DJ:".getRealIpAddr();}
if($g=="DJ:SkipNow"){$_POST['Param1']="DJ:".getRealIpAddr();}
if(array_key_exists('IP',$_POST) && $_POST['IP']!=""){$WebJockeyIP=$_POST['IP'];$pc--;}
if(array_key_exists('Port',$_POST) && $_POST['Port']!=""){$WebJockeyPort=$_POST['Port'];$pc--;}
$isdj=(strlen($g)>3 && substr($g,0,3)=="DJ:");
if(
	$g!="SkipVote" &&
	$g!="List" &&
	$g!="ListLength" &&
	$g!="PagedList" &&
	$g!="NowPlaying" &&
	$g!="Settings" &&
	$g!="Version" &&
	$g!="Request" &&
	$g!="RequestList" &&
	$g!="Search" &&
	$g!="GetAllTimezones" &&
	$g!="SetTimezone" &&
	$g!="GetTimezone" &&
	!$isdj
)
{
	echo "UnknownCommand\r\n\r\n";
	return;
}
if($g=="DJ:Logout")
{
	global $djpassword;
	global $djsalt;
	$_SESSION["djpw"]="";
	unset($_SESSION["djpw"]);
	$djpw="";
	$djauth=($djpw==$djpassword);
	echo "Unauth\r\n\r\n";
	return;
}
if($g=="DJ:ChangePassword")
{
	global $djsalt;
	global $djpassword;
	if(!$djauth)
	{
		echo "UnAuth\r\n\r\n";
		return;
	}
	$token=$_POST['Passes'];
	if(!isset($token) || $token==NULL)
	{
		echo "Invalid\r\n\r\n";
		return;
	}
	$Pass=RSADecryptText($token);
	if($Pass==NULL)
	{
		echo "RSAError\r\n\r\n";
		return;
	}
}
if($g=="DJ:LoginS")
{
	global $djsalt;
	global $djpassword;
	$token=$_POST['Pass'];
	if(!isset($token) || $token==NULL)
	{
		echo "Invalid\r\n\r\n";
		return;
	}
	$Pass=RSADecryptText($token);
	if($Pass==NULL)
	{
		echo "RSAError\r\n\r\n";
		return;
	}
	if($Pass=="")
	{
		echo "MissingParams\r\n\r\n";
		return;
	}
	$Pass=decodeURIComponent($Pass);
	$check=strtoupper(sha1($djsalt.$Pass));
	if($djpassword!=$check)
	{
		unset($_SESSION["djpw"]);
		echo "Unauth\r\n\r\n";
		return;
	}
	$_SESSION["djpw"]=$check;
	echo "Auth\r\n\r\n";
	return;
}
if($g=="DJ:ChangePass")
{
	global $djsalt;
	global $djpassword;
	if(!$djauth)
	{
		echo "UnAuth\r\n\r\n";
		return;
	}
	$token=$_POST['token'];
	if(!isset($token) || $token=="")
	{
		echo "Invalid\r\n\r\n";
		return;
	}
	$tt=RSADecryptText($token);
	if($tt==NULL)
	{
		echo "RSAError\r\n\r\n";
		return;
	}
	if($tt=="")
	{
		echo "Invalid\r\n\r\n";
		return;
	}
	$tt=explode("=",$tt);
	if(count($tt)!=2)
	{
		echo "Invalid\r\n\r\n";
		return;
	}
	$OldPassword=decodeURIComponent($tt[0]);
	$NewPassword=decodeURIComponent($tt[1]);
	if($OldPassword=="" || $NewPassword=="")
	{
		echo "Invalid\r\n\r\n";
		return;
	}
	$OldCheck=strtoupper(sha1($djsalt.$OldPassword));
	if($djpassword!=$OldCheck)
	{
		echo "OldNonmatch\r\n\r\n";
		return;
	}
	$NewSalt=generatePassword();
	$NewPassword=strtoupper(sha1($NewSalt.$NewPassword));
	$djsalt=$NewSalt;
	$djpassword=$NewPassword;
	if(!setDjSalt($NewSalt))
	{
		echo "Error\r\n\r\n";
		return;
	}
	if(!setDjPassword($NewPassword))
	{
		echo "Error\r\n\r\n";
		return;
	}
	$_SESSION["djpw"]=$NewPassword;
	echo "Success\r\n\r\n";
	return;
}
if($g=="DJ:Login")
{
	$p1=(array_key_exists('Param1',$_POST)?$_POST['Param1']:"");
	$p2=(array_key_exists('Param2',$_POST)?$_POST['Param2']:"");
	if($p1!="" && $p2=="")
	{
		if($p1=="changeme")
		{
			echo "ChangePassword\r\n\r\n";
			return;
		}
		if(sha1($p1)==$djpassword && ($djpassword==sha1("changeme") || $djpassword==""))
		{
			echo "ChangePassword\r\n\r\n";
			return;
		}
		$_SESSION["djpw"]=sha1($p1);
		$djpw=sha1($p1);
		$djauth=($djpw==$djpassword);
	}
	if($p1!="" && $p2!="" && $p2=="changeme")
	{
		echo "ChangePassword\r\n\r\n";
		return;
	}
	if($p1!="" && $p2!="" && $p2!="changeme")
	{
		if(sha1($p1)==$djpassword)
		{
			ChangePassword($p2);
			$p2=sha1($p2);
			$djpassword=$p2;
			$djpw=$p2;
			$_SESSION["djpw"]=$p2;
			$djauth=($djpw==$djpassword);
		}
		else
		{
			echo "Unauth\r\n\r\n";
			return;
		}
	}
	if($djauth)
	{
		echo "Auth\r\n\r\n";
		return;
	}
	else
	{
		echo "Unauth\r\n\r\n";
		return;
	}
}
if($isdj && !$djauth)
{
	echo "Unauth\r\n\r\n";
	return;
}
if($g=="SetTimezone")
{
	if(!$djauth)
	{
		echo "SetTimezoneReply\r\nUnAuth\r\n\r\n";
		return;
	}
	$Timezone=$_POST['Timezone'];
	if(!isset($Timezone) || $Timezone=="")
	{
		echo "SetTimezoneReply\r\nInvalid\r\n\r\n";
		return;
	}
	if(!setTimezone($Timezone))
	{
		echo "SetTimezoneReply\r\nError\r\n\r\n";
		return;
	}
	echo "SetTimezoneReply\r\nSuccess\r\n\r\n";
	return;
}
if($g=="GetTimezone")
{
	global $timezone;
	if(!$djauth)
	{
		echo "GetTimezoneReply\r\nUnAuth\r\n\r\n";
		return;
	}
	if(!isset($timezone))
	{
		$timezone="";
	}
	$rr=encodeURIComponent($timezone);
	echo "GetTimezoneReply\r\nSuccess\r\n$rr\r\n\r\n";
	return;
}
if($g=="GetAllTimezones")
{
	if(!$djauth)
	{
		echo "GetAllTimezonesReply\r\nUnAuth\r\n\r\n";
		return;
	}
	$TZs=timezone_identifiers_list();
	echo "GetAllTimezonesReply\r\nSuccess\r\n";
	$c=count($TZs);
	echo "$c\r\n";
	for($i=0;$i<$c;$i++)
	{
		echo encodeURIComponent($TZs[$i]);echo "\r\n";
	}
	echo "\r\n";
	return;
}
if(($WebJockeyPort+0)<1024){return;}
$pc--;
$ecs=$g . "\r\n";
for($i=1;$i<=$pc;$i++)
{
	if($_POST["Param$i"]==""){return;}
	$ecs = $ecs . $_POST["Param$i"] . "\r\n";
}
$ecs = $ecs . "\r\n";
$fp = @fsockopen($WebJockeyIP,$WebJockeyPort,$errno,$errstr,1);
if($fp)
{
	$Res="";
	@fwrite($fp,$ecs);
	while (!feof($fp)) {
		$temp = @fgets($fp, 128);
		if(is_string($temp)){$Res = $Res . $temp;}
	}
	echo $Res;
}
else
{
	echo "Error\r\n\r\n";
}
function escapestring($t)
{
	$r="";
	$l=strlen($t);
	for($i=0;$i<$l;$i++)
	{
		
		$r.="\\x".dechex(ord($t[$i]));
	}
	return $r;
}
function encoded_hash_map($t)
{
	$hash=array();
	$key=NULL;
	$value=NULL;
	$p=NULL;
	$t=explode("&",$t);
	while(count($t))
	{
		$value=array_shift($t);
		$p=strpos($value,"=");
		if($p===0)
		{
			$value=explode("=",$value);
			array_shift($value);
			$value=implode("",$value);
			$hash['']=$value;
		}
		else if($p===FALSE)
		{
			$hash["$value"]="";
		}
		else
		{
			$value=explode("=",$value);
			$key=array_shift($value);
			$value=implode("=",$value);
			$hash["$key"]=$value;
		}
	}
	return $hash;
}
function setDjSalt($t)
{
	global $djsalt;
	global $djpassword;
	global $opensslcnffile;
	global $timezone;
	$djsalt=$t;
	$fh = fopen("bpwjdjcpconfig.php",'c');
	if($fh)
	{
		$narf="<?php\r\n";
		if(isset($djsalt))
		{
			$narf.='$djsalt="'.escapestring($djsalt)."\";\r\n";
		}
		if(isset($djpassword))
		{
			$narf.='$djpassword="'.escapestring($djpassword)."\";\r\n";
		}
		if(isset($opensslcnffile))
		{
			$narf.='$opensslcnffile="'.escapestring($opensslcnffile)."\";\r\n";
		}
		if(isset($timezone))
		{
			$narf.='$timezone="'.escapestring($timezone)."\";\r\n";
		}
		$narf.="?>";
		flock($fh,LOCK_EX);
		ftruncate($fh,0);
		rewind($fh);
		fwrite($fh,$narf);
		fclose($fh);
	}
	return $fh;
}
function setDjPassword($t)
{
	global $djsalt;
	global $djpassword;
	global $opensslcnffile;
	global $timezone;
	$djpassword=$t;
	$fh = fopen("bpwjdjcpconfig.php",'c');
	if($fh)
	{
		$narf="<?php\r\n";
		if(isset($djsalt))
		{
			$narf.='$djsalt="'.escapestring($djsalt)."\";\r\n";
		}
		if(isset($djpassword))
		{
			$narf.='$djpassword="'.escapestring($djpassword)."\";\r\n";
		}
		if(isset($opensslcnffile))
		{
			$narf.='$opensslcnffile="'.escapestring($opensslcnffile)."\";\r\n";
		}
		if(isset($timezone))
		{
			$narf.='$timezone="'.escapestring($timezone)."\";\r\n";
		}
		$narf.="?>";
		flock($fh,LOCK_EX);
		ftruncate($fh,0);
		rewind($fh);
		fwrite($fh,$narf);
		fclose($fh);
	}
	return $fh;
}
function setopensslcnffile($t)
{
	global $djsalt;
	global $djpassword;
	global $opensslcnffile;
	global $timezone;
	$opensslcnffile=$t;
	$fh = fopen("bpwjdjcpconfig.php",'c');
	if($fh)
	{
		$narf="<?php\r\n";
		if(isset($djsalt))
		{
			$narf.='$djsalt="'.escapestring($djsalt)."\";\r\n";
		}
		if(isset($djpassword))
		{
			$narf.='$djpassword="'.escapestring($djpassword)."\";\r\n";
		}
		if(isset($opensslcnffile))
		{
			$narf.='$opensslcnffile="'.escapestring($opensslcnffile)."\";\r\n";
		}
		if(isset($timezone))
		{
			$narf.='$timezone="'.escapestring($timezone)."\";\r\n";
		}
		$narf.="?>";
		flock($fh,LOCK_EX);
		ftruncate($fh,0);
		rewind($fh);
		fwrite($fh,$narf);
		fclose($fh);
	}
	return $fh;
}
function setTimezone($t)
{
	global $djsalt;
	global $djpassword;
	global $opensslcnffile;
	global $timezone;
	$timezone=$t;
	$fh = fopen("bpwjdjcpconfig.php",'c');
	if($fh)
	{
		$narf="<?php\r\n";
		if(isset($djsalt))
		{
			$narf.='$djsalt="'.escapestring($djsalt)."\";\r\n";
		}
		if(isset($djpassword))
		{
			$narf.='$djpassword="'.escapestring($djpassword)."\";\r\n";
		}
		if(isset($opensslcnffile))
		{
			$narf.='$opensslcnffile="'.escapestring($opensslcnffile)."\";\r\n";
		}
		if(isset($timezone))
		{
			$narf.='$timezone="'.escapestring($timezone)."\";\r\n";
		}
		$narf.="?>";
		flock($fh,LOCK_EX);
		ftruncate($fh,0);
		rewind($fh);
		fwrite($fh,$narf);
		fclose($fh);
	}
	return $fh;
}
function getRealIpAddr()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
    {
      $ip=$_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
    {
      $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    else
    {
      $ip=$_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}
function IncludeTrailingPathDelimiter($Path)
{
	if(substr($Path,-1)!="\\" && substr($Path,-1)!="/")
	{
		$Path.=DIRECTORY_SEPARATOR;
	}
	return $Path;
}
function ExcludeTrailingPathDelimiter($Path)
{
	while(substr($Path,-1)==DIRECTORY_SEPARATOR)
	{
		$Path=substr($Path,0,-1);
	}
	$Path=rtrim($Path,'/\\');
	return $Path;
}
function crypto_rand_secure($min, $max)
{
    $range = $max - $min;
    if ($range < 1) return $min; 
    $log = ceil(log($range, 2));
    $bytes = (int) ($log / 8) + 1; 
    $bits = (int) $log + 1; 
    $filter = (int) (1 << $bits) - 1; 
    do {
        $rnd = hexdec(bin2hex(openssl_random_pseudo_bytes($bytes)));
        $rnd = $rnd & $filter; 
    } while ($rnd > $range);
    return $min + $rnd;
}
function getToken($length)
{
    $token = "";
    $codeAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $codeAlphabet.= "abcdefghijklmnopqrstuvwxyz";
    $codeAlphabet.= "0123456789";
    $max = strlen($codeAlphabet); 

    for ($i=0; $i < $length; $i++) {
        $token .= $codeAlphabet[crypto_rand_secure(0, $max-1)];
    }

    return $token;
}
function generatePassword($length=160, $strength=15) {
	$vowels = 'aeuy';
	$consonants = 'bdghjmnpqrstvz';
	if ($strength & 1) {
		$consonants .= 'BDGHJLMNPQRSTVWXZ';
	}
	if ($strength & 2) {
		$vowels .= "AEUY";
	}
	if ($strength & 4) {
		$consonants .= '23456789';
	}
	if ($strength & 8) {
		$consonants .= '@#$%_+-!^&*(){}[]\"\'\\;.,/?';
	}
 
	$password = '';
	$alt = time() % 2;
	for ($i = 0; $i < $length; $i++) {
		if ($alt == 1) {
			$password .= $consonants[(rand() % strlen($consonants))];
			$alt = 0;
		} else {
			$password .= $vowels[(rand() % strlen($vowels))];
			$alt = 1;
		}
	}
	return $password;
}
$CreateCNFTemp="";
function CreateCNF($rf)
{
	global $CreateCNFTemp;
	$CreateCNFTemp="HOME\t= .\r\n";
	$CreateCNFTemp.="RANDFILE\t= \$ENV::HOME/.rnd\r\n";
	function VP($v,$p)
	{
		global $CreateCNFTemp;
		$CreateCNFTemp.="$v\t=$p\r\n";
	};
	function Section($s)
	{
		global $CreateCNFTemp;
		$CreateCNFTemp.="[ $s ]\r\n";
	}
	VP("oid_section","new_oids");
	Section("new_oids");
	Section("ca");
	VP("default_ca","CA_default");
	Section("CA_default");
	VP("dir","./demoCA");
	VP("certs","\$dir/certs");
	VP("crl_dir","\$dir/crl");
	VP("database","\$dir/index.txt");
	VP("new_certs_dir","\$dir/newcerts");
	VP("certificate","\$dir/cacert.pem");
	VP("serial","\$dir/crlnumber");
	VP("crl","\$dir/crl.pem");
	VP("private_key","\$dir/private/cakey.pem");
	VP("RANDFILE","\$dir/private/.rand");
	VP("x509_extensions","usr_cert");
	VP("name_opt","ca_default");
	VP("cert_opt","ca_default");
	VP("default_days","365");
	VP("default_crl_days","30");
	VP("default_md","sha1");
	VP("preserve","no");
	VP("preserve","no");
	Section("policy_match");
	VP("countryName","match");
	VP("stateOrProvinceName","match");
	VP("organizationName","match");
	VP("organizationalUnitName","optional");
	VP("commonName","supplied");
	VP("emailAddress","optional");
	Section("policy_anything");
	VP("countryName","optional");
	VP("stateOrProvinceName","optional");
	VP("localityName","optional");
	VP("organizationName","optional");
	VP("organizationalUnitName","optional");
	VP("commonName","supplied");
	VP("emailAddress","optional");
	Section("req");
	VP("default_bits","1024");
	VP("default_keyfile","privkey.pem");
	VP("distinguished_name","req_distinguished_name");
	VP("attributes","req_attributes");
	VP("x509_extensions","v3_ca");
	Section("req_distinguished_name");
	VP("countryName","Country Name (2 letter code)");
	VP("countryName_default","AU");
	VP("countryName_min","2");
	VP("countryName_max","2");
	VP("stateOrProvinceName","State or Province Name (full name)");
	VP("stateOrProvinceName_default","Some-State");
	VP("localityName","Locality Name (eg, city)");
	VP("0.organizationName","Organization Name (eg, company)");
	VP("0.organizationName_default","World Wide Web Pty Ltd");
	VP("organizationalUnitName","Organizational Unit Name (eg, section)");
	VP("commonName","Common Name (e.g. server FQDN or YOUR name)");
	VP("commonName_max","64");
	VP("emailAddress","Email Address");
	VP("emailAddress_max","64");
	Section("req_attributes");
	VP("challengePassword","A challenge password");
	VP("challengePassword_min","4");
	VP("challengePassword_max","20");
	VP("unstructuredName","An optional company name");
	Section("usr_cert");
	VP("basicConstraints","CA:FALSE");
	VP("nsComment","\"OpenSSL Generated Certificate\"");
	VP("subjectKeyIdentifier","hash");
	VP("authorityKeyIdentifier","keyid,issuer");
	Section("v3_req");
	VP("basicConstraints","CA:FALSE");
	VP("keyUsage","nonRepudiation, digitalSignature, keyEncipherment");
	Section("v3_ca");
	VP("subjectKeyIdentifier","hash");
	VP("authorityKeyIdentifier","keyid:always,issuer:always");
	VP("basicConstraints","CA:true");
	Section("crl_ext");
	VP("authorityKeyIdentifier","keyid:always,issuer:always");
	Section("proxy_cert_ext");
	VP("basicConstraints","CA:FALSE");
	VP("nsComment","hash");
	VP("subjectKeyIdentifier","\"OpenSSL Generated Certificate\"");
	VP("authorityKeyIdentifier","keyid,issuer:always");
	VP("proxyCertInfo","critical,language:id-ppl-anyLanguage,pathlen:3,policy:foo");
	$fh = fopen($rf,'c');
	flock($fh,LOCK_EX);
	ftruncate($fh,0);
	rewind($fh);
	fwrite($fh,$CreateCNFTemp);
	fclose($fh);
}
?>
