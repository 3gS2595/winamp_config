
FolderSrc="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiA/Pjxzdmcgdmlld0JveD0iMCAwIDM2MyAzNDEuMDIiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHN0eWxlPi5jbHMtMXtmaWxsOiM0MjY1NzI7fS5jbHMtMntmaWxsOiNlMWQyZDU7fS5jbHMtM3tmaWxsOiNmZmQ5NDc7fS5jbHMtNHtmaWxsOiNmZmE1NDY7fS5jbHMtNXtmaWxsOiNmZmY7fTwvc3R5bGU+PC9kZWZzPjx0aXRsZS8+PGcgZGF0YS1uYW1lPSJMYXllciAyIiBpZD0iTGF5ZXJfMiI+PGcgZGF0YS1uYW1lPSJMYXllciAxIiBpZD0iTGF5ZXJfMS0yIj48cmVjdCBjbGFzcz0iY2xzLTEiIGhlaWdodD0iMTIiIHdpZHRoPSIxNDgiIHg9IjEyNSIgeT0iNjUiLz48cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Ik03NSwxMVYyOTUuNUg2MC41YTEyLDEyLDAsMCwxLTEyLTEyVjIzYTEyLDEyLDAsMCwxLDEyLTEyWiIvPjxwYXRoIGNsYXNzPSJjbHMtMSIgZD0iTTMyMC41LDI5Ni41SDYwLjVhMTgsMTgsMCwwLDEtMTgtMThWMThhMTgsMTgsMCwwLDEsMTgtMThoMjYwYTE4LDE4LDAsMCwxLDE4LDE4VjI3OC41QTE4LDE4LDAsMCwxLDMyMC41LDI5Ni41Wk02MC41LDEyYTYsNiwwLDAsMC02LDZWMjc4LjVhNiw2LDAsMCwwLDYsNmgyNjBhNiw2LDAsMCwwLDYtNlYxOGE2LDYsMCwwLDAtNi02WiIvPjxwYXRoIGNsYXNzPSJjbHMtMyIgZD0iTTI4Mi42MywxMDEuNTdIMjM4LjJhNzQuMzcsNzQuMzcsMCwwLDEtNTIuNTktMjEuNzhoMEE3NC4zNyw3NC4zNywwLDAsMCwxMzMsNThIODAuMzdBNzQuMzcsNzQuMzcsMCwwLDAsNiwxMzIuMzdWMjYwLjY1QTc0LjM3LDc0LjM3LDAsMCwwLDgwLjM3LDMzNUgyODIuNjNBNzQuMzcsNzQuMzcsMCwwLDAsMzU3LDI2MC42NVYxNzUuOTRBNzQuMzcsNzQuMzcsMCwwLDAsMjgyLjYzLDEwMS41N1oiLz48cGF0aCBjbGFzcz0iY2xzLTQiIGQ9Ik0zNDcuNywyOTMuNjZBNzQuMzUsNzQuMzUsMCwwLDEsMjgyLjYzLDMzMkg4MC4zN0E3NC4zNyw3NC4zNywwLDAsMSw2LDI1Ny42M1YxMjkuMzVhNzQuMzcsNzQuMzcsMCwwLDEsNDQuMy02OCw3NCw3NCwwLDAsMC05LjMsMzZWMjI1LjYzQTc0LjM3LDc0LjM3LDAsMCwwLDExNS4zNywzMDBIMzE3LjYzQTczLjk0LDczLjk0LDAsMCwwLDM0Ny43LDI5My42NloiLz48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik0yODIuNjMsMzQxSDgwLjM3QTgwLjQ2LDgwLjQ2LDAsMCwxLDAsMjYwLjY1VjEzMi4zN0E4MC40Niw4MC40NiwwLDAsMSw4MC4zNyw1MkgxMzNhNzkuODQsNzkuODQsMCwwLDEsNTYuODMsMjMuNTQsNjcuOTMsNjcuOTMsMCwwLDAsNDguMzUsMjBoNDQuNDNBODAuNDYsODAuNDYsMCwwLDEsMzYzLDE3NS45NHY4NC43MUE4MC40Niw4MC40NiwwLDAsMSwyODIuNjMsMzQxWk04MC4zNyw2NEE2OC40NSw2OC40NSwwLDAsMCwxMiwxMzIuMzdWMjYwLjY1QTY4LjQ1LDY4LjQ1LDAsMCwwLDgwLjM3LDMyOUgyODIuNjNBNjguNDUsNjguNDUsMCwwLDAsMzUxLDI2MC42NVYxNzUuOTRhNjguNDUsNjguNDUsMCwwLDAtNjguMzctNjguMzdIMjM4LjJBNzkuODQsNzkuODQsMCwwLDEsMTgxLjM3LDg0LDY3LjkzLDY3LjkzLDAsMCwwLDEzMyw2NFoiLz48cGF0aCBjbGFzcz0iY2xzLTUiIGQ9Ik0zMDYuNTMsMTI2LjE0Yy41Ni4yNSwxLjE0LjQ2LDEuNjguNzRsMS42My44NCwxLjYyLjg0LjguNDIuNzcuNDgsMywxLjkzYzEsLjY3LDEuOTMsMS40NiwyLjg4LDIuMThhNDYuNTksNDYuNTksMCwwLDEsOSwxMC4xNCw1NS41NCw1NS41NCwwLDAsMSw1LjU0LDEwLjY2Yy4zNy44Ni42OCwxLjcyLDEsMi41OHMuNTksMS42OC44MywyLjUxYy40NiwxLjY2Ljk0LDMuMjQsMS4yNCw0Ljc5QTU3LjQ2LDU3LjQ2LDAsMCwxLDMzOCwxNzlhMjAuNDMsMjAuNDMsMCwwLDEtLjQ3LDRjLS4yMS45MS0uNDUsMS4zOC0uNzIsMS4zOXMtLjU0LS40Ni0uODMtMS4zMy0uNTYtMi4xNi0xLTMuNzlhMTIyLDEyMiwwLDAsMC0zLjctMTMuNWMtLjQ0LTEuNC0xLTIuOC0xLjYtNC4yOS0uMjktLjc0LS42NC0xLjQ3LTEtMi4yMnMtLjY2LTEuNTItMS4wNi0yLjI3YTU2Ljc2LDU2Ljc2LDAsMCwwLTUuNTEtOS4xOCw0My4zLDQzLjMsMCwwLDAtNy45My04LjM0Yy0uODEtLjU3LTEuNTYtMS4xOS0yLjQyLTEuNzVMMzA5LjE2LDEzNmwtLjY3LS40MS0uNzEtLjM2LTEuNDItLjcyLTEuNDItLjczYy0uNDgtLjI0LTEtLjQyLTEuNDktLjY0LTcuOTMtMy41MS0xNi4zNC01LjA2LTI0LjA1LTYuMDZzLTE0Ljg4LTEuMjItMjAuOS0xLjUxYy0xMi4wNS0uNDgtMTkuNjItMS4wNi0xOS42NS0yLjE1czcuMzktMi4zNSwxOS41OC0zLjI2YTE1Ni4zOCwxNTYuMzgsMCwwLDEsMjEuNjUtLjFDMjg4LjI3LDEyMC43MywyOTcuNDksMTIyLjE1LDMwNi41MywxMjYuMTRaIi8+PC9nPjwvZz48L3N2Zz4=";
FileSrc="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiA/PjxzdmcgaGVpZ2h0PSI0OCIgdmlld0JveD0iMCAwIDQ4IDQ4IiB3aWR0aD0iNDgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHN0eWxlPi5jbHMtMXtmaWxsOiNmZmY7fS5jbHMtMntmaWxsOiNkMGQ3ZGY7fS5jbHMtM3tmaWxsOiM0NzRjNTQ7fTwvc3R5bGU+PC9kZWZzPjx0aXRsZS8+PGcgZGF0YS1uYW1lPSIxLUZpbGUtRG9jdW1lbnQiIGlkPSJfMS1GaWxlLURvY3VtZW50Ij48cGF0aCBjbGFzcz0iY2xzLTEiIGQ9Ik00MywxNFY0M2E0LDQsMCwwLDEtNCw0SDlzLTQsMC00LTRWNUE0LDQsMCwwLDEsOSwxSDMwdjlhNCw0LDAsMCwwLDQsNFoiLz48cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Ik00MywxNEgzNGE0LDQsMCwwLDEtNC00VjFaIi8+PHBhdGggY2xhc3M9ImNscy0zIiBkPSJNNDMuOTIyLDEzLjYxNWEuOTk0Ljk5NCwwLDAsMC0uMjE1LS4zMjJsLTEzLTEzQTEsMSwwLDAsMCwzMCwwSDlBNS4wMDYsNS4wMDYsMCwwLDAsNCw1VjQzYTQuODIxLDQuODIxLDAsMCwwLDUsNUgzOWE1LjAwNiw1LjAwNiwwLDAsMCw1LTVWMTRBLjk4OC45ODgsMCwwLDAsNDMuOTIyLDEzLjYxNVpNMzksNDZIOS4wMDVBMi44NTMsMi44NTMsMCwwLDEsNiw0M1Y1QTMsMywwLDAsMSw5LDJIMjkuNTg2bDExLDExSDM0YTMsMywwLDAsMS0zLTNWN2ExLDEsMCwwLDAtMiwwdjNhNS4wMDYsNS4wMDYsMCwwLDAsNSw1aDhWNDNBMywzLDAsMCwxLDM5LDQ2WiIvPjxwYXRoIGNsYXNzPSJjbHMtMyIgZD0iTTM3LDI0SDExYTEsMSwwLDAsMCwwLDJIMzdhMSwxLDAsMCwwLDAtMloiLz48cGF0aCBjbGFzcz0iY2xzLTMiIGQ9Ik0zNywzMEgxMWExLDEsMCwwLDAsMCwySDM3YTEsMSwwLDAsMCwwLTJaIi8+PHBhdGggY2xhc3M9ImNscy0zIiBkPSJNMzcsMzVIMzVhMSwxLDAsMCwwLDAsMmgyYTEsMSwwLDAsMCwwLTJaIi8+PHBhdGggY2xhc3M9ImNscy0zIiBkPSJNMzEsMzVIMjlhMSwxLDAsMCwwLDAsMmgyYTEsMSwwLDAsMCwwLTJaIi8+PC9nPjwvc3ZnPg==";
FavIconSrc="data:image/ico;base64,AAABAAMAMDAAAAEAIACoJQAANgAAACAgAAABACAAqBAAAN4lAAAQEAAAAQAgAGgEAACGNgAAKAAAADAAAABgAAAAAQAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEm28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9JtvD/Sbbw/0m28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/0m28P9ftvD/dqXY/3al2P92pdj/dqXY/2CGr/8vQVb/LT9S/y0/Uv8tP1L/LT9S/y0/Uv8tP1L/LT9S/zRJYP9sl8b/dqXY/3ak1/9EX33/LT9S/y0/Uv8tP1L/LT9S/y0/Uv8tP1L/LT9S/y0/Uv8/WXT/dKLV/3al2P92pdj/cqDR/2WOuv9ObY7/RF99/y9BVv8tP1L/OE5m/05tjv9iibT/c6HT/3al2P92pdj/dqXY/3al2P92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+NksD/jZLA/0tNZv8AAAD/AAAA/wAAAP8AAAD/AAAA/wAAAP8AAAD/AAAA/wICA/9gZIP/jZLA/4WKtf8bGyT/AAAA/wAAAP8AAAD/AAAA/wAAAP8AAAD/AAAA/wAAAP8SExn/f4St/4uQvv9fYoL/Jyg1/w4PFP8BAQH/AAAA/wAAAP8AAAD/AAAA/wEBAf8LCw7/LC07/2Zpi/+LkL7/jZLA/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/l36l/y4nM/8BAQH/VmBm/36Mlf9+jJX/foyV/36Mlf9+jJX/QkpO/wAAAP8/NUX/mYCo/39qjP8LCg3/Jist/3uIkf9+jJX/foyV/36Mlf9+jJX/eIaO/x4iJP8FBAX/cF57/1pLY/8IBwn/BQUG/zA1OP9WYGb/e4iR/36Mlf9+jJX/dYKK/0BITP8TFRf/AAAA/w0LDv9tW3f/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/lmKC/xUOE/8OERL/obrI/8Lg8P/C4PD/wuDw/8Lg8P/C4PD/h5yo/wMEBP8hFRz/m2aG/2ZDWf8BAAH/W2lx/8Lg8P/C4PD/wuDw/8Lg8P/C4PD/wuDw/1BcY/8AAAD/NCIt/wgGB/8YGx3/dIaQ/7fU4//C4PD/wuDw/8Lg8P/C4PD/wuDw/7/c7P+husj/Tlpg/wgJCf8ZEBX/fmmK/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/glVw/wgEBf8iKSz/sNLj/7re8P+63vD/ut7w/7re8P+63vD/p8fY/xgdH/8HBAX/g0JY/zkdJv8DAwT/gpuo/7re8P+63vD/ut7w/7re8P+63vD/ut7w/3OJlP8AAAD/BgME/wQFBv94kJv/ut7w/7re8P+63vD/ut7w/7re8P+63vD/ut7w/7re8P+63vD/ttnq/2p+iP8EBQb/KSIt/4CErv92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/YkBV/wAAAP8/Tlb/sNrv/7Hb8P+x2/D/sdvw/7Hb8P+x2/D/rtjs/zhGTP8AAAD/UiAr/xkKDf8XHB//n8XY/7Hb8P+x2/D/sdvw/7Hb8P+x2/D/sdvw/4ytvf8JCwz/AAAA/yw2O/+nz+P/sdvw/7Hb8P+x2/D/sdvw/7Hb8P+x2/D/sdvw/7Hb8P+x2/D/sdvw/6fP4/8sNjv/AQEB/1dadv92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+Yf6f/Oycz/wAAAP9jgI3/qdnw/6nZ8P+p2fD/qdnw/6nZ8P+p2fD/qdnw/2eFk/8BAQH/DwUG/wMBAf8zQkj/ptbs/6nZ8P+p2fD/qdnw/6nZ8P+p2fD/qdnw/5zJ3v8cJSj/AwME/26NnP+p2fD/qdnw/6nZ8P+p2fD/qdnw/5nF2f+bx9z/qdnw/6nZ8P+p2fD/qdnw/6nZ8P9hfYr/AAAA/zg6TP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ReZ//HxUb/wcJCv99qLv/oNfw/6DX8P+g1/D/oNfw/6DX8P+g1/D/oNfw/4WzyP8MEBL/AAAA/wAAAP9XdIL/oNfw/6DX8P+g1/D/oNfw/6DX8P+g1/D/oNfw/5/W7/83SVL/DBAS/4e1yv+g1/D/oNfw/6DX8P+g1/D/j8DX/yUyOP8yQ0v/ms/n/6DX8P+g1/D/oNfw/6DX8P93n7L/BQcI/yssOv90otX/X7bw/0m28P9ftvD/dqXY/42SwP9/aoz/DAgL/xQcH/+Jv9j/mNXw/5jV8P+Y1fD/mNXw/5jV8P+Y1fD/mNXw/5LN5/8mNTz/AAAA/wgLDP94qL3/mNXw/5jV8P+Y1fD/mNXw/5jV8P+Y1fD/mNXw/5jV8P9QcX//Fh8j/3ipvv+QyeP/kczm/5jV8P+Y1fD/ZIye/wEBAf8LEBL/gLTK/5jV8P+Y1fD/mNXw/5jV8P99r8X/CAsM/xYXHv9tmcj/X7bw/0m28P9ftvD/dqXY/42SwP9lVG//AQAB/ytASP+N0Oz/j9Pw/4/T8P+P0/D/j9Pw/4/T8P+P0/D/j9Pw/4/T8P9DY3H/AAAA/xgkKP+Ew97/j9Pw/4/T8P+P0/D/j9Pw/4/T8P+P0/D/j9Pw/4/T8P9qnLL/BQcI/wsQEv8ZJCn/Hy41/zVOWP9DY3H/N1Fc/wAAAP8HCwz/da3F/4/T8P+P0/D/j9Pw/4/T8P98uNH/DhUY/wgIC/9iibP/X7bw/0m28P9ftvD/dqXY/42SwP9IPE//AAAA/0Bicf+H0PD/h9Dw/4fQ8P+H0PD/h9Dw/4XO7f+H0PD/h9Dw/4fQ8P9kmrL/BAcI/zBKVv+Gz+//h9Dw/4fQ8P+H0PD/hc7t/4fQ8P+H0PD/h9Dw/4fQ8P92tdH/DRQY/wMAAP8LAAD/CAAA/wAAAP8AAAD/AAAA/wAAAP8HCwz/b6rF/4fQ8P+H0PD/h9Dw/4fQ8P+AxeT/GCYr/wcHCv9hh7H/X7bw/0m28P9ftvD/dqXY/4mNuv8oISv/AgME/1iQqP9+zvD/fs7w/37O8P9+zvD/eMPk/2Oivf9+zvD/fs7w/37O8P9xudj/Ex8k/01+k/9+zvD/fs7w/37O8P92wOD/Z6jE/37O8P9+zvD/fs7w/37O8P96yOj/ITU+/wQAAP+SAAD/vQAA/54AAP94AAD/XAAA/xEAAP8GCwz/Z6nF/37O8P9+zvD/fs7w/37O8P94w+T/FyUr/wcHCv9hh7H/X7bw/0m28P9ftvD/dqXY/3t/p/8QDRH/DBQY/2ey0f92zPD/dszw/3bM8P92zPD/Y6zK/zNYaP92y+//dszw/3bM8P92y+//N15v/2KqyP92zPD/dszw/3bM8P9dob3/Pmp9/3bM8P92zPD/dszw/3bM8P92zPD/OGBx/wAAAP94AAD//wAA//8AAP//AAD/8gAA/y4AAP8GCgz/YafF/3bM8P92zPD/dszw/3bM8P9wwuT/FSUr/wcHCv9hh7H/X7bw/0m28P9ftvD/dqXY/2lsjv8FBAX/GCw1/2nB5v9uyvD/bsrw/27K8P9uyvD/TY2o/xUmLf9mu97/bsrw/27K8P9uyvD/WqbF/2jA5P9uyvD/bsrw/27K8P9Bd43/HDQ+/2vE6P9uyvD/bsrw/27K8P9uyvD/SIWe/wABAf9NAAD/+wAA//8AAP//AAD/8gAA/y4AAP8GCgz/WqbF/27K8P9uyvD/bsrw/27K8P9owOT/FCQr/wcHCv9hh7H/X7bw/0m28P9ftvD/dqXY/0tNZv8AAAD/KlJj/2bI8P9myPD/Zsjw/2bI8P9myPD/Nmp//wUKDP9Qnr3/Zsjw/2bI8P9myPD/Zcbt/2bI8P9myPD/Zsjw/2bH7/8kR1b/DRof/1y02P9myPD/Zsjw/2bI8P9myPD/VabI/wgPEv8fAAD/2gAA//cAAP//AAD/8gAA/y4AAP8FCgz/VKTF/2bI8P9myPD/Zsjw/2bI8P9hvuT/EiQr/wcHCv9hh7H/X7bw/0m28P9ftvD/dqTX/zAyQv8AAAD/OXqU/13G8P9dxvD/Xcbw/13G8P9cw+z/HDxI/wAAAP83dI3/Xcbw/13G8P9dxvD/Xcbw/13G8P9dxvD/Xcbw/1Sy2P8NHCL/BAkK/0mbu/9dxvD/Xcbw/13G8P9dxvD/WLvj/xEkLP8CAQH/JAoK/1kICP/3AAD/8gAA/y4AAP8FCgz/TKLF/13G8P9dxvD/Xcbw/13G8P9YvOT/ESQr/wcHCv9hh7H/X7bw/0m28P9ftvD/bZnI/xgZIP8ECgz/Q5q9/1XE8P9VxPD/VcTw/1XE8P9Ptd7/DR8m/wAAAP8bPkz/VMHs/1XE8P9VxPD/VcTw/1XE8P9VxPD/VcTw/z+Rsv8DBgj/AAAA/zJzjf9VxPD/VcTw/1XE8P9VxPD/VcPv/x5GVv8AAAD/MDAw/ygMDP/yAAD/8gAA/y4AAP8ECgz/RqHF/1XE8P9VxPD/VcTw/1XE8P9RuuT/DyMr/wcHCv9hh7H/X7bw/0m28P9ftvD/XYKq/wcHCv8NISj/R7Te/03C8P9NwvD/TcLw/03C8P8/ncP/BAsN/wAAAP8KGR//Ra7Y/03C8P9NwvD/TcLw/03C8P9NwvD/TcLw/ylnf/8AAAD/AAAA/x5LXP9NwvD/TcLw/03C8P9NwvD/TcLw/y1yjf8AAAD/JSUl/ygMDP/yAAD/8gAA/y4AAP8ECgz/P5/F/03C8P9NwvD/TcLw/03C8P9JuOT/DiMr/wcHCv9hh7H/X7bw/0m28P9ftvD/SWaF/wAAAP8YQlL/Rb/v/0XA8P9FwPD/RcDw/0XA8P8se5r/AAEB/wAAAP8CBgj/M46y/0XA8P9FwPD/RcDw/0XA8P9FwPD/RL3s/xU6SP8AAAD/AAAA/w8qNf9CuOb/RcDw/0XA8P9FwPD/RcDw/zaWu/8DCAr/FBQU/yYLC//yAAD/8gAA/y4AAP8ECgz/OZ3F/0XA8P9FwPD/RcDw/0XA8P9BtuT/DCMr/wcHCv9hh7H/X7bw/0m28P9ftvD/MURZ/wAAAP8gZX//PL7w/zy+8P88vvD/PL7w/zy+8P8ZUGb/AwMD/xEREf8AAAD/IGV//zy+8P88vvD/PL7w/zy+8P88vvD/NqvY/wgZH/8AAAD/AQAA/wYTGP80pdH/PL7w/zy+8P88vvD/PL7w/zar2P8IGR//CAgI/yEKCv/yAAD/8gAA/y4AAP8DCgz/MZzF/zy+8P88vvD/PL7w/zy+8P85tOT/CyIr/wcHCv9hh7H/X7bw/0m28P9brub/GiQv/wIGCP8kg6j/MbLk/zGy5P8xsuT/MbLk/zCt3P8NLzz/Dg4O/05OTv8AAAD/DzhI/zCv3/8xsuT/MbLk/zGy5P8xsuT/JYWq/wIGCP8EAwP/FQEB/wEDBP8ifZ//MbLk/zGy5P8xsuT/MbLk/zCv3/8PNUT/AAAA/xoICP/yAAD/8gAA/y4AAP8DCgz/KJG5/zGy5P8xsuT/MbLk/zGy5P8vqdj/CSAp/wcHCv9hh7H/X7bw/0m28P9TntH/DBEW/wABAf8HHCT/CCIr/wgiK/8IIiv/CCIr/wggKf8BBQf/JSUl/4qKiv8CAgL/AQUH/wggKf8IIiv/CCIr/wgiK/8IIiv/BRQa/wAAAP8UEhL/KAQE/wAAAP8FFBr/CCIr/wgiK/8IIiv/CCIr/wgiK/8DDBD/AAAA/xMGBv/yAAD/8gAA/y4AAP8AAQH/Bxwk/wgiK/8IIiv/CCIr/wgiK/8IICn/AQUH/wcHCv9hh7H/X7bw/0m28P9Eg6z/CAwP/wcHCv8IBwn/BwUG/wEBAf8JCQn/CwsL/wsLC/8LCwv/TExM/7S0tP8LCAj/BgAA/wEBAf8ICAj/CQkJ/wkJCf8ICAj/CAgI/wsLC/8pJib/PQcH/xEAAP8CAQH/BwcH/wsLC/8LCwv/CwsL/woKCv8KCgr/BgYG/wwEBP/qAAD/8gAA/zoAAP8MAQH/DAIC/wsCA/8KAwT/CgQF/wkFBv8IBgf/CAcJ/w4PFP9iibP/X7bw/0m28P9ZquD/YYex/3R4nf99aYr/b0lh/xEPEP+YmJj/tra2/7Ozs/+urq7/uLi4/8HBwf8hGhr/WwQE/xIKCv99fX3/lJSU/4+Pj/+Li4v/h4eH/4SEhP87Njb/VwoK/8gAAP8kDQ3/c3Nz/7a2tv+wsLD/rKys/6mpqf+lpaX/ZGRk/yMLC//xAAD//gAA/9kAAP/GDBD/vBkh/7ImMf+nMkL/nT5S/5NLYv+IWXb/fWmK/3V5n/9zoNL/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xUSE/+9vb3/4+Pj/97e3v/a2tr/1NTU/8TExP8mHh7/bwUF/xYMDP+cnJz/ubm5/7W1tf+vr6//qqqq/6Kiov8yLi7/cA0N//IAAP8tERH/j4+P/+Li4v/e3t7/19fX/9LS0v/Ozs7/fX19/yoODv/yAAD//wAA//8AAP/yDxT/5R4o/9kuPP/MPVD/v0xk/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xYTFP/BwcH/5+fn/+Pj4//e3t7/2tra/8nJyf8nHx//bwUF/xYMDP+fn5//vr6+/7m5uf+1tbX/r6+v/6Ghof8iGhr/rQgI//IAAP8tERH/kpKS/+fn5//i4uL/3t7e/9fX1//S0tL/gICA/xkICP+ZAAD/yQAA/+wAAP/mDhP/5B4o/9kuPP/MPVD/v0xk/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xYTFP/FxcX/6+vr/+fn5//j4+P/3t7e/8/Pz/8oICD/UAYG/xoREf+np6f/wsLC/76+vv+5ubn/tbW1/5GRkf8kFBT/3QIC//IAAP8tERH/lZWV/+vr6//n5+f/4uLi/97e3v/X19f/qKio/zMlJf8nFhb/JxYW/ywXF/8rERH/VhYZ/6olL//MPVD/v0xk/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xYTFP/IyMj/8PDw/+vr6//n5+f/4+Pj/9vb2/9mXl7/NCMj/3RwcP/Jycn/xsbG/8LCwv++vr7/ra2t/1ZOTv8+DAz/9wAA//IAAP8uEhL/l5eX//Dw8P/r6+v/5+fn/+Li4v/e3t7/19fX/8nJyf/Dw8P/tbW1/5qamv92dnb/Pzg4/yATFP+ZMj//v0xk/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xcUFf/MzMz/9PT0//Dw8P/r6+v/5+fn/+Pj4//b29v/0dHR/9TU1P/Pz8//y8vL/8HBwf+MjIz/MCws/yELC/+oAQH//wAA//IAAP8uEhL/mpqa//T09P/w8PD/6+vr/+fn5//i4uL/3t7e/9fX1//S0tL/zs7O/8nJyf/FxcX/uLi4/19dXv8sGBv/r0Zc/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xYTFP/R0dH/+fn5//T09P/w8PD/6+vr/+fn5//j4+P/3t7e/9ra2v/U1NT/z8/P/46Ojv8NCgr/IQkJ/7kBAf//AAD//wAA//IAAP8uEhL/nZ2d//n5+f/09PT/8PDw/+vr6//n5+f/4uLi/97e3v/X19f/0tLS/87Ozv/Jycn/xcXF/5ubm/8UDxD/nEBT/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xYTFP/Nzc3///////n5+f/09PT/8PDw/+vr6//g4OD/19fX/9vb2//a2tr/1NTU/7+/v/9ycXH/KiEh/ywREf+kBgb//wAA//IAAP8tERH/m5ub//39/f/5+fn/9PT0//Dw8P/r6+v/vLy8/1tSUv93dHT/0tLS/9LS0v/Ozs7/ycnJ/7Kysv8dGRr/hTlJ/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xYTFP/Jycn/+vr6///////5+fn/9PT0/+jo6P9YUlL/LyEh/2pnZ//b29v/2tra/9TU1P/Pz8//vb29/2xqav8xEhL/7gAA//IAAP8tERH/mJiY//r6+v/9/f3/+fn5//T09P/w8PD/kpKS/wEAAP8TDQ3/ubm5/9fX1//S0tL/zs7O/8DAwP8sKCn/bjVB/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xUSE//FxcX/9fX1//r6+v//////+fn5/+jo6P8sJCT/UAcH/x8WFv/Gxsb/3t7e/9ra2v/U1NT/z8/P/7Gxsf8gFxf/xwcH//IAAP8tERH/lZWV//X19f/6+vr//f39//n5+f/09PT/lZWV/xoJCf8aDQ3/lZWV/97e3v/X19f/0tLS/87Ozv9LSEj/TCcv/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xUSE//BwcH/8PDw//X19f/6+vr//////+zs7P8tJSX/cAYG/xgODv+9vb3/4+Pj/97e3v/a2tr/1NTU/8bGxv8uKCj/kg8P//IAAP8sEBD/kpKS//Dw8P/19fX/+vr6//39/f/5+fn/l5eX/yAMDP8gDAz/j4+P/+Li4v/e3t7/19fX/9LS0v9PTEz/SiYt/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xUSE/+9vb3/6+vr//Dw8P/19fX/+vr6//Ly8v8tJSX/cAYG/xkPD//BwcH/5+fn/+Pj4//e3t7/2tra/9TU1P9OSUn/YQ0N//IAAP8sEBD/j4+P/+vr6//w8PD/9fX1//r6+v/9/f3/mpqa/yAMDP8gDAz/kpKS/+fn5//i4uL/3t7e/9fX1/9PTU3/SiYt/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xQREv+5ubn/5+fn/+vr6//w8PD/9fX1/+3t7f8tJib/agwO/xkQEP/FxcX/6+vr/+fn5//j4+P/3t7e/9fX1/9CNzf/Zg0P/+YOE/8rEhL/jIyM/+fn5//r6+v/8PDw//X19f/6+vr/nZ2d/x4NDv8dDw//mJiY/+vr6//n5+f/4uLi/97e3v9RS0z/SiQs/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xQREv+1tbX/4uLi/+fn5//r6+v/8PDw/+np6f8sJib/Pw0P/xoTFP/Ozs7/8PDw/+vr6//n5+f/4+Pj/9LS0v8mICD/ihge/9kcJv8oEhT/iYmJ/+Li4v/n5+f/6+vr//Dw8P/19fX/m5ub/wYCA/8WDxD/xMTE//Dw8P/r6+v/5+fn/97e3v9COjv/Wicy/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xQREv+xsbH/3d3d/+Li4v/n5+f/6+vr/+jo6P9OSkv/Jh0e/5aSkv/29vb/9PT0//Dw8P/r6+v/5+fn/7a2tv8XExP/oycx/84sOf8nFBb/hoaG/93d3f/i4uL/5+fn/+vr6//w8PD/sbGx/yQfIP9wamr/7+/v//T09P/w8PD/6+vr/9ra2v8mIiL/dzRC/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xQQEf+rq6v/2NjY/93d3f/i4uL/5+fn/+vr6//c3Nz/3d3d//n5+f//////+fn5//T09P/w8PD/6urq/2poaf81HSD/wTpM/8I6TP8lFRf/g4OD/9jY2P/d3d3/4uLi/+fn5//r6+v/7e3t/9vb2//5+fn//f39//n5+f/09PT/8PDw/7Gxsf8VEBH/jztM/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xQQEf+np6f/0dHR/9jY2P/d3d3/4uLi/+fn5//r6+v/8PDw//X19f/6+vr///////n5+f/q6ur/ioqK/xYREv93M0H/v0xk/7VIX/8jFxn/fn5+/9PT0//Y2Nj/3d3d/+Li4v/n5+f/6+vr//Dw8P/19fX/+vr6//39/f/5+fn/6Ojo/01JSv9EJiz/uElg/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/iFl2/xQQEf+ampr/wsLC/8bGxv/Nzc3/0tLS/9bW1v/d3d3/6+vr/+bm5v/p6en/4eHh/8fHx/9eXF3/FBAR/2c4R/+sV3P/s1t4/6pWcv8hFxv/dHR0/8LCwv/IyMj/zc3N/9LS0v/W1tb/29vb/+rq6v/m5ub/6enp/+fn5/+6urr/T01O/yEZHP+US2P/s1t4/7NbeP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/jFx5/xAND/8cGhv/IyEj/yMhI/8kIiT/JSMk/yYkJf8vLS7/TkpN/zEvMP8tKy3/KCUn/x4ZHP8zJy7/eVFp/6Rsjv+mbZD/pm2Q/59oiv8pICX/FRQU/yIgIv8jISP/JCIk/yUjJP8mJCX/Kigp/0hFR/8xLzD/MC4v/y4qLf8YFRf/QDE6/4NXcv+mbZD/pm2Q/6ZtkP+mbZD/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+ZgKj/l36m/29eef9gUWn/YFFp/2BRaf9hUmn/YVJp/2FSaf9hUmr/YVJq/2FTav9uXXj/fmqL/4Vvkv+UfKP/mYCo/5mAqP+ZgKj/mYCo/5mAqP97Z4f/YFFp/2BRaf9gUWn/YVJp/2FSaf9hUmn/YVJq/2FSav9hU2r/dWN//35qi/+BbI7/lX2k/5mAqP+ZgKj/mYCo/5mAqP+ZgKj/mYCo/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/42SwP+NksD/jZLA/42SwP+NksD/jZLA/42SwP+NksD/jZLA/42SwP+NksD/jZLA/42SwP+NksD/jZLA/42SwP+NksD/jZLA/42SwP+NksD/jZLA/42SwP+NksD/jZLA/42SwP+NksD/jZLA/42SwP+NksD/jZLA/42SwP+NksD/jZLA/42SwP+NksD/jZLA/42SwP+NksD/jZLA/42SwP+NksD/jZLA/42SwP92pdj/X7bw/0m28P9ftvD/dqXY/3al2P92pdj/dqXY/3al2P92pdj/dqXY/3al2P92pdj/dqXY/3al2P92pdj/dqXY/3al2P92pdj/dqXY/3al2P92pdj/dqXY/3al2P92pdj/dqXY/3al2P92pdj/dqXY/3al2P92pdj/dqXY/3al2P92pdj/dqXY/3al2P92pdj/dqXY/3al2P92pdj/dqXY/3al2P92pdj/dqXY/3al2P92pdj/dqXY/3al2P92pdj/X7bw/0m28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/1+28P9ftvD/X7bw/wAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/QAAAAAAAPz9AAAAAAAA/P0AAAAAAAD8/SgAAAAgAAAAQAAAAAEAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABLtvD/ULbw/1C28P9QtvD/S63k/0qr4f9Kq+H/Sanf/0qq4f9Kq+H/S63k/0+07v9Osuv/Sqvi/0qr4f9Jqd//Sqvh/0qr4f9Kq+H/TbHp/1C28P9QtvD/T7Tu/02x6f9Kq+H/S6vi/0+z7f9Qte//ULbw/1C28P9QtvD/ULbw/1C28P9pruX/bqrg/2un2/8pR17/HjdJ/x43Sf8cNEX/HTZI/x43Sf8qSWH/YJbF/0x6oP8gOkz/HjdJ/xw0Rf8eN0n/HjdJ/x44Sv9DbpD/a6fb/1uQvP84X33/KEhf/x43Sf8fOUz/MVVw/0t5n/9ppNj/bqrg/26q4P9ksur/ULbw/26q4P+OkL3/fXmf/wUFB/8TFRb/Ki4x/youMf8qLjH/HCAh/wkJDP9hX33/NjVG/wgJCv8pLTD/Ki4x/youMf8oLTD/BgcI/yQkMP86Ok3/BwgK/xQWF/8kKCv/Ki4x/ygsL/8QEhP/AwMD/y0uPP93dZr/hZjI/2aw6P9QtvD/bqrg/5GMuP9tVXD/AwQE/11rc/+rxNH/q8TR/6vE0f+Dl6H/AgID/0UyQ/8cFRv/MDg8/6rD0P+rxNH/q8TR/6rC0P8qMDT/CQcK/wsKDP86Qkf/kKay/6a+y/+rxNH/qcHP/4mdqP9IU1n/BgYH/zIqN/+Bk8L/ZrDo/1C28P9uquD/joq1/0s6TP8OERP/g5+t/7fd8P+33fD/t93w/63S5P8XHB7/CwUH/wYFBv9gdH//t93w/7fd8P+33fD/t93w/1Nkbf8BAQH/OEVL/6fK2/+33fD/t93w/7fd8P+33fD/t93w/7Xa7f9abXb/BggI/05ffP9lruX/ULbw/26q4P+Gg6z/LyYz/x0lKP+Ptsj/q9nw/6vZ8P+r2fD/q9nv/zpKUv8AAAD/DRET/3ucrP+r2fD/q9nw/6vZ8P+r2fD/a4mW/wgKDP9ykaH/qtju/6vZ8P+r2fD/oczh/6jV6/+r2fD/q9nw/4qwwv8aISX/KTdI/2Cn3f9QtvD/bqrg/3d2nP8ZFRz/MkRM/5PJ4f+d1vD/ndbw/53W8P+d1vD/YoaW/wYJCv8iLjT/ibvR/53W8P+d1vD/ndbw/53W8P99q7//Hyow/4q80v+a0+z/ndbw/4q70v8dJyv/bZSm/53W8P+d1vD/kcXd/yw8Q/8aJTD/WZ3P/1C28P9uquD/ZmiI/wwKDf9GZnP/j9Ds/5LT8P+S0/D/ktPw/5LT8P9zp73/Exsf/zdQWv+My+b/ktPw/5LT8P+S0/D/ktPw/4G81f8nOUH/NUtU/0Ngbf9Zf5D/TnB//wMEBP9TeYn/ktPw/5LT8P+KyeT/MUhR/xIZIf9RksH/ULbw/26q4P9KTWX/AwMD/1yQp/+Ez/D/hM/w/4LM7f99xOP/hM/w/3rB3/8oQEv/UoGW/4PP7/+Dze7/fcTj/4TP8P+Ez/D/f8jo/zRTYP8CAAD/EgAA/w0AAP8EAAD/AgME/0p0h/+Ez/D/hM/w/4HL7P85Wmj/DxUb/06Ou/9QtvD/bqrg/y8wP/8FCQv/abPS/3jM8P94zPD/brzc/1SPqP94zO//d8rt/0Nyhv9kq8n/eMzw/3LB4v9Ujab/eMzw/3jM8P94zO//SHqP/wYAAP91AAD/qgAA/28AAP8CAwT/RHOH/3jM8P94zPD/dsnr/zRZaP8PFRv/To67/1C28P9po9b/ExQa/xQlLf9pxev/a8nw/2vJ8P9Smbb/Kk5d/2fB5v9ryfD/Yrjc/2jE6v9ryfD/WqjI/yE/S/9nwuf/a8nw/2vJ8P9Wo8L/AgME/1ABAf/VAQH/vQAA/wEDBP88cYf/a8nw/2vJ8P9pxuz/Lldo/w8VG/9Ojrv/ULbw/12SwP8EBQf/IkhX/2DG8P9gxvD/X8bv/zhzi/8WLTf/Va/U/2DG8P9fxu//YMbw/2DG8P9Ciab/Cxcc/1Sv0/9gxvD/YMbw/1q64f8JExf/EAwM/3YHB/+6AAD/AQME/zZvh/9gxvD/YMbw/17D6/8pVmj/DxUb/06Ou/9Qte//Q26Q/wIFB/8vcoz/UsPw/1LD8P9Pu+f/H0la/wcQFP87ja3/UsPw/1LD8P9Sw/D/UsPw/yVYbf8AAQH/OISj/1LD8P9Sw/D/UsLv/xc4Rf8GBgb/ZwYG/7oAAP8BAwT/Lm6H/1LD8P9Sw/D/UcDs/yNVaP8PFRv/To67/06y6/8uT2n/BhIW/zWPsv9HwPD/R8Dw/0Ct1/8RLzv/AQQF/ydphP9HwPD/R8Dw/0fA8P9Hv+7/EjA8/wAAAP8kYXn/R77t/0fA8P9HwPD/Il10/wECAv9hBQX/ugAA/wEDBP8obIf/R8Dw/0fA8P9Gvev/H1Ro/w8VG/9Ojrv/R6XZ/xkvPv8LJjD/MKHM/zi67P84uuz/LJG4/wcXHf8AAAD/ETlI/zi56v84uuz/OLrs/zOn1P8EDA//AAAA/xI7S/80rt3/OLrs/zi67P8mfqD/AwsO/1cCAv+4AAD/AQME/x9ohP84uuz/OLrs/ze26P8YUWb/DxUb/06Ou/8+k8L/DRoi/wYWHP8US2D/FVJo/xVSaP8PO0v/AQYI/wAAAP8DDhP/FVBm/xVSaP8VUmj/EUFU/wABAf8AAAD/BRMY/xNJXf8VUmj/FVJo/xA+T/8CCAv/TAAA/7EAAP8AAQH/DC46/xVSaP8VUmj/FVBm/wkjLf8PFRv/To67/zR+pv8SHSb/EhEX/xINEf8JCQn/Gxsb/xsbG/8fHx//Pj4+/wsBAf8IBwf/FhYW/xYWFv8VFRX/EhIS/xcGBv8WAAD/DQwM/xwcHP8bGxv/Ghoa/xMTE/9DAQH/sAAA/x8AAP8dAwT/GwYI/xgJC/8WDBD/Ew8U/x4lMf9RksH/SKbb/1iIsv9zb5L/cFFq/z48Pf+srKz/srKy/6+vr/+DgYH/RQoK/zUwMP+NjY3/kZGR/4uLi/9gXl7/ZQ0N/4sEBP9YUVH/tbW1/7CwsP+oqKj/enp6/0UEBP+7AAD/uwMF/7YTGv+oKDT/mzhK/4pNZf98YH//bX2k/2Gp3v9QtvD/bqrg/5GMuP+NZob/UE5P/9/f3//n5+f/4eHh/6Cenv9DHBz/YFtb/729vf+9vb3/tbW1/2JXV/+oBgb/sAUF/3Jpaf/r6+v/5eXl/93d3f/CwsL/YVdX/1dMTP9MPT3/Sico/5EnMv+9RVv/rmGA/515oP+FmMj/ZrDo/1C28P9uquD/kYy4/41mhv9SUFH/5eXl/+zs7P/n5+f/0dDQ/6Sfn/+8u7v/ysrK/7W1tf9wbm7/ThcX/9QBAf+wBgb/dWxs//Hx8f/r6+v/4+Pj/93d3f/Q0ND/yMjI/7S0tP+Yl5f/TDg7/5M6TP+uYYD/nXmg/4WYyP9msOj/ULbw/26q4P+RjLj/jWaG/1NRUv/s7Oz/9PT0/+7u7v/m5ub/3d3d/9jY2P/S0tL/eXh4/ycaGv+mBAT/9AAA/7AFBf93bm7/+Pj4//Ly8v/r6+v/29vb/7Oxsf/JyMj/zc3N/8fHx/90cnL/ai87/65hgP+deaD/hZjI/2aw6P9QtvD/bqrg/5GMuP+NZob/UlBQ/+vr6//7+/v/9PT0/8fGxv9xaWn/qKen/9jY2P/Dw8P/mJWV/1Y3N/+/BAT/sAUF/3Vra//7+/v/+Pj4//Hx8f+6urr/JiIi/5KQkP/T09P/zc3N/4mIiP9bLzn/rmGA/515oP+FmMj/ZrDo/1C28P9uquD/kYy4/41mhv9PTU3/4+Pj//r6+v/7+/v/qqen/0sQEP9UTU3/1tbW/9nZ2f/S0tL/hoSE/4UQEP+wBQX/cWho//X19f/6+vr/+Pj4/7W1tf8cCgr/a2Zm/93d3f/V1dX/o6Ki/0syN/+uYYD/nXmg/4WYyP9msOj/ULbw/26q4P+RjLj/jWaG/01LTP/d3d3/8/Pz//r6+v+vrKz/WRAQ/1BJSf/Z2dn/39/f/9nZ2f+gnp7/Yh0d/7AFBf9uZWX/7u7u//X19f/7+/v/ubm5/yAMDP9rZGT/4+Pj/93d3f+op6f/SzI3/65hgP+deaD/hZjI/2aw6P9QtvD/bqrg/5GMuP+NZob/SkhJ/9bW1v/r6+v/8fHx/6ypqf9PERH/U01N/+Dg4P/n5+f/4eHh/6Gdnf9iFRb/rQgJ/2tiYv/m5ub/7Ozs//X19f+7u7v/GAoK/3hzc//r6+v/5eXl/62rq/9OLzb/rmGA/515oP+FmMj/ZrDo/1C28P9uquD/kYy4/41mhv9IRkf/z8/P/+Xl5f/r6+v/sa+v/zUjI/+WkpL/7+/v/+zs7P/n5+f/iYeH/3UWGv+hFRv/Z19g/+Dg4P/m5ub/7u7u/8HBwf8sJyf/sa6v//Hx8f/r6+v/oqCg/1gtNv+uYYD/nXmg/4WYyP9msOj/ULbw/26q4P+RjLj/jWaG/0VDQ//Hx8f/3d3d/+Pj4//m5ub/4uLi//n5+f/7+/v/8/Pz/9bV1v9OPD7/ois3/5MnMf9iXF3/2NjY/97e3v/m5ub/6+vr/+np6f/6+vr/+Pj4//Dw8P9sZmf/dTE//65hgP+deaD/hZjI/2aw6P9QtvD/bqrg/5GMuP+NZob/Qj9A/7m5uf/Ozs7/1dXV/93d3f/p6en/7Ozs/+zs7P++vr7/VlNU/2wtOv+5RFn/hzRD/1tWV//Jycn/0NDQ/9jY2P/e3t7/6+vr/+3t7f/j4+P/nJqb/0ssMv+oQ1j/rmGA/515oP+FmMj/ZrDo/1C28P9uquD/kYy4/5Vrjf8zJS3/OCsz/zotNf87Ljb/PjE4/1BBSv9ENz7/SDZA/0szP/98SmD/rWB//65hgP+JT2f/OCgx/zosNP87LjX/PC82/z4xOP9OP0f/RzlB/0g1P/9WOUj/nVl0/65hgP+rZYX/nXmg/4WYyP9msOj/ULbw/26q4P+RjLj/m3ui/4xukf+IbI7/iGyO/4htjv+IbY7/iW2O/4pukP+Rcpb/mHab/5x5n/+deaD/nXmg/5l3nP+LbpD/iGyO/4hsjv+IbY7/iG2O/4ltjv+NcJL/lHOX/5l3nP+deaD/nXmg/515oP+afaX/hZjI/2aw6P9QtvD/bqrg/4WYyP+FmMj/hZjI/4WYyP+FmMj/hZjI/4WYyP+FmMj/hZjI/4WYyP+FmMj/hZjI/4WYyP+FmMj/hZjI/4WYyP+FmMj/hZjI/4WYyP+FmMj/hZjI/4WYyP+FmMj/hZjI/4WYyP+FmMj/hZjI/4WYyP+AnM3/ZrDo/1C28P9ksur/ZrDo/2aw6P9msOj/ZrDo/2aw6P9msOj/ZrDo/2aw6P9msOj/ZrDo/2aw6P9msOj/ZrDo/2aw6P9msOj/ZrDo/2aw6P9msOj/ZrDo/2aw6P9msOj/ZrDo/2aw6P9msOj/ZrDo/2aw6P9msOj/ZrDo/2aw6P9htO3/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoAAAAEAAAACAAAAABACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVbTt/16v5v83dZv/M3CT/zRwlf9JkL7/QYSu/zNvk/80cZX/PoCp/1qo3v8/g63/NHGW/0eOu/9erub/XLLq/1+w6P+CeqH/HiIl/2p5gf9danH/LCc0/yMjKv9qeIH/aniA/xcZHf8hJCv/XGhw/2l4gP85QUb/NzVF/3Wj1v9fsOj/ZFt4/09jbP+x2/D/rtjs/xcbHv87SlH/sdvw/7Hb8P8yPkT/f56t/7Hb8P+u1+v/sNrv/0FRWf9Pe6L/X7Do/0E/U/9nkaP/l9Tw/5fU8P87VF//W4GR/5fU8P+X1PD/UXKB/2eOoP9zoLT/OE5Y/5fU8P9ehJX/NVt4/1+w6P8gIi3/cLjW/3vJ6v9zu9r/V4+n/2yy0P9xuNb/fs7w/12Ysf8kAAD/SgAA/yQ7Rf9+zvD/WZKq/y5Ra/9ZqN3/EyIp/2XH7v9Vp8j/P3uT/2PD6v9lxu7/MmJ1/2HA5v9fu+H/GwkK/7ECAv8dOUX/Zcjw/0iOqv8uUWv/RIm1/xtGV/9NwfD/MHiV/xtCUv9NwfD/TMHv/w4iKv89mr7/TcHv/xAnMP+PAwP/FjhF/03B8P82iar/LlFr/ytgf/8VSl7/J4aq/xE6Sv8FEhf/JoWp/yR9n/8BAwT/F1Fn/yeGqv8PNEL/gwAA/wsmMf8nhqr/G154/y5Ra/85cpb/QjdJ/0RDQ/9nZ2f/RDMz/zg3N/9SUlL/PCEh/0IYGP9nZ2f/VFRU/30BAf9rBgn/Xhwk/0wyQv9Pd53/X7Do/494n/+amZn/5+fn/5aKiv+pp6f/pqWl/4sdHf+SODj/6+vr/9jY2P+Uj4//eWxs/4s4Rf+mbZD/dqTY/1+w6P+PeJ//n56e//T09P+/vb3/y8rK/356ev+sEBD/kzk5//f39//c3Nz/jYuL/83Nzf9xVlz/pm2Q/3ak2P9fsOj/j3if/5eWlv/4+Pj/f11d/5SRkf/Z2dn/g1RU/5A2Nv/09PT/2NjY/0Q4OP/d3d3/eGtu/6ZtkP92pNj/X7Do/494n/+OjY3/6+vr/3hjY/+uq6v/5+fn/4BUVf+IODn/5ubm/9jY2P9bVVX/6+vr/31qbv+mbZD/dqTY/1+w6P+PeJ//goCB/9nZ2f/k5OT/8/Pz/7e2tv+FNkL/dkNK/9TU1P/i4uL/7+/v/9rZ2v91Qkz/pm2Q/3ak2P9fsOj/lH+n/2BLYP9iTWL/aFNo/2pTaf9/W3b/pW2P/3lXcf9hTWH/Y05j/2tVav9zVm//oWuN/6B1mv92pNj/XLLq/3Wk1/91pNf/daTX/3Wk1/91pNf/daTX/3Wk1/91pNf/daTX/3Wk1/91pNf/daTX/3Wk1/91pNf/a6zi/wAArEEAAKxBAACsQQAArEEAAKxBAACsQQAArEEAAKxBAACsQQAArEEAAKxBAACsQQAArEEAAKxBAACsQQAArEE=";
function $(id){return document.getElementById(id);}
if (!Array.prototype.indexOf) {
	Array.prototype.indexOf=function(elt) {
		var len=this.length;
		var from=Number(arguments[1]) || 0;
		from=(from < 0)
			? Math.ceil(from)
			: Math.floor(from);
		if (from < 0)
		from += len;

		for (; from < len; from++) {
			if (from in this && this[from] === elt)
			return from;
		}
		return -1;
	};
}
document.getScroll = function() {
    if (window.pageYOffset != undefined) {
        return [pageXOffset, pageYOffset];
    } else {
        var sx, sy, d = document,
            r = d.documentElement,
            b = d.body;
        sx = r.scrollLeft || b.scrollLeft || 0;
        sy = r.scrollTop || b.scrollTop || 0;
        return [sx, sy];
    }
}
function getElementOffset( el ) {
    var _x = 0;
    var _y = 0;
    while( el && !isNaN( el.offsetLeft ) && !isNaN( el.offsetTop ) ) {
        _x += el.offsetLeft - el.scrollLeft;
        _y += el.offsetTop - el.scrollTop;
        el = el.offsetParent;
    }
    return { top: _y, left: _x };
}
function dayNo(y,m,d){
  return --m>=0 && m<12 && d>0 && d<29+(  
           4*(y=y&3||!(y%25)&&y&15?0:1)+15662003>>m*2&3  
         ) && m*31-(m>1?(1054267675>>m*3-6&7)-y:0)+d;
}
function GetPrevPeriodDaysRange(OldStart,OldEnd)
{
	var IsWeek=false;
	var IsMonth=false;
	var IsYear=false;
	var IsOneDay=false;
	OldStart.setHours(0);
	OldStart.setMinutes(0);
	OldStart.setSeconds(0);
	OldStart.setMilliseconds(0);
	OldEnd.setHours(0);
	OldEnd.setMinutes(0);
	OldEnd.setSeconds(0);
	OldEnd.setMilliseconds(0);
	var OldStartLastDayOfMonth=new Date(OldStart.getFullYear(),OldStart.getMonth()+1,0);
	var OldEndLastDayOfMonth=new Date(OldEnd.getFullYear(),OldEnd.getMonth()+1,0);
	var OldStartDayOfWeek=OldStart.getDay();
	var OldEndDayOfWeek=OldEnd.getDay();
	var OldStartY=parseInt(OldStart.getFullYear());
	var OldStartM=OldStart.getMonth()+1;
	var OldStartD=OldStart.getDate();
	var OldEndY=parseInt(OldEnd.getFullYear());
	var OldEndM=OldEnd.getMonth()+1;
	var OldEndD=OldEnd.getDate();
	var OldStartDOY=dayNo(OldStartY,OldStartM,OldStartD);
	var OldEndDOY=dayNo(OldEndY,OldEndM,OldEndD);
	var Period=OldEndDOY-OldStartDOY;
	if(OldStartY==OldEndY && OldStartDOY==OldEndDOY)
	{
		IsOneDay=true;
	}
	else if(OldStartY==OldEndY && OldStartM==OldEndM && OldStartD==1 && OldEndD==OldEndLastDayOfMonth.getDate())
	{
		IsMonth=true;
	}
	else if(OldStartY==OldEndY && OldStartM==1 && OldStartD==1 && OldEndM==12 && OldEndD==31)
	{
		IsYear=true;
	}
	else if(OldStartY==OldEndY && Period==6)
	{
		IsWeek=true;
	}
	var Res=new Object;
	var NewStart=new Date;
	var NewEnd=new Date;
	if(IsWeek)
	{
		NewEnd=GetPrevDay(OldStart);
		NewStart=new Date(NewEnd);
		NewStart.setDate(NewEnd.getDate()-6);
	}
	else if(IsMonth)
	{
		NewEnd=GetPrevDay(OldStart);
		NewStart=new Date(NewEnd.getFullYear(),NewEnd.getMonth(),1);
	}
	else if(IsYear)
	{
		NewEnd=GetPrevDay(OldStart);
		NewStart=new Date(NewEnd);
		NewStart.setMonth(0);
		NewStart.setDate(1);
	}
	else if(IsOneDay)
	{
		NewStart=GetPrevDay(OldStart);
		NewEnd=GetPrevDay(OldEnd);
	}
	else
	{
		NewEnd=GetPrevDay(OldStart);
		NewStart=new Date(NewEnd);
		NewStart.setDate(NewEnd.getDate()-Period);
	}
	Res['Start']=NewStart;
	Res['End']=NewEnd;
	return Res;
}
function GetNextPeriodDaysRange(OldStart,OldEnd)
{
	var IsWeek=false;
	var IsMonth=false;
	var IsYear=false;
	var IsOneDay=false;
	OldStart.setHours(0);
	OldStart.setMinutes(0);
	OldStart.setSeconds(0);
	OldStart.setMilliseconds(0);
	OldEnd.setHours(0);
	OldEnd.setMinutes(0);
	OldEnd.setSeconds(0);
	OldEnd.setMilliseconds(0);
	var OldStartLastDayOfMonth=new Date(OldStart.getFullYear(),OldStart.getMonth()+1,0);
	var OldEndLastDayOfMonth=new Date(OldEnd.getFullYear(),OldEnd.getMonth()+1,0);
	var OldStartDayOfWeek=OldStart.getDay();
	var OldEndDayOfWeek=OldEnd.getDay();
	var OldStartY=parseInt(OldStart.getFullYear());
	var OldStartM=OldStart.getMonth()+1;
	var OldStartD=OldStart.getDate();
	var OldEndY=parseInt(OldEnd.getFullYear());
	var OldEndM=OldEnd.getMonth()+1;
	var OldEndD=OldEnd.getDate();
	var OldStartDOY=dayNo(OldStartY,OldStartM,OldStartD);
	var OldEndDOY=dayNo(OldEndY,OldEndM,OldEndD);
	var Period=OldEndDOY-OldStartDOY;
	if(OldStartY==OldEndY && OldStartDOY==OldEndDOY)
	{
		IsOneDay=true;
	}
	else if(OldStartY==OldEndY && OldStartM==OldEndM && OldStartD==1 && OldEndD==OldEndLastDayOfMonth.getDate())
	{
		IsMonth=true;
	}
	else if(OldStartY==OldEndY && OldStartM==1 && OldStartD==1 && OldEndM==12 && OldEndD==31)
	{
		IsYear=true;
	}
	else if(OldStartY==OldEndY && Period==6)
	{
		IsWeek=true;
	}
	var Res=new Object;
	var NewStart=new Date;
	var NewEnd=new Date;
	if(IsWeek)
	{
		NewStart=GetNextDay(OldEnd);
		NewEnd=new Date(NewStart);
		NewEnd.setDate(NewStart.getDate()+6);
	}
	else if(IsMonth)
	{
		NewStart=GetNextDay(OldEnd);
		NewEnd=new Date(NewStart.getFullYear(),NewStart.getMonth()+1,0);
	}
	else if(IsYear)
	{
		NewStart=GetNextDay(OldEnd);
		NewEnd=new Date(NewStart);
		NewEnd.setMonth(11);
		NewEnd.setDate(31);
	}
	else if(IsOneDay)
	{
		NewStart=GetNextDay(OldStart);
		NewEnd=GetNextDay(OldEnd);
	}
	else
	{
		NewStart=GetNextDay(OldEnd);
		NewEnd=new Date(NewStart);
		NewEnd.setDate(NewStart.getDate()+Period);
	}
	Res['Start']=NewStart;
	Res['End']=NewEnd;
	return Res;
}
function GetNextDay(inputDayObj)
{
	var next=new Date(inputDayObj);
	next.setDate(next.getDate()+1);
	return next;
}
function GetPrevDay(inputDayObj)
{
	var next=new Date(inputDayObj);
	next.setDate(next.getDate()-1);
	return next;
}
function ConvertInputDateTimeToDateString(inputDate)
{
	inputDate=inputDate.toUpperCase();
	inputDate=inputDate.split(" ");
	var time=inputDate.pop();
	var time=time.split(":");
	var Hour24=true;
	var PM=false;
	if(time[1].indexOf("PM")>0){PM=true;Hour24=false;}
	if(time[1].indexOf("AM")>0){PM=false;Hour24=false;}
	if(!Hour24)
	{
		var seconds=time.pop();
		if(PM)
		{
			seconds=seconds.split("PM");
			time.push(seconds[0]);
			var h=time[0]*1+0;
			if(h==12){h=0;}
			h=h+12;while(h>24)h-=24;
			h=""+h;
			while(h.length<2)h="0"+h;
			time[0]=h;
		}
		else
		{
			seconds=seconds.split("AM");
			time.push(seconds[0]);
			var h=time[0]*1+0;
			if(h==12){h=0;}
			h=""+h;
			while(h.length<2)h="0"+h;
			time[0]=h;
		}
	}
	time=time.join(":");
	inputDate.push(time);
	inputDate=inputDate.join("T");
	inputDate+=":00";
	return inputDate;
}
var Timers=null;
var NextTimerID=1;
function TimerFunction(TimerID)
{
	if(Timers==null)return;
	TimerID=parseInt(TimerID)
	if(!TimerID)return;
	Timer=Timers[TimerID];
	if(!Timer)return;
	delete Timers[TimerID];
	Timer.func.call(Timer.obj);
}
function TimerCreate(obj,callback,interval)//returns TimerID
{
	if(!callback)return null;
	if(!interval)return null;
	if(Timers==null)Timers=new Object;
	var TimerID=NextTimerID++;
	var Timer={obj:obj,func:callback,interval:interval,TimerID:TimerID,id:window.setTimeout(TimerFunction,interval,TimerID)};
	Timers[TimerID]=Timer;
	return TimerID;
}
function TimerDestroy(TimerID)
{
	if(!Timers)return;
	TimerID=parseInt(TimerID)
	if(!TimerID)return;
	Timer=Timers[TimerID];
	if(!Timer)return;
	window.clearTimeout(Timer.id);
	delete Timers[TimerID];
}
function TimerClearAll()
{
	if(!Timers)return;
	keys=Object.keys(Timers);
	var c=keys.length;
	for(var i=0;i<c;i++)
	{
		var Timer=Timers[keys[i]];
		if(!Timer)continue;
		delete Timers[keys[i]];
		if(!Timer.id)continue;
		window.clearTimeout(Timer.id);
	}
	Timers=null;
}
function TimerPauseAll()
{
	if(!Timers)return;
	keys=Object.keys(Timers);
	var c=keys.length;
	for(var i=0;i<c;i++)
	{
		var Timer=Timers[keys[i]];
		if(!Timer)continue;
		window.clearTimeout(Timer.id);
		Timer.id=null;
	}
}
function TimerUnPauseAll()
{
	if(!Timers)return;
	keys=Object.keys(Timers);
	var c=keys.length;
	for(var i=0;i<c;i++)
	{
		var Timer=Timers[keys[i]];
		if(!Timer)continue;
		if(Timer.id)continue;
		Timer.id=window.setTimeout(TimerFunction,Timer.interval,Timer.TimerID);
	}
}
var RegisteredCookieNames=new Array();
function cookieCreate(name,value,days)
{
	if(RegisteredCookieNames.indexOf(name)<0 && days>-1)
	{
		RegisteredCookieNames.push(name);
	}
	if(days==undefined)
	{
		days=0;
	}
	if(days)
	{
		var date=new Date();
		date.setTime(date.getTime()+(days*86400000));
		var expires="; expires="+date.toGMTString();
	}
	else var expires="";
	var pathname=window.location.pathname;
	pathname=pathname.split("/");
	var c=pathname.length;
	if(c!=0)
	{
		var end=pathname[c-1];
		if(end!="")pathname[c-1]="";
	}
	pathname=pathname.join("/");
	document.cookie=name+"="+encodeURIComponent(value)+expires+"; path="+pathname;
}
function cookieRead(name)
{
	var nameEQ=name+"=";
	var ca=document.cookie.split(';');
	for(var i=0;i<ca.length;i++)
	{
		var c=ca[i];
		while(c.charAt(0)==' ')
		{
			c=c.substring(1,c.length);
		}
		if (c.indexOf(nameEQ)==0)
		{
			if(RegisteredCookieNames.indexOf(name)<0)
			{
				RegisteredCookieNames.push(name);
			}
			return decodeURIComponent(c.substring(nameEQ.length,c.length));
		}
	}
	return null;
}
function cookieErase(name)
{
	try
	{
		if(RegisteredCookieNames.indexOf(name)>-1)
		{
			RegisteredCookieNames.splice(RegisteredCookieNames.indexOf(name),1);
		}
	}
	catch(e)
	{
	}
	cookieCreate(name,"",-1);
}
function encodeEscapeSequence(data) {
    var regexp=/\\[tnr\\]/g;

    if (regexp.test(data)) {
        data=data.replace(regexp, function (match) {
            switch (match) {
                case '\\t' : return '\\x09';
                case '\\n' : return '\\x0a';
                case '\\r' : return '\\x0d';
            }

            return '\\x5c';
        });
    }

    var regexp=/\\[Xx][0-9A-Fa-f]{2}/g;

    if (regexp.test(data)) {
        data=data.replace(regexp, function (match) {
            return String.fromCharCode(parseInt(match.slice(2), 16));
        });
    }

    return data;
}
function htmlentities(e){return e.replace(/[^]/g,function(e){return"&#"+e.charCodeAt(0)+";"})}
function ClearNodeChildren(myNode)
{
	while (myNode.firstChild) {
		myNode.removeChild(myNode.lastChild);
	}
}
function MakeAntiScroll(obj)
{
	if(!obj)return;
	function MakeAntiScrollTouchStart(w)
	{
		var event=w || window.event;
		if(event.preventDefault)
		{
			event.preventDefault();
		}
	}
	function MakeAntiScrollTouchMove(w)
	{
		var event=w || window.event;
		if(event.preventDefault)
		{
			event.preventDefault();
		}
	}
	function MakeAntiScrollTouchEnd(w)
	{
		var event=w || window.event;
		if(event.preventDefault)
		{
			event.preventDefault();
		}
	}
	//obj.addEventListener("touchstart",MakeAntiScrollTouchStart,false);
	obj.addEventListener("touchmove",MakeAntiScrollTouchMove,false);
	//obj.addEventListener("touchend",MakeAntiScrollTouchEnd,false);
	var Config={attributes:true,childList:false,subtree:true};
	function MakeAntiScrollMutationCallback(mutationsList,observer)
	{
		
	}
	var MakeAntiScrollObserver=new MutationObserver(MakeAntiScrollMutationCallback);
	MakeAntiScrollObserver.observe(obj,Config);
}
var WebJockeyIP="127.0.0.1";
var WebJockeyPort="62187";
var CommonWebJockeyAIURL="IP="+WebJockeyIP+"&Port="+WebJockeyPort;
var LastOpenedDirectory="";
var LastUsedFilter="*.m3u;*.pls;*.mp3;*.aac;*.wav;*.bpwjssp";
var SeekToTime="0.0";
var WBDJCPTID=null;
var WJLastTime=-2;
var WJLastID="";
var SongChangeCallback=null;
var DJNowPlayingRefreshTimeoutID=null;
var Ajax=null;
var ct="Content-type",ctt="application/x-www-form-urlencoded";
var ailoc="bpwjai.php";
var Settings_LoginTimeout=300;
var LogonAuths=null;
var LastSearch=null;
var NowPlayingTitleSpan=null;
var NowPlayingIDSpan=null;
var NowPlayingTimeSpan=null;
var NowPlayingRemainingSpan=null;
var DJFileInfoButton=null;
var LastWJListIDs=new Array(0);
var LastWJListTimes=new Array(0);
var LastWJListTitles=new Array(0);
var LastWJPlayedIDs=new Array(0);
var LastWJPlayedIPs=new Array(0);
var LastWJPlayedTimes=new Array(0);
function getAjaxIFace()
{
	if(window.XMLHttpRequest)
	{
		return new XMLHttpRequest();
	}
	else
	{
		return new ActiveXObject("Microsoft.XMLHTTP");
	}
}
function WebJockeyParameterize(tt)
{
	var Res=CommonWebJockeyAIURL;
	var tt=tt.split("\r\n");
	var c=tt.length;
	for(var i=1;i<=c;i++)
	{
		Res+="&Param"+i+"="+tt[i-1];
	}
	return Res;
}
function RunAjax(query,func,anAjaxObj)
{
	if(!anAjaxObj)
	{
		anAjaxObj=Ajax;
		if(!anAjaxObj)
		{
			anAjaxObj=getAjaxIFace();
			if(!anAjaxObj)
			{
				return;
			}
		}
	}
	anAjaxObj.abort();
	anAjaxObj.RunAjaxReadStateChangeFunc=func;
	anAjaxObj.onreadystatechange=function()
	{
		if(this.readyState!=4)return;
		if(this.responseText=="LoginExpired\r\n\r\n")
		{
			ClearNodeChildren(document.body);
			OverlayMessage("Your login session has expired.",function(){location.reload();});
			return;
		}
		var func=this.RunAjaxReadStateChangeFunc;
		if(!func)
		{
			OverlayMessage("Internal error, please contact the developer.");
			return;
		}
		this.RunAjaxReadStateChangeFunc=null;
		delete this.RunAjaxReadStateChangeFunc;
		this.onreadystatechange=null;
		func.call(this);
	}
	anAjaxObj.open("POST",ailoc,true);
	anAjaxObj.setRequestHeader(ct,ctt);
	anAjaxObj.send(query);
}
function RunSpecialAjax(loc,query,func,anAjaxObj)
{
	if(!anAjaxObj)
	{
		anAjaxObj=Ajax;
		if(!anAjaxObj)
		{
			anAjaxObj=getAjaxIFace();
			if(!anAjaxObj)
			{
				return;
			}
		}
	}
	if(loc==""){loc=ailoc;}
	anAjaxObj.abort();
	anAjaxObj.RunAjaxReadStateChangeFunc=func;
	anAjaxObj.onreadystatechange=function()
	{
		if(this.readyState!=4)return;
		var func=this.RunAjaxReadStateChangeFunc;
		if(!func)
		{
			OverlayMessage("Internal error, please contact the developer.");
			return;
		}
		this.RunAjaxReadStateChangeFunc=null;
		delete this.RunAjaxReadStateChangeFunc;
		this.onreadystatechange=null;
		func.call(this);
	}
	anAjaxObj.open("POST",loc,true);
	anAjaxObj.timeout=StarWebPrintTimeOut;
	anAjaxObj.setRequestHeader(ct,ctt);
	anAjaxObj.withCredentials=true;
	anAjaxObj.send(query);
}
function MultiRunAjax(canfArray,callback)
{
	var l=canfArray.length;
	if(l==0)
	{
		if(callback)
		{
			callback.call(canfArray);
		}
		return;
	}
	for(var i=0;i<l;i++)
	{
		canfArray[i]['ajax']=getAjaxIFace();
		canfArray[i]['ajax'].canfArray=canfArray;
		canfArray[i]['ajax'].func=canfArray[i]['func'];
		canfArray[i]['ajax'].callback=callback;
		canfArray[i]['ajax'].done=false;
		canfArray[i]['ajax'].onreadystatechange=function()
		{
			if(this.readyState!=4)return;
			if(this.responseText=="LoginExpired\r\n\r\n")
			{
				ClearNodeChildren(document.body);
				OverlayMessage("Your login session has expired.",function(){location.reload();});
				return;
			}
			var func=this.func;
			if(!func){OverlayMessage("Internal error, please contact the developer.");return;}
			delete this.func;
			this.onreadystatechange=null;
			func.call(this);
			this.done=true;
			var canfArray=this.canfArray;
			var c=canfArray.length;
			for(var i=0;i<c;i++)
			{
				if(!canfArray[i]['ajax'].done)return;
			}
			this.callback.call(canfArray);
		};
	}
	for(var i=0;i<l;i++)
	{
		var query=canfArray[i]['query'];
		var anAjaxObj=canfArray[i]['ajax'];
		anAjaxObj.open("POST",ailoc,true);
		anAjaxObj.setRequestHeader(ct,ctt);
		anAjaxObj.send(query);
	}
}
var WaitObj=null;
function OverlayWaitClose()
{
	if(WaitObj)
	{
		WaitObj.Close();
	}
	else
	{
		var WaitObj=document.getElementById("OverlayWaitDiv");
		if(WaitObj)
		{
			WaitObj.Close();
		}
	}
}
function OverlayWait(Text)
{
    if(!Text){Text="";}
	var LastFocused=document.activeElement;
	if(WaitObj)
    {
        LastFocused=WaitObj.LastFocused;
		ClearNodeChildren(WaitObj);
        if(WaitObj.parentNode)
        {
            WaitObj.parentNode.removeChild(WaitObj);
        }
        delete WaitObj.Close;
        WaitObj=null;
    }
	WaitObj=document.createElement("div");
	WaitObj.tabIndex=0;
	WaitObj.id="OverlayWaitDiv";
	WaitObj.className="OverlayMessageDiv";
	var OverlayWaitDivSpan=document.createElement("span");
	OverlayWaitDivSpan.id="OverlayWaitDivSpan";
	OverlayWaitDivSpan.className="OverlayMessageDivSpan";
	WaitObj.OverlayWaitDivSpan=OverlayWaitDivSpan;
	WaitObj.appendChild(OverlayWaitDivSpan);
	var h1=document.createElement("h1");
	h1.appendChild(document.createTextNode("Please wait..."));
	OverlayWaitDivSpan.appendChild(h1);
	if(Text)
	{
		if(Text!="")
		{
			var h2=document.createElement("h2");
			h2.appendChild(document.createTextNode(Text));
			OverlayWaitDivSpan.appendChild(h2);
		}
	}
	document.body.insertBefore(WaitObj,null);
	WaitObj.LastFocused=LastFocused;
	WaitObj.focus();
	WaitObj.Close=function()
	{
		var obj=null;
		if(this)
		{
			obj=this;
		}
		else
		{
			obj=WaitObj;
		}
		if(obj!=WaitObj)return;
		var LastFocused=obj.LastFocused;
		if(obj.parentNode)
		{
			obj.parentNode.removeChild(obj);
		}
		delete obj.Close;
		ClearNodeChildren(obj);
		WaitObj=null;
		if(LastFocused)
		{
			if(LastFocused.parentNode)
			{
				try
				{
					LastFocused.focus();
				}
				catch(e)
				{
					alert(e);
				}
			}
		}
	}
	return WaitObj;
}
var OverlayAskDiv=null;
function OverlayAsk(Text,Options,ReturnFunc)
{
	if(!ReturnFunc)return null;
	if(OverlayAskDiv)
	{
		if(OverlayAskDiv.ReturnFunc)
		{
			OverlayAskDiv.ReturnFunc.call(OverlayAskDiv,null);
		}
		ClearNodeChildren(OverlayAskDiv);
		if(OverlayAskDiv.parentNode)
		{
			OverlayAskDiv.parentNode.removeChild(OverlayAskDiv);
		}
		delete OverlayAskDiv;
		OverlayAskDiv=null;
	}
	if(Text=="" || Options==null)
	{
		ReturnFunc.call(null,undefined);
		return;
	}
	OverlayAskDiv=document.createElement("div");
	OverlayAskDiv.tabIndex=0;
	OverlayAskDiv.id="OverlayAskDiv";
	OverlayAskDiv.className="OverlayAskDiv";
	OverlayAskDiv.ReturnFunc=ReturnFunc;
	var OverlayAskDivSpan=document.createElement("span");
	OverlayAskDivSpan.id="OverlayAskDivSpan";
	OverlayAskDivSpan.className="OverlayAskDivSpan";
	OverlayAskDiv.OverlayAskDivSpan=OverlayAskDivSpan;
	OverlayAskDiv.appendChild(OverlayAskDivSpan);
	var h1=document.createElement("h1");
	Text=Text.split("\r\n");
	Text=Text.join("\n");
	Text=Text.split("\r");
	Text=Text.join("\n");
	Text=Text.split("\n");
	var tl=Text.length;
	for(var i=0;i<tl;i++)
	{
		if(i!=0){h1.appendChild(document.createElement("br"));}
		h1.appendChild(document.createTextNode(Text[i]));
	}
	//h1.appendChild(document.createTextNode(Text));
	OverlayAskDivSpan.appendChild(h1);
	OverlayAskDivSpan.appendChild(document.createElement("br"));
	for (var key in Options) {
		if (Object.prototype.hasOwnProperty.call(Options, key)) {
			var val = Options[key];
			var button=document.createElement("button");
			button.appendChild(document.createTextNode(key));
			button.OverlayAskDiv=OverlayAskDiv;
			button.Key=key;
			button.Val=val;
			button.onclick=function()
			{
				if(this.OverlayAskDiv!=OverlayAskDiv)return;
				var val=this.Val;
				var ReturnFunc=OverlayAskDiv.ReturnFunc;
				ClearNodeChildren(OverlayAskDiv);
				if(OverlayAskDiv.parentNode)
				{
					OverlayAskDiv.parentNode.removeChild(OverlayAskDiv);
				}
				ReturnFunc.call(OverlayAskDiv,val);
				delete OverlayAskDiv;
				OverlayAskDiv=null;
			}
			OverlayAskDivSpan.appendChild(button);
		}
	}
	OverlayAskDiv.onclick=function()
	{
		if(this!=OverlayAskDiv)return;
		var gg=OverlayAskDiv.ReturnFunc;
		if(gg)
		{
			gg.call(OverlayAskDiv,null);
		}
		ClearNodeChildren(OverlayAskDiv);
		if(OverlayAskDiv.parentNode)
		{
			OverlayAskDiv.parentNode.removeChild(OverlayAskDiv);
		}
		delete OverlayAskDiv;
		OverlayAskDiv=null;
		if(!gg)
		{
			document.body.focus();
		}
	};
	OverlayAskDiv.onkeypress=OverlayAskDiv.onclick;
	document.body.insertBefore(OverlayAskDiv,null);
	OverlayAskDiv.focus();
	return OverlayAskDiv;
}
var OverlayMessageDiv=null;
function OverlayMessage(Text,ReturnFunc)
{
	if(!ReturnFunc){ReturnFunc=null;}
	if(OverlayMessageDiv)
	{
		if(OverlayMessageDiv.ReturnFunc)
		{
			OverlayMessageDiv.ReturnFunc.call(OverlayMessageDiv);
		}
		ClearNodeChildren(OverlayMessageDiv);
		if(OverlayMessageDiv.parentNode)
		{
			OverlayMessageDiv.parentNode.removeChild(OverlayMessageDiv);
		}
		delete OverlayMessageDiv;
		OverlayMessageDiv=null;
	}
	OverlayMessageDiv=document.createElement("div");
	OverlayMessageDiv.tabIndex=0;
	OverlayMessageDiv.id="OverlayMessageDiv";
	OverlayMessageDiv.className="OverlayMessageDiv";
	OverlayMessageDiv.ReturnFunc=ReturnFunc;
	var OverlayMessageDivSpan=document.createElement("span");
	OverlayMessageDivSpan.id="OverlayMessageDivSpan";
	OverlayMessageDivSpan.className="OverlayMessageDivSpan";
	OverlayMessageDiv.OverlayMessageDivSpan=OverlayMessageDivSpan;
	OverlayMessageDiv.appendChild(OverlayMessageDivSpan);
	var h1=document.createElement("h1");
	h1.appendChild(document.createTextNode(Text));
	OverlayMessageDivSpan.appendChild(h1);
	OverlayMessageDiv.onclick=function()
	{
		if(this!=OverlayMessageDiv)return;
		var gg=OverlayMessageDiv.ReturnFunc;
		if(gg)
		{
			gg.call(OverlayMessageDiv);
		}
		ClearNodeChildren(OverlayMessageDiv);
		if(OverlayMessageDiv.parentNode)
		{
			OverlayMessageDiv.parentNode.removeChild(OverlayMessageDiv);
		}
		delete OverlayMessageDiv;
		OverlayMessageDiv=null;
		if(!gg)
		{
			document.body.focus();
		}
	};
	OverlayMessageDiv.onkeypress=OverlayMessageDiv.onclick;
	document.body.insertBefore(OverlayMessageDiv,null);
	OverlayMessageDiv.focus();
	return OverlayMessageDiv;
}
var lastWindowMoving=null;
function CreateWindow(Title,CloseCallback)//return true on CloseCallback to abort closing
{
	var makeWindowMovable=function(target, handle)
	{
		handle.target=target;
		target.handle=handle;
		function WindowHandleOnTouchStart(w)
		{
			var event=w || window.event;
			if(event.targetTouches.length!=1)return;
			var target=this.target;
			var handle=target.handle;
			var touch=event.targetTouches[0];
			target.OldZIndex=target.style.zIndex;
			target.OldCursor=target.style.cursor;
			target.style.cursor="grabbing";
			target.style.zIndex="100";
			lastWindowMoving=target;
			var initialXOffset=0;
			var initialYOffset=0;
			if(event.preventDefault)
			{
				event.preventDefault();
			}
			if("pageX" in touch)
			{
				initialXOffset=target.offsetLeft - touch.pageX;
				initialYOffset=target.offsetTop - touch.pageY;
			}
			else
			{
				initialXOffset=target.offsetLeft - touch.clientX;
				initialYOffset=target.offsetTop - touch.clientY;
			}
			function WindowHandleOnTouchMove(w)
			{
				var event=w || window.event;
				if(event.targetTouches.length!=1)
				{
					WindowHandelOnTouchEnd.call(document,w);
					return;
				}
				var touch=event.targetTouches[0];
				var x=0,y=0;
				if("pageX" in touch)
				{
					x=(touch.pageX + initialXOffset);
					y=(touch.pageY + initialYOffset); 
				}
				else
				{
					x=(touch.clientX + initialXOffset);
					y=(touch.clientY + initialYOffset); 
				}
				if(x<0){x=0;}
				if(y<0){y=0;}
				lastWindowMoving.style.left=x+"px";
				lastWindowMoving.style.top=y+"px";
			}
			function WindowHandelOnTouchEnd(w)
			{
				document.removeEventListener("touchmove",WindowHandleOnTouchMove);
				document.removeEventListener("touchend",WindowHandelOnTouchEnd);
				if(event.preventDefault)
				{
					event.preventDefault();
				}
				if(lastWindowMoving)
				{
					lastWindowMoving.style.cursor="";
					lastWindowMoving.style.zIndex="";
					delete lastWindowMoving.OldCursor;
					delete lastWindowMoving.OldZIndex;
					WindowOnFocus.call(lastWindowMoving,w);
					lastWindowMoving=null;
				}
			}
			document.addEventListener("touchmove",WindowHandleOnTouchMove);
			document.addEventListener("touchend",WindowHandelOnTouchEnd);
			return false;
		}
		handle.addEventListener("touchstart",WindowHandleOnTouchStart);
		function WindowHandleOnMouseDown(w)
		{
			var event=w || window.event;
			var target=this.target;
			var handle=target.handle;
			target.OldZIndex=target.style.zIndex;
			target.OldCursor=target.style.cursor;
			target.style.cursor="grabbing";
			target.style.zIndex="100";
			lastWindowMoving=target;
			var initialXOffset=0;
			var initialYOffset=0;
			if(event.preventDefault)
			{
				event.preventDefault();
			}
			if("pageX" in event)
			{
				initialXOffset=target.offsetLeft - event.pageX;
				initialYOffset=target.offsetTop - event.pageY;
			}
			else
			{
				initialXOffset=target.offsetLeft - event.clientX;
				initialYOffset=target.offsetTop - event.clientY;
			}
			function WindowHandleOnMouseMove(w)
			{
				var event=w || window.event;
				var target=lastWindowMoving;
				if(!target){WindowHandleOnMouseUp.call(document,w);}
				var x=0,y=0;
				if("pageX" in event)
				{
					x=(event.pageX + initialXOffset);
					y=(event.pageY + initialYOffset); 
				}
				else
				{
					x=(event.clientX + initialXOffset);
					y=(event.clientY + initialYOffset); 
				}
				if(x<0){x=0;}
				if(y<0){y=0;}
				target.style.left=x+"px";
				target.style.top=y+"px";
			}
			function WindowHandleOnMouseUp(w)
			{
				document.removeEventListener("mousemove",WindowHandleOnMouseMove)
				document.removeEventListener("mouseup",WindowHandleOnMouseUp)
				if(lastWindowMoving)
				{
					lastWindowMoving.style.cursor=lastWindowMoving.OldCursor;
					lastWindowMoving.style.zIndex=lastWindowMoving.OldZIndex;
					delete lastWindowMoving.OldCursor;
					delete lastWindowMoving.OldZIndex;
					WindowOnFocus.call(lastWindowMoving,w);
					lastWindowMoving=null;
				}
			}
			document.addEventListener("mousemove",WindowHandleOnMouseMove);
			document.addEventListener("mouseup",WindowHandleOnMouseUp);
			return false;
		}
		handle.addEventListener("mousedown",WindowHandleOnMouseDown);
	}
	function WindowOnAny(w)
	{
		var event=w || window.event;
		try{event.cancelBubble=true;}catch(e){}
		try{event.stopPropogation();}catch(e){}
	};
	function WindowOnFocus(w)
	{
		var event=w || window.event;
		var parent=this.parentNode;
		if(parent)
		{
			if("pageX" in event)
			{
				initialXOffset=this.offsetLeft;
				initialYOffset=this.offsetTop;
			}
			else
			{
				initialXOffset=this.offsetLeft;
				initialYOffset=this.offsetTop;
			}
			try
			{
				if(parent.lastChild==this)return;
			}catch(e){}
			try{parent.removeChild(this);}catch(e){}
			this.style.left=initialXOffset+"px";
			this.style.top=initialYOffset+"px";
			parent.appendChild(this);
		}
		else
		{
			document.appendChild(this);
		}
	}
	var Window=document.createElement("div");
	Window.className="Window";
	Window.CloseCallback=CloseCallback;
	Window.style.position="absolute";
	Window.tabIndex=0;
	try
	{
		Window.style.top=event.clientY+"px";
		Window.style.left=event.clientX+"px";
	}
	catch(e)
	{
		Window.style.top=(window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0)+"px";
		Window.style.left=(window.pageXOffset || document.documentElement.scrollLeft || document.body.scrollLeft || 0)+"px";
	}/**/
	var WindowTitleBar=document.createElement("div");
	WindowTitleBar.className="WindowTitleBar";
	WindowTitleBar.appendChild(document.createTextNode(Title));
	Window.appendChild(WindowTitleBar);
	Window.WindowTitleBar=WindowTitleBar;
	var WindowIcon=document.createElement("img");
	WindowIcon.className="WindowIcon";
	WindowIcon.src=FavIconSrc;
	WindowIcon.onload=function()
	{
		this.style.width="";
	};
	WindowIcon.onerror=function()
	{
		this.style.width="0px";
	};
	Window.WindowIcon=WindowIcon;
	WindowTitleBar.insertBefore(WindowIcon,WindowTitleBar.firstChild);
	var WindowStickyButton=document.createElement("button");
	WindowStickyButton.className="WindowStickyButton";
	WindowStickyButton.type="button";
	WindowStickyButton.value="+";
	WindowStickyButton.appendChild(document.createTextNode("+"));
	var WindowCloseButton=document.createElement("button");
	WindowCloseButton.className="WindowCloseButton";
	WindowCloseButton.type="button";
	WindowCloseButton.value="X";
	WindowCloseButton.appendChild(document.createTextNode("X"));
	WindowTitleBar.insertBefore(WindowStickyButton,null);
	WindowTitleBar.insertBefore(WindowCloseButton,null);
	WindowTitleBar.WindowCloseButton=WindowCloseButton;
	WindowTitleBar.Window=Window;
	WindowCloseButton.Window=Window;
	WindowStickyButton.Window=Window;
	Window.WindowCloseButton=WindowCloseButton;
	Window.WindowStickyButton=WindowStickyButton;
	WindowCloseButton.onmousedown=function(w)
	{
		var event=w || window.event;
		event.cancelBubble=true;
	};
	WindowCloseButton.ontouchstart=WindowCloseButton.onmousedown;
	WindowStickyButton.onmousedown=WindowCloseButton.onmousedown;
	WindowStickyButton.ontouchstart=WindowCloseButton.onmousedown;
	WindowCloseButton.onclick=function()
	{
		var Window=this.Window;
		var CloseCallback=Window.CloseCallback;
		if(CloseCallback)
		{
			var Res=CloseCallback.call(Window);
			if(Res)return;
		}
		delete Window.CloseCallback;
		delete Window.WindowTitleBar.Window;
		delete Window.WindowTitleBar.WindowCloseButton;
		delete Window.WindowTitleBar;
		delete Window.WindowCloseButton;
		delete this.WindowTitleBar;
		delete this.Window;
		ClearNodeChildren(Window);
		if(Window.parentNode)
			Window.parentNode.removeChild(Window);
	};
	WindowStickyButton.onclick=function()
	{
		var Window=this.Window;
		if(Window.style.position=="absolute")
		{
			var rr=getElementOffset(Window);
			var tt=document.getScroll();
			var sLeft=tt[0];
			var sTop=tt[1];
			Window.style.position="fixed";
			Window.style.zIndex="100";
			Window.style.top=(rr.top - sTop)+"px";
			Window.style.left=(rr.left - sLeft)+"px";
			ClearNodeChildren(this);
			this.appendChild(document.createTextNode("-"));
		}
		else
		{
			var rr=getElementOffset(Window);
			var tt=document.getScroll();
			var sLeft=tt[0];
			var sTop=tt[1];
			Window.style.position="absolute";
			Window.style.zIndex="99";
			Window.style.top=(rr.top + sTop)+"px";
			Window.style.left=(rr.left + sLeft)+"px";
			ClearNodeChildren(this);
			this.appendChild(document.createTextNode("+"));
		}
		
	};
	function WindowOnInserted()
	{
		var Window=this;
		Window.removeEventListener("DOMNodeInsertedIntoDocument",WindowOnInserted);
		if(!Window.style.left=="" && !Window.style.top=="")return;
		var dd=getElementOffset(Window);
		var Width=Window.offsetWidth;
		var Height=Window.offsetHeight;
		var scrollX = window.pageXOffset;
		var scrollY = window.pageYOffset;
		if(scrollX==0){scrollX=window.scrollX;}
		if(scrollY==0){scrollY=window.scrollY;}
		var ViewportWidth=(window.innerWidth || document.documentElement.clientWidth);
		var ViewportHeight=(window.innerHeight || document.documentElement.clientHeight);
		if(dd.left+Width>=ViewportWidth)
		{
			var newLeft=((ViewportWidth-Width)/2);
			if(newLeft<0){newLeft=0;}
			Window.style.left=newLeft+"px";
		}
		else if(dd.left<0)
		{
			var newLeft=((ViewportWidth-Width)/2);
			if(newLeft<0){newLeft=0;}
			Window.style.left=newLeft+"px";
		}
		if(dd.top+Height>=ViewportHeight)
		{
			var newTop=((ViewportHeight-Height)/2);
			if(newTop<0){newTop=0;}
			Window.style.top=newTop+"px";
		}
		else if(dd.top<0)
		{
			var newTop=((ViewportHeight-Height)/2);
			if(newTop<0){newTop=0;}
			Window.style.top=newTop+"px";
		}
	}
	Window.addEventListener("click",WindowOnAny);
	Window.addEventListener("mousedown",WindowOnAny);
	//Window.addEventListener("mouseup",WindowOnAny);
	Window.addEventListener("touchstart",WindowOnAny);
	//Window.addEventListener("touchend",WindowOnAny);
	Window.addEventListener("focus",WindowOnFocus);
	var InsertedObserverOptions={attributes:true,childList:true,subtree:true,actionList:true};
	function InsertedObserverCallback(mutationList,InsertedObserver)
	{
		if(document.contains(InsertedObserver.Window))
		{
			WindowOnInserted.call(InsertedObserver.Window);
			InsertedObserver.disconnect();
		}
	}
	try
	{
		var InsertedObserver=new MutationObserver(InsertedObserverCallback);
		InsertedObserver.Window=Window;
		InsertedObserver.observe(Window, InsertedObserverOptions);/**/
	}
	catch(e)
	{
		Window.addEventListener("DOMNodeInsertedIntoDocument",WindowOnInserted);
	}
	makeWindowMovable(Window,WindowTitleBar);
	Window.style.zIndex="99";
	return Window;
}
function MakeRequired(obj)
{
	obj.setAttribute("required","");
	obj.required=true;
}
function hash_map(t)
{
	var hash=new Array();
	var key;
	while(t.length>2)
	{
		key=t.shift();
		hash[key]=t.shift();
	}
	return hash;
}
function encoded_hash_map(t)
{
	var hash=new Array();
	var key;
	var value;
	var p;
	t=t.split("&");
	while(t.length>0)
	{
		value=t.shift();
		p=value.indexOf("=");
		if(p==0)
		{
			value=value.split("=");
			value.shift();
			value=value.join("=");
			hash[""]=value.pop();
		}
		else if(p<0)
		{
			hash[value]="";
		}
		else
		{
			value=value.split("=");
			key=value.shift();
			value=value.join("=");
			hash[key]=value;
		}
	}
	return hash;
}
var TouchServerAjax=null;
var SessionTimeoutTimer=null;
function SessionTimeoutCheck()
{
	SessionTimeoutTimer=null;
	RunAjax("Command=Touch",function(){});
}
function TouchServer()
{
	if(!TouchServerAjax)
	{
		TouchServerAjax=getAjaxIFace();
		if(!TouchServerAjax)return;
	}
	if(SessionTimeoutTimer!=null)
	{
		clearTimeout(SessionTimeoutTimer);
		SessionTimeoutTimer=null;
	}
	RunAjax("Command=Touch",function(){
		var narf=this.responseText;
		narf=narf.split("\r\n");
		if(narf[0]=="UnAuth")
		{
			ClearNodeChildren(document.body);
			CheckStatus();
			//location.reload();
			return;
		}
		else if((narf[0]!="TouchReply" || narf[1]!="Ack") && this.status!=0)
		{
			OverlayMessage("An error occurred while touching the server.");
			return;
		}
		if(Settings_LoginTimeout>1)
		{
			SessionTimeoutTimer=setTimeout(SessionTimeoutCheck,(Settings_LoginTimeout+1)*1000);
		}
	},TouchServerAjax);
}
function formatTimeDispE(t)
{
	st=t%60;
	tmt=(t-st)/60;
	mt=tmt%60;
	ht=(tmt-mt)/60;
	t="";
	p="";
	if(ht!=0)
	{
		if(t!=""){t+=" ";}
		if(ht==1){p="";}else{p="s";}
		t+=ht+" hour"+p;
	}
	if(mt!=0)
	{
		if(t!=""){t+=" ";}
		if(mt==1){p="";}else{p="s";}
		t+=mt+" minute"+p;
	}
	if(st!=0)
	{
		if(t!=""){t+=" ";}
		if(st==1){p="";}else{p="s";}
		t+=st+" second"+p;
	}
	return t;
}
function formatTimeDisp(t)
{
	if(t<0){return "";}
	st=t%60;
	tmt=(t-st)/60;
	mt=tmt%60;
	ht=(tmt-mt)/60;
	if(st<10){st="0"+st;}else{st=st;}
	if(ht>0)
	{
		if(mt<10){mt="0"+mt;}else{mt=mt;}
	}else{mt=mt;}
	if(ht>0){t=ht+":"+mt+":"+st;}else{t=mt+":"+st;}
	return t;
}
function formatShortMonthText(Month)
{
	var mn=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
	Month=Month*1+0;
	Month--;
	return mn[Month];
}
function formatShortDateTimeRangeNoTime(Start,End)
{
	var mn=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
	var dw=["Sun","Mon","Tue","Wed","Thr","Fri","Sat"];
	var Syear=Start.getFullYear();
	var Smonth=Start.getMonth();
	var Sday=Start.getDate();
	var Sdow=Start.getDay();
	var Shour=Start.getHours();
	var Smin=Start.getMinutes();
	var Ssec=Start.getSeconds();
	var SM="am";
	if(Shour>=12){SM="pm";Shour-=12;}
	if(Shour==0){Shour=12;}
	var Eyear=End.getFullYear();
	var Emonth=End.getMonth();
	var Eday=End.getDate();
	var Edow=End.getDay();
	var Ehour=End.getHours();
	var Emin=End.getMinutes();
	var Esec=End.getSeconds();
	var EM="am";
	if(Ehour>=12){EM="pm";Ehour-=12;}
	if(Ehour==0){Ehour=12;}
	var lhs="";
	var rhs="";
	var res="";
	if(Syear==Eyear)
	{
		res+=""+Syear;
	}
	else
	{
		lhs+=""+Syear;
		rhs+=""+Eyear;
	}
	if(Smonth==Emonth)
	{
		if(res!=""){res+=" ";}
		res+=mn[Smonth];
	}
	else
	{
		if(lhs!=""){lhs+=" ";rhs+=" ";}
		lhs+=mn[Smonth];
		rhs+=mn[Emonth];
	}
	function formatDateTimeRangeDotM(day)
	{
		day=day*1+0;
		var filter=day;
		if(day>19)
		{
			filter=filter%20;
		}
		switch(filter)
		{
			case 1:
			return ""+day+"st";
			case 2:
			return ""+day+"nd";
			case 3:
			return ""+day+"rd";
		}
		return ""+day+"th";
	}
	if(Sday==Eday)
	{
		if(res!=""){res+=" ";}
		res+=formatDateTimeRangeDotM(Sday)+" ("+dw[Sdow]+")";
	}
	else
	{
		if(lhs!=""){lhs+=" ";rhs+=" ";}
		lhs+=formatDateTimeRangeDotM(Sday)+" ("+dw[Sdow]+")";
		rhs+=formatDateTimeRangeDotM(Eday)+" ("+dw[Edow]+")";
	}
	if(rhs=="")return res;
	if(res=="")return lhs+" - "+rhs;
	return lhs+" - "+rhs+" ["+res+"]";
}
function formatShortDateTimeRangeNoDate(Start,End)
{
	var Shour=Start.getHours();
	var Smin=Start.getMinutes();
	var Ssec=Start.getSeconds();
	var SM="am";
	if(Shour>=12){SM="pm";Shour-=12;}
	if(Shour==0){Shour=12;}
	var Ehour=End.getHours();
	var Emin=End.getMinutes();
	var Esec=End.getSeconds();
	var EM="am";
	if(Ehour>=12){EM="pm";Ehour-=12;}
	if(Ehour==0){Ehour=12;}
	var lhs="";
	var rhs="";
	var res="";
	function formatDateTimeRangeDotM(day)
	{
		day=day*1+0;
		var filter=day;
		if(day>19)
		{
			filter=filter%20;
		}
		switch(filter)
		{
			case 1:
			return ""+day+"st";
			case 2:
			return ""+day+"nd";
			case 3:
			return ""+day+"rd";
		}
		return ""+day+"th";
	}
	function formatDateTimeRangeTime(hour,min,sec)
	{
		hour=hour+":";
		if(min<10){min="0"+min+":";}else{min=min+":";}
		if(sec<10){sec="0"+sec;}else{sec=sec+"";}
		return hour+min+sec;
	}
	if(Shour==Ehour && Smin==Emin && Ssec==Esec && SM==EM)
	{
		if(res!=""){res+=" ";}
		res+=formatDateTimeRangeTime(Shour,Smin,Ssec)+" "+SM;
	}
	else
	{
		if(lhs!=""){lhs+=" ";rhs+=" ";}
		lhs+=formatDateTimeRangeTime(Shour,Smin,Ssec)+" "+SM;
		rhs+=formatDateTimeRangeTime(Ehour,Emin,Esec)+" "+EM;
	}
	if(rhs=="")return res;
	if(res=="")return lhs+" - "+rhs;
	return lhs+" - "+rhs+" ["+res+"]";
}
function formatDateTimeRangeNoTime(Start,End)
{
	var mn=["January","February","March","April","May","June","July","August","September","October","November","December"];
	var dw=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
	var Syear=Start.getFullYear();
	var Smonth=Start.getMonth();
	var Sday=Start.getDate();
	var Sdow=Start.getDay();
	var Shour=Start.getHours();
	var Smin=Start.getMinutes();
	var Ssec=Start.getSeconds();
	var SM="am";
	if(Shour>=12){SM="pm";Shour-=12;}
	if(Shour==0){Shour=12;}
	var Eyear=End.getFullYear();
	var Emonth=End.getMonth();
	var Eday=End.getDate();
	var Edow=End.getDay();
	var Ehour=End.getHours();
	var Emin=End.getMinutes();
	var Esec=End.getSeconds();
	var EM="am";
	if(Ehour>=12){EM="pm";Ehour-=12;}
	if(Ehour==0){Ehour=12;}
	var lhs="";
	var rhs="";
	var res="";
	if(Syear==Eyear)
	{
		res+=""+Syear;
	}
	else
	{
		lhs+=""+Syear;
		rhs+=""+Eyear;
	}
	if(Smonth==Emonth)
	{
		if(res!=""){res+=" ";}
		res+=mn[Smonth];
	}
	else
	{
		if(lhs!=""){lhs+=" ";rhs+=" ";}
		lhs+=mn[Smonth];
		rhs+=mn[Emonth];
	}
	function formatDateTimeRangeDotM(day)
	{
		day=day*1+0;
		var filter=day;
		if(day>19)
		{
			filter=filter%20;
		}
		switch(filter)
		{
			case 1:
			return ""+day+"st";
			case 2:
			return ""+day+"nd";
			case 3:
			return ""+day+"rd";
		}
		return ""+day+"th";
	}
	if(Sday==Eday)
	{
		if(res!=""){res+=" ";}
		res+=formatDateTimeRangeDotM(Sday)+" ("+dw[Sdow]+")";
	}
	else
	{
		if(lhs!=""){lhs+=" ";rhs+=" ";}
		lhs+=formatDateTimeRangeDotM(Sday)+" ("+dw[Sdow]+")";
		rhs+=formatDateTimeRangeDotM(Eday)+" ("+dw[Edow]+")";
	}
	if(rhs=="")return res;
	if(res=="")return lhs+" - "+rhs;
	return lhs+" - "+rhs+" ["+res+"]";
}
function formatDateTimeRange(Start,End)
{
	var mn=["January","February","March","April","May","June","July","August","September","October","November","December"];
	var dw=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
	var Syear=Start.getFullYear();
	var Smonth=Start.getMonth();
	var Sday=Start.getDate();
	var Sdow=Start.getDay();
	var Shour=Start.getHours();
	var Smin=Start.getMinutes();
	var Ssec=Start.getSeconds();
	var SM="am";
	if(Shour>=12){SM="pm";Shour-=12;}
	if(Shour==0){Shour=12;}
	var Eyear=End.getFullYear();
	var Emonth=End.getMonth();
	var Eday=End.getDate();
	var Edow=End.getDay();
	var Ehour=End.getHours();
	var Emin=End.getMinutes();
	var Esec=End.getSeconds();
	var EM="am";
	if(Ehour>=12){EM="pm";Ehour-=12;}
	if(Ehour==0){Ehour=12;}
	var lhs="";
	var rhs="";
	var res="";
	if(Syear==Eyear)
	{
		res+=""+Syear;
	}
	else
	{
		lhs+=""+Syear;
		rhs+=""+Eyear;
	}
	if(Smonth==Emonth)
	{
		if(res!=""){res+=" ";}
		res+=mn[Smonth];
	}
	else
	{
		if(lhs!=""){lhs+=" ";rhs+=" ";}
		lhs+=mn[Smonth];
		rhs+=mn[Emonth];
	}
	function formatDateTimeRangeDotM(day)
	{
		day=day*1+0;
		var filter=day;
		if(day>19)
		{
			filter=filter%20;
		}
		switch(filter)
		{
			case 1:
			return ""+day+"st";
			case 2:
			return ""+day+"nd";
			case 3:
			return ""+day+"rd";
		}
		return ""+day+"th";
	}
	if(Sday==Eday)
	{
		if(res!=""){res+=" ";}
		res+=formatDateTimeRangeDotM(Sday)+" ("+dw[Sdow]+")";
	}
	else
	{
		if(lhs!=""){lhs+=" ";rhs+=" ";}
		lhs+=formatDateTimeRangeDotM(Sday)+" ("+dw[Sdow]+")";
		rhs+=formatDateTimeRangeDotM(Eday)+" ("+dw[Edow]+")";
	}
	function formatDateTimeRangeTime(hour,min,sec)
	{
		hour=hour+":";
		if(min<10){min="0"+min+":";}else{min=min+":";}
		if(sec<10){sec="0"+sec;}else{sec=sec+"";}
		return hour+min+sec;
	}
	if(Shour==Ehour && Smin==Emin && Ssec==Esec && SM==EM)
	{
		if(res!=""){res+=" ";}
		res+=formatDateTimeRangeTime(Shour,Smin,Ssec)+" "+SM;
	}
	else
	{
		if(lhs!=""){lhs+=" ";rhs+=" ";}
		lhs+=formatDateTimeRangeTime(Shour,Smin,Ssec)+" "+SM;
		rhs+=formatDateTimeRangeTime(Ehour,Emin,Esec)+" "+EM;
	}
	if(rhs=="")return res;
	if(res=="")return lhs+" - "+rhs;
	return lhs+" - "+rhs+" ["+res+"]";
}
function formatShortDateTimeRange(Start,End)
{
	var mn=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
	var dw=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
	var Syear=Start.getFullYear();
	var Smonth=Start.getMonth();
	var Sday=Start.getDate();
	var Sdow=Start.getDay();
	var Shour=Start.getHours();
	var Smin=Start.getMinutes();
	var Ssec=Start.getSeconds();
	var SM="am";
	if(Shour>=12){SM="pm";Shour-=12;}
	if(Shour==0){Shour=12;}
	var Eyear=End.getFullYear();
	var Emonth=End.getMonth();
	var Eday=End.getDate();
	var Edow=End.getDay();
	var Ehour=End.getHours();
	var Emin=End.getMinutes();
	var Esec=End.getSeconds();
	var EM="am";
	if(Ehour>=12){EM="pm";Ehour-=12;}
	if(Ehour==0){Ehour=12;}
	var lhs="";
	var rhs="";
	var res="";
	if(Syear==Eyear)
	{
		res+=""+Syear;
	}
	else
	{
		lhs+=""+Syear;
		rhs+=""+Eyear;
	}
	if(Smonth==Emonth)
	{
		if(res!=""){res+=" ";}
		res+=mn[Smonth];
	}
	else
	{
		if(lhs!=""){lhs+=" ";rhs+=" ";}
		lhs+=mn[Smonth];
		rhs+=mn[Emonth];
	}
	function formatShortDateTimeRangeDotM(day)
	{
		day=day*1+0;
		var filter=day;
		if(day>19)
		{
			filter=filter%20;
		}
		switch(filter)
		{
			case 1:
			return ""+day+"st";
			case 2:
			return ""+day+"nd";
			case 3:
			return ""+day+"rd";
		}
		return ""+day+"th";
	}
	if(Sday==Eday)
	{
		if(res!=""){res+=" ";}
		res+=formatShortDateTimeRangeDotM(Sday)+" ("+dw[Sdow]+")";
	}
	else
	{
		if(lhs!=""){lhs+=" ";rhs+=" ";}
		lhs+=formatShortDateTimeRangeDotM(Sday)+" ("+dw[Sdow]+")";
		rhs+=formatShortDateTimeRangeDotM(Eday)+" ("+dw[Edow]+")";
	}
	function formatShortDateTimeRangeTime(hour,min,sec)
	{
		hour=hour+":";
		if(min<10){min="0"+min;}
		return hour+min;
	}
	if(Shour==Ehour && Smin==Emin && SM==EM)
	{
		if(res!=""){res+=" ";}
		res+=formatShortDateTimeRangeTime(Shour,Smin,Ssec)+" "+SM;
	}
	else
	{
		if(lhs!=""){lhs+=" ";rhs+=" ";}
		lhs+=formatShortDateTimeRangeTime(Shour,Smin,Ssec)+" "+SM;
		rhs+=formatShortDateTimeRangeTime(Ehour,Emin,Esec)+" "+EM;
	}
	if(rhs=="")return res;
	if(res=="")return lhs+" - "+rhs;
	return lhs+" - "+rhs+" ["+res+"]";
}
function ParseDateToReportMDYString(narf)
{
	var mn=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
	var dw=["Sun","Mon","Tue","Wed","Thr","Fri","Sat"];
	function ParseDateToReportMDYStringDotM(day)
	{
		day=day*1+0;
		var filter=day;
		if(day>19)
		{
			filter=filter%20;
		}
		switch(filter)
		{
			case 1:
			return ""+day+"st";
			case 2:
			return ""+day+"nd";
			case 3:
			return ""+day+"rd";
		}
		return ""+day+"th";
	}
	var t="AM";
	var yr=narf.getFullYear();
	var mo=narf.getMonth()+1;
	var dow=parseInt(narf.getDay());
	if(mo<10){mo="0"+mo;}
	var dy=narf.getDate();
	var res=mn[mo-1]+" "+ParseDateToReportMDYStringDotM(dy)+", "+yr+" ("+dw[dow]+")";
	return res;
}
function ParseDateToMDYString(narf)
{
	var t="AM";
	var yr=narf.getFullYear();
	var mo=narf.getMonth()+1;
	if(mo<10){mo="0"+mo;}
	var dy=narf.getDate();
	if(dy<10){dy="0"+dy;}
	//var hr=narf.getHours();
	//if(hr>=12){hr-=12;t="PM";}
	//if(hr==0){hr=12;}
	//if(hr<10){hr="0"+hr;}
	//var mi=narf.getMinutes();
	//if(mi<10){mi="0"+mi;}
	//var sc=narf.getSeconds();
	//if(sc<10){sc="0"+sc;}
	//var res=yr+"-"+mo+"-"+dy+" "+hr+":"+mi+t;
	var res=mo+"/"+dy+"/"+yr;
	return res;
}
function ParseDateToString(narf)
{
	var t="AM";
	var yr=narf.getFullYear();
	var mo=narf.getMonth()+1;
	if(mo<10){mo="0"+mo;}
	var dy=narf.getDate();
	if(dy<10){dy="0"+dy;}
	var hr=narf.getHours();
	if(hr>=12){hr-=12;t="PM";}
	if(hr==0){hr=12;}
	if(hr<10){hr="0"+hr;}
	var mi=narf.getMinutes();
	if(mi<10){mi="0"+mi;}
	var sc=narf.getSeconds();
	if(sc<10){sc="0"+sc;}
	var res=yr+"-"+mo+"-"+dy+" "+hr+":"+mi+t;
	return res;
}
function ParseDateToServerString(narf)
{
	var yr=narf.getFullYear();
	var mo=narf.getMonth()+1;
	if(mo<10){mo="0"+mo;}
	var dy=narf.getDate();
	if(dy<10){dy="0"+dy;}
	var hr=narf.getHours();
	if(hr<10){hr="0"+hr;}
	var mi=narf.getMinutes();
	if(mi<10){mi="0"+mi;}
	var sc=narf.getSeconds();
	if(sc<10){sc="0"+sc;}
	var res=yr+"-"+mo+"-"+dy+" "+hr+":"+mi+":"+sc;
	return res;
}
var PubKey=null;
function CallDumpEncryptionKeys(callback)
{
	if(!callback){callback=null;}
	DumpEncKeysAjax=getAjaxIFace();
	if(DumpEncKeysAjax!=null)
	{
		DumpEncKeysAjax.Callback=callback;
		RunAjax("Command=DumpEncryptionKeys",function()
		{
			if(this.readyState!=4)return;
			var callback=null;
			if(this.Callback)
			{
				callback=this.Callback;
			}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			if(narf[0]=="DumpEncryptionKeysReply")
			{
				if(narf[1]=="Success")
				{
					PubKey=null;
					if(callback){callback(true);}
					return;
				}
			}
			if(callback){callback(false);}
		},DumpEncKeysAjax);
	}
}
function RSAEncryptText(text,resultsFunc)
{
	if(PubKey==null)
	{
		RunAjax("Command=GetPubKey",function(){
			var narf=this.responseText;
			narf=narf.split("\r\n");
			if(narf[0]!="GetPubKeyReply")
			{
				CallDumpEncryptionKeys();
				resultsFunc(null);
				return;
			}
			if(narf[1]!="Available")
			{
				CallDumpEncryptionKeys();
				resultsFunc(null);
				return;
			}
			var temp=decodeURIComponent(narf[2]);
			PubKey=temp.split(",");
			var rsa=new RSAKey();
			rsa.setPublic(PubKey[0],PubKey[1]);
			var data=rsa.encrypt(text);
			if(data==null){CallDumpEncryptionKeys();}
			resultsFunc(data);
		});
	}
	else
	{
		var rsa=new RSAKey();
		rsa.setPublic(PubKey[0],PubKey[1]);
		var data=rsa.encrypt(text);
		if(data==null){CallDumpEncryptionKeys();}
		resultsFunc(data);
	}
}

var WindowsPreserved=new Array();
function PreserveAllWindows()
{
	var Windows=document.getElementsByClassName("Window");
	var c=Windows.length;
	for(var i=0;i<c;i++)
	{
		var Window=Windows[i];
		if(Window)
		{
			WindowsPreserved.push(Window);
			if(Window.parentNode)
			{
				var rr=getElementOffset(Window);
				Window.style.top=rr.top+"px";
				Window.style.left=rr.left+"px";
				Window.parentNode.removeChild(Window);
				if(c!=Windows.length)
				{
					i-=(c-Windows.length);
					c=Windows.length
				}
			}
		}
		else throw new Exception("Error");
	}
}
function RestorePreservedWindows()
{
	while(WindowsPreserved.length>0)
	{
		var Window=WindowsPreserved.shift();
		if(Window)
		{
			document.body.appendChild(Window);
		}
		else throw new Exception("Error");
	}
}
var LastNavigatorObject=null;
var LastNavChain=null;
var LastNav="";
function SetNavigateProp(obj,location,auths)
{
	obj.NavigateName=location;
	obj.NextNavigateObj=LastNavigatorObject;
	if(!auths)auths="";
	obj.AuthLevels=auths;
	if(LogonAuths)
	{
		if(auths!="")
		{
			var rr=auths.split(",");
			var c=rr.length;
			var IsAuth=false;
			for(var i=0;i<c;i++)
			{
				IsAuth|=LogonAuths[rr[i]];
			}
			if(!IsAuth)
			{
				obj.style.display="none";
			}
		}
	}
	obj.NavigateTo=function(loc)
	{
		var t=loc.shift();
		if(this.NavigateName==t)
		{
			if(this.onclick)
			{
				this.NavigateOnClick.call(this,window.event);
			}
			if(loc.length>0)
			{
				LastNavigatorObject.NavigateTo.call(LastNavigatorObject,loc);
				loc.unshift(t);
				return;
			}
		}
		else
		{
			if(this.NextNavigateObj)
			{
				loc.unshift(t);
				this.NextNavigateObj.NavigateTo.call(this.NextNavigateObj,loc);
				return;
			}
		}
		loc.unshift(t);
	};
	obj.HighlightSelected=function(hashloc)
	{
		if(hashloc)
		{
			if(hashloc.indexOf(this.NavigateName)>-1)
			{
				this.setAttribute("Selected","Selected");
			}
			else
			{
				this.removeAttribute("Selected");
			}
		}
		if(this.NextNavigateObj)
		{
			if(this.NextNavigateObj.HighlightSelected)
				this.NextNavigateObj.HighlightSelected.call(this.NextNavigateObj,hashloc);
		}
	};
	if(obj.onclick)
	{
		obj.className="NavButton";
		obj.NavigateOnClick=obj.onclick;
		obj.onclick=function(e)
		{
			PreserveAllWindows();
			this.NavigateOnClick.call(this,e);
			var gg=LastNavChain.join("&");
			gg=gg.split("&");
			gg.shift();
			var t="";
			if(gg.length>0)
			{
				t=gg.pop();
			}
			if(t!=this.NavigateName){gg.push(t);}
			gg=gg.join("&");
			if(gg!=""){gg+="&";}
			var loc="#"+gg+this.NavigateName;
			if(LastNav!=loc)
			{
				LastNav=loc;
				window.onhashchange=nullHashChange;
				window.location.hash=loc;
			}
			var hashloc=window.location.hash;
			hashloc=hashloc.split("#");
			hashloc.shift();
			hashloc=hashloc.join("");
			hashloc=hashloc.split("&");
			LastNavigatorObject.HighlightSelected.call(LastNavigatorObject,hashloc);
			RestorePreservedWindows();
		}
	}
	else
	{
		obj.NavigateOnClick=null;
		if(LastNavChain==null)
		{
			LastNavChain=new Array();
		}
		LastNavChain.push(location);
		obj.NavigateName=obj.NavigateName+"Nav";
	}
	LastNavigatorObject=obj;
	var hashloc=window.location.hash;
	hashloc=hashloc.split("#");
	hashloc.shift();
	hashloc=hashloc.join("");
	hashloc=hashloc.split("&");
	LastNavigatorObject.HighlightSelected.call(LastNavigatorObject,hashloc);
}
var anRAjaxObj=getAjaxIFace();
function RefreshDJNowPlaying()
{
	RunAjax(CommonWebJockeyAIURL+"&Command=DJ:NowPlaying",function(){
		var narf=this.responseText;
		if(narf!="")
		{
			narf=narf.split("\r\n");
			narf0=narf.shift();
			if(narf0=="DJ:NowPlayingReply")
			{
				var ID=narf.shift();
				var Title=decodeURIComponent(narf.shift());
				Title=Title.split(" ");
				Title=Title.join("\xA0");
				var Time=parseInt(narf.shift());
				var l=narf.shift();
				var RemainingText="_:__";
				if(l>0)
				{
					var Remaining=l-Time;
					RemainingText=formatTimeDisp(Remaining);
				}
				var TimeText=formatTimeDisp(Time);
				if(WJLastID!=ID || WJLastTime>Time)
				{
					WJLastID=ID;
					WJLastTime=Time;
					ClearNodeChildren(NowPlayingTitleSpan);
					ClearNodeChildren(NowPlayingIDSpan);
					NowPlayingTitleSpan.appendChild(document.createTextNode(Title));
					NowPlayingIDSpan.appendChild(document.createTextNode(ID));
					if(SongChangeCallback){SongChangeCallback();}
				}
				ClearNodeChildren(NowPlayingTimeSpan);
				ClearNodeChildren(NowPlayingRemainingSpan);
				NowPlayingTimeSpan.appendChild(document.createTextNode(TimeText));
				NowPlayingRemainingSpan.appendChild(document.createTextNode(RemainingText));
			}
			else
			{
				ClearNodeChildren(NowPlayingTimeSpan);
				ClearNodeChildren(NowPlayingRemainingSpan);
				ClearNodeChildren(NowPlayingTitleSpan);
				ClearNodeChildren(NowPlayingIDSpan);
				NowPlayingTimeSpan.appendChild(document.createTextNode("_:__"));
				NowPlayingRemainingSpan.appendChild(document.createTextNode("_:__"));
				NowPlayingTitleSpan.appendChild(document.createTextNode("Error"));
				NowPlayingIDSpan.appendChild(document.createTextNode("-"));
				if(WJLastID!="" && WJLastTime!=-1)
				{
					WJLastID="";
					WJLastTime=-2;
					if(SongChangeCallback){SongChangeCallback();}
				}
			}
		}
		else
		{
			ClearNodeChildren(NowPlayingTimeSpan);
			ClearNodeChildren(NowPlayingRemainingSpan);
			ClearNodeChildren(NowPlayingTitleSpan);
			ClearNodeChildren(NowPlayingIDSpan);
			NowPlayingTimeSpan.appendChild(document.createTextNode("_:__"));
			NowPlayingRemainingSpan.appendChild(document.createTextNode("_:__"));
			NowPlayingTitleSpan.appendChild(document.createTextNode("Error"));
			NowPlayingIDSpan.appendChild(document.createTextNode("-"));
			if(WJLastID!="" && WJLastTime!=-1)
			{
				WJLastID="";
				WJLastTime=-2;
				if(SongChangeCallback){SongChangeCallback();}
			}
		}
		if(DJNowPlayingRefreshTimeoutID)
		{
			clearTimeout(DJNowPlayingRefreshTimeoutID);
		}
		DJNowPlayingRefreshTimeoutID=setTimeout(RefreshDJNowPlaying,990);
	},anRAjaxObj);
}
function CreateNavigator()
{
	TimerClearAll();
	TouchServer();
	LastNavigatorObject=null;
	LastNavChain=null;
	Cal=null;
	winCal=null;
	SongChangeCallback=null;
	var obj=document.createElement("span");
	obj.id="NavigatorSpan";
	var NavMainButton=document.createElement("input");
	NavMainButton.id="NavMainButton";
	NavMainButton.type="button";
	NavMainButton.value="Main";
	NavMainButton.onclick=function(){DisplayMainPanel();}
	SetNavigateProp(NavMainButton,"Main");
	obj.appendChild(NavMainButton);
	var NavRequestsButton=document.createElement("input");
	NavRequestsButton.id="NavRequestsButton";
	NavRequestsButton.type="button";
	NavRequestsButton.value="Requests";
	NavRequestsButton.onclick=function(){DisplayRequestsPanel();}
	SetNavigateProp(NavRequestsButton,"Requests");
	obj.appendChild(NavRequestsButton);
	var NavStopSetsProgramButton=document.createElement("input");
	NavStopSetsProgramButton.id="NavStopSetsProgramButton";
	NavStopSetsProgramButton.type="button";
	NavStopSetsProgramButton.value="Stop Sets Program";
	NavStopSetsProgramButton.onclick=function(){DisplayStopSetsProgramPanel();}
	SetNavigateProp(NavStopSetsProgramButton,"StopSetsProgram");
	obj.appendChild(NavStopSetsProgramButton);
	var NavStopSetsButton=document.createElement("input");
	NavStopSetsButton.id="NavStopSetsButton";
	NavStopSetsButton.type="button";
	NavStopSetsButton.value="Stop Sets";
	NavStopSetsButton.onclick=function(){DisplayStopSetsPanel();}
	SetNavigateProp(NavStopSetsButton,"StopSets");
	obj.appendChild(NavStopSetsButton);
	var NavBrowseButton=document.createElement("input");
	NavBrowseButton.id="NavBrowseButton";
	NavBrowseButton.type="button";
	NavBrowseButton.value="Browse";
	NavBrowseButton.onclick=function(){DisplayBrowsePanel();}
	SetNavigateProp(NavBrowseButton,"Browse");
	obj.appendChild(NavBrowseButton);
	var NavSearchButton=document.createElement("input");
	NavSearchButton.id="NavSearchButton";
	NavSearchButton.type="button";
	NavSearchButton.value="Search";
	NavSearchButton.onclick=function(){DisplaySearchPanel();}
	SetNavigateProp(NavSearchButton,"Search");
	obj.appendChild(NavSearchButton);
	var NavConfigButton=document.createElement("input");
	NavConfigButton.id="NavConfigButton"
	NavConfigButton.type="button";
	NavConfigButton.value="Configuration";
	NavConfigButton.onclick=function(){DisplayConfigPanel();};
	SetNavigateProp(NavConfigButton,"Config","CanConfig");
	obj.appendChild(NavConfigButton);
	var NavAdminButton=document.createElement("input");
	NavAdminButton.id="NavAdminButton";
	NavAdminButton.type="button";
	NavAdminButton.value="Administration";
	NavAdminButton.onclick=function(){DisplayAdminPanel();};
	SetNavigateProp(NavAdminButton,"Admin");
	obj.appendChild(NavAdminButton);
	var NavLogoutButton=document.createElement("input");
	NavLogoutButton.id="NavLogoutButton";
	NavLogoutButton.type="button";
	NavLogoutButton.value="Logout";
	NavLogoutButton.className="NavButton";
	NavLogoutButton.onclick=function()
	{
		TimerClearAll();
		ClearNodeChildren(document.body);
		document.body.appendChild(CreateNavigator());
		ClearNodeChildren(document.body);
		document.body.appendChild(document.createTextNode("Logging out, please wait..."));
		RunAjax("Command=DJ:Logout",function()
		{
			PubKey=null;
			ClearNodeChildren(document.body);
			document.body.appendChild(document.createTextNode("Please wait..."));
			if(DJNowPlayingRefreshTimeoutID)
			{
				clearTimeout(DJNowPlayingRefreshTimeoutID);
				DJNowPlayingRefreshTimeoutID=null;
			}
			CheckStatus();
		});
	}
	obj.appendChild(NavLogoutButton);
	obj.appendChild(document.createTextNode("\xA0"));
	var div=document.createElement("div");
	div.style.display="inline-block";
	div.style.padding="0px";
	div.style.margin="0px";
	obj.appendChild(div);
	NowPlayingTimeSpan=document.createElement("span");
	NowPlayingTimeSpan.appendChild(document.createTextNode("_:__"));
	div.appendChild(NowPlayingTimeSpan);
	div.appendChild(document.createTextNode("\xA0"));
	var NowPlayingRemainingSpanP=document.createElement("span");
	NowPlayingRemainingSpanP.appendChild(document.createTextNode("("));
	div.appendChild(NowPlayingRemainingSpanP);
	NowPlayingRemainingSpan=document.createElement("span");
	NowPlayingRemainingSpan.appendChild(document.createTextNode("_:__"));
	NowPlayingRemainingSpanP.appendChild(NowPlayingRemainingSpan);
	NowPlayingRemainingSpanP.appendChild(document.createTextNode(")"));
	DJFileInfoButton=document.createElement("input");
	DJFileInfoButton.className="NavButton";
	DJFileInfoButton.type="button";
	DJFileInfoButton.value="Information";
	DJFileInfoButton.onclick=function()
	{
		OverlayFileInfo(WJLastID);
		return false;
	};
	div.appendChild(DJFileInfoButton);
	div.appendChild(document.createTextNode("\xA0"));
	NowPlayingTitleSpan=document.createElement("span");
	NowPlayingTitleSpan.appendChild(document.createTextNode("Title"));
	div.appendChild(NowPlayingTitleSpan);
	div.appendChild(document.createTextNode("\xA0"));
	var NowPlayingIDSpanB=document.createElement("span");
	NowPlayingIDSpanB.appendChild(document.createTextNode("["));
	div.appendChild(NowPlayingIDSpanB);
	NowPlayingIDSpan=document.createElement("span");
	NowPlayingIDSpan.appendChild(document.createTextNode("-"));
	NowPlayingIDSpanB.appendChild(NowPlayingIDSpan);
	NowPlayingIDSpanB.appendChild(document.createTextNode("]"));
	obj.appendChild(document.createElement("br"));
	RefreshDJNowPlaying();
	WJLastID="";
	WJLastTime=-2;
	SetNavigateProp(obj,"Main");
	return obj;
}

function CreateConfigPanelNavigator()
{
	var obj=document.createElement("span");
	obj.id="ConfigNavigatorSpan";
	var NavSettingsButton=document.createElement("input");
	NavSettingsButton.id="NavSettingsButton";
	NavSettingsButton.type="button";
	NavSettingsButton.value="Settings";
	NavSettingsButton.onclick=function(){DisplaySettingsPanel();};
	SetNavigateProp(NavSettingsButton,"Settings","CanConfig");
	obj.appendChild(NavSettingsButton);
	var NavPasswordButton=document.createElement("input");
	NavPasswordButton.id="NavPasswordButton";
	NavPasswordButton.type="button";
	NavPasswordButton.value="Password";
	NavPasswordButton.onclick=function(){DisplayPasswordPanel();};
	SetNavigateProp(NavPasswordButton,"Password","CanConfig");
	obj.appendChild(NavPasswordButton);
	obj.appendChild(document.createElement("br"));
	SetNavigateProp(obj,"Config");
	return obj;
}

function CreateAdminPanelNavigator()
{
	var obj=document.createElement("span");
	obj.id="AdminNavigatorSpan";
	var NavAdminServerButton=document.createElement("input");
	NavAdminServerButton.id="NavAdminServerButton"
	NavAdminServerButton.type="button";
	NavAdminServerButton.value="Server";
	NavAdminServerButton.onclick=function(){DisplayServerPanel();};
	SetNavigateProp(NavAdminServerButton,"Server");
	obj.appendChild(NavAdminServerButton);
	var NavAdminSetupButton=document.createElement("input");
	NavAdminSetupButton.id="NavAdminSetupButton";
	NavAdminSetupButton.type="button";
	NavAdminSetupButton.value="Setup";
	NavAdminSetupButton.onclick=function(){DisplaySetupPanel();};
	SetNavigateProp(NavAdminSetupButton,"Setup","IsAdmin,CanConfig");
	obj.appendChild(NavAdminSetupButton);
	obj.appendChild(document.createElement("br"));
	SetNavigateProp(obj,"Admin");
	return obj;
}

function DisplayPasswordPanel()
{
	ClearNodeChildren(document.body);
	document.body.appendChild(CreateNavigator());
	document.body.appendChild(CreateConfigPanelNavigator());
	document.body.appendChild(document.createElement("br"));
	var ChangePasswordForm=document.createElement("form");
	ChangePasswordForm.id="ChangePasswordForm";
	ChangePasswordForm.target="_blank";
	ChangePasswordForm.action="";
	ChangePasswordForm.method="POST";
	ChangePasswordForm.onsubmit=function(){return false;};
	document.body.appendChild(ChangePasswordForm);
	var OldPasswordLabel=document.createElement("label");
	MakeRequired(OldPasswordLabel);
	ChangePasswordForm.appendChild(OldPasswordLabel);
	OldPasswordLabel.appendChild(document.createTextNode("Enter old password."));
	OldPasswordLabel.appendChild(document.createElement("br"));
	var OldPasswordInput=document.createElement("input");
	OldPasswordInput.id="OldPasswordInput";
	OldPasswordInput.name="OldPasswordInput";
	OldPasswordInput.type="password";
	OldPasswordLabel.appendChild(OldPasswordInput);
	ChangePasswordForm.appendChild(document.createElement("br"));
	var NewPasswordLabel=document.createElement("label");
	MakeRequired(NewPasswordLabel);
	ChangePasswordForm.appendChild(NewPasswordLabel);
	NewPasswordLabel.appendChild(document.createTextNode("Enter new password."));
	NewPasswordLabel.appendChild(document.createElement("br"));
	var NewPasswordInput=document.createElement("input");
	NewPasswordInput.id="NewPasswordInput";
	NewPasswordInput.name="NewPasswordInput";
	NewPasswordInput.type="password";
	NewPasswordLabel.appendChild(NewPasswordInput);
	ChangePasswordForm.appendChild(document.createElement("br"));
	var div=document.createElement("div");
	div.style.textAlign="right";
	ChangePasswordForm.appendChild(div);
	var SubmitButton=document.createElement("input");
	SubmitButton.id="ChangePasswordSubmitButton";
	SubmitButton.name="ChangePasswordSubmitButton";
	SubmitButton.value="Change";
	SubmitButton.type="submit";
	div.appendChild(SubmitButton);
	function ChangePasswordGo()
	{
		var OldPassword=OldPasswordInput.value;
		var NewPassword=NewPasswordInput.value;
		var Errors="";
		if(OldPassword=="")
		{
			Errors+="  The old password field cannot be blank.";
		}
		if(NewPassword=="")
		{
			Errors+="  The new password field cannot be blank.";
		}
		if(Errors!="")
		{
			OverlayMessage("The following errors are present in the submission:"+Errors);
			return;
		}
		var token=encodeURIComponent(OldPassword)+"="+encodeURIComponent(NewPassword);
		var WaitObj=OverlayWait();
		RSAEncryptText(token,function(encrypted){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			if(encrypted==null)
			{
				OverlayMessage("Unable to encrypt account credentials before sending to server.  Please try again.",function(){
					CallDumpEncryptionKeys();
				});
				return;
			}
			var q="Command=DJ:ChangePass&token="+encodeURIComponent(encrypted);
			var WaitObj=OverlayWait();
			RunAjax(q,function(){
				try{WaitObj.Close();}catch(err){OverlayWaitClose();}
				var narf=this.responseText;
				narf=narf.split("\r\n\r\n");
				var narf0=narf.shift();
				if(narf0=="UnAuth")
				{
					OverlayMessage("You are not authorized to perform that action.");
					return;
				}
				if(narf0=="Invalid")
				{
					OverlayMessage("The server reported that an invalid command was sent.");
					return;
				}
				if(narf0=="RSAError")
				{
					OverlayMessage("The server reported that it could not process the encrypted token.  Please try again.",function(){
						CallDumpEncryptionKeys();
					});
					return;
				}
				if(narf0=="OldNonmatch")
				{
					OverlayMessage("The old password did not match.");
					return;
				}
				if(narf0=="Error")
				{
					OverlayMessage("The server reported that an error occurred in the operation.");
					return;
				}
				if(narf0!="Success")
				{
					var error="";
					if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
					var c=narf.length;
					for(var i=0;i<c-1;i++)
					{
						if(narf[i]=="")continue;
						error+=" {"+decodeURIComponent(narf[i])+"}";
					}
					OverlayMessage("The server responded with an unknown error reply."+error);
					return;
				}
				OverlayMessage("Password changed successfully.");
			});
		});
	}
	ChangePasswordForm.onsubmit=function()
	{
		ChangePasswordGo();
		return false;
	};
}

function DisplaySettingsPanel()
{
	ClearNodeChildren(document.body);
	document.body.appendChild(CreateNavigator());
	document.body.appendChild(CreateConfigPanelNavigator());
	document.body.appendChild(document.createElement("br"));
	var WebJockeySettingsForm=document.createElement("form");
	WebJockeySettingsForm.id="WebJockeySettingsForm";
	WebJockeySettingsForm.target="_blank";
	WebJockeySettingsForm.action="";
	WebJockeySettingsForm.method="POST";
	WebJockeySettingsForm.onsubmit=function(){return false;};
	document.body.appendChild(WebJockeySettingsForm);
	var TotalMaxRequestsLabel=document.createElement("label");
	MakeRequired(TotalMaxRequestsLabel);
	TotalMaxRequestsLabel.appendChild(document.createTextNode("Total maximum requests:"));
	TotalMaxRequestsLabel.appendChild(document.createElement("br"));
	WebJockeySettingsForm.appendChild(TotalMaxRequestsLabel);
	var TotalMaxRequestsInput=document.createElement("input");
	TotalMaxRequestsInput.id="TotalMaxRequestsInput";
	TotalMaxRequestsInput.name="TotalMaxRequestsInput";
	TotalMaxRequestsInput.type="number";
	TotalMaxRequestsInput.min=0;
	TotalMaxRequestsLabel.appendChild(TotalMaxRequestsInput);
	WebJockeySettingsForm.appendChild(document.createElement("br"));
	var IPMaxRequestsLabel=document.createElement("label");
	MakeRequired(IPMaxRequestsLabel);
	IPMaxRequestsLabel.appendChild(document.createTextNode("Maximum requests per IP:"));
	IPMaxRequestsLabel.appendChild(document.createElement("br"));
	WebJockeySettingsForm.appendChild(IPMaxRequestsLabel);
	var IPMaxRequestsInput=document.createElement("input");
	IPMaxRequestsInput.id="IPMaxRequestsInput";
	IPMaxRequestsInput.name="IPMaxRequestsInput";
	IPMaxRequestsInput.type="number";
	IPMaxRequestsInput.min=0;
	IPMaxRequestsLabel.appendChild(IPMaxRequestsInput);
	WebJockeySettingsForm.appendChild(document.createElement("br"));
	var SkipVoteCountLabel=document.createElement("label");
	MakeRequired(SkipVoteCountLabel);
	SkipVoteCountLabel.appendChild(document.createTextNode("Number of votes to skip (zero to disable):"));
	SkipVoteCountLabel.appendChild(document.createElement("br"));
	WebJockeySettingsForm.appendChild(SkipVoteCountLabel);
	var SkipVoteCountInput=document.createElement("input");
	SkipVoteCountInput.id="SkipVoteCountInput";
	SkipVoteCountInput.name="SkipVoteCountInput";
	SkipVoteCountInput.type="number";
	SkipVoteCountInput.min=0;
	SkipVoteCountLabel.appendChild(SkipVoteCountInput);
	WebJockeySettingsForm.appendChild(document.createElement("br"));
	var TimeLimitLabel=document.createElement("label");
	MakeRequired(TimeLimitLabel);
	TimeLimitLabel.appendChild(document.createTextNode("Requests Time Limit (in seconds):"));
	TimeLimitLabel.appendChild(document.createElement("br"));
	WebJockeySettingsForm.appendChild(TimeLimitLabel);
	var TimeLimitInput=document.createElement("input");
	TimeLimitInput.id="TimeLimitInput";
	TimeLimitInput.name="TimeLimitInput";
	TimeLimitInput.type="number";
	TimeLimitInput.min=0;
	TimeLimitLabel.appendChild(TimeLimitInput);
	WebJockeySettingsForm.appendChild(document.createElement("br"));
	var div=document.createElement("div");
	div.style.textAlign="right";
	WebJockeySettingsForm.appendChild(div);
	var SubmitButton=document.createElement("input");
	SubmitButton.id="SubmitButton";
	SubmitButton.name="SubmitButton";
	SubmitButton.value="Apply";
	SubmitButton.type="submit";
	div.appendChild(SubmitButton);
	TotalMaxRequestsInput.focus();
	function DisplaySettingsPanelRetrieve()
	{
		var q=CommonWebJockeyAIURL+"&Command=Settings";
		var WaitObj=OverlayWait();
		RunAjax(q,function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0=="Error")
			{
				OverlayMessage("WebJockey responded that an error occurred while processing the request.");
				return;
			}
			if(narf0!="SettingsReply")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			var tt=hash_map(narf);
			var TotalMaxRequests=parseInt(tt['TotalMaxRequests']);
			var IPMaxRequests=parseInt(tt['IPMaxRequests']);
			var SkipVoteCount=parseInt(tt['SkipVoteCount']);
			var TimeLimit=parseInt(tt['TimeLimit']);
			TotalMaxRequestsInput.value=TotalMaxRequests;
			IPMaxRequestsInput.value=IPMaxRequests;
			SkipVoteCountInput.value=SkipVoteCount;
			TimeLimitInput.value=TimeLimit;
		});
	}
	DisplaySettingsPanelRetrieve();
	function WebJockeySettingsFormGo()
	{
		Errors="";
		var TotalMaxRequests=TotalMaxRequestsInput.value;
		var IPMaxRequests=IPMaxRequestsInput.value;
		var SkipVoteCount=SkipVoteCountInput.value;
		var TimeLimit=TimeLimitInput.value;
		if(TotalMaxRequests=="" || isNaN(parseInt(TotalMaxRequests)))
		{
			Errors+="  The total max requests field contains an invalid entry.";
		}
		if(IPMaxRequests=="" || isNaN(parseInt(IPMaxRequests)))
		{
			Errors+="  The max requests per IP field contains an invalid entry.";
		}
		if(SkipVoteCount=="" || isNaN(parseInt(SkipVoteCount)))
		{
			Errors+="  The skip vote count field contains an invalid entry.";
		}
		if(TimeLimit=="" || isNaN(parseInt(TimeLimit)))
		{
			Errors+="  The requests time limit field contains an invalid entry.";
		}
		if(Errors!="")
		{
			OverlayMessage("The submission contains the following error(s)"+Error);
			return;
		}
		TotalMaxRequests=parseInt(TotalMaxRequests);
		IPMaxRequests=parseInt(IPMaxRequests);
		SkipVoteCount=parseInt(SkipVoteCount);
		TimeLimit=parseInt(TimeLimit);
		var q="Command=DJ:SetSettings&"+CommonWebJockeyAIURL;
		q+="&Param1=TotalMaxRequests&Param2="+TotalMaxRequests;
		q+="&Param3=IPMaxRequests&Param4="+IPMaxRequests;
		q+="&Param5=SkipVoteCount&Param6="+SkipVoteCount;
		q+="&Param7=TimeLimit&Param8="+TimeLimit;
		var WaitObj=OverlayWait();
		RunAjax(q,function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0=="Error")
			{
				OverlayMessage("WebJockey responded that an error occurred while processing the request.");
				return;
			}
			if(narf0!="DJ:SetSettingsDone")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			OverlayMessage("Settings set.",function(){
				DisplaySettingsPanelRetrieve();
			});
		});
	};
	WebJockeySettingsForm.onsubmit=function()
	{
		WebJockeySettingsFormGo();
		return false;
	};
}

function DisplayConfigPanel()
{
	ClearNodeChildren(document.body);
	document.body.appendChild(CreateNavigator());
	document.body.appendChild(CreateConfigPanelNavigator());
}

function DisplaySetupPanel()
{
	ClearNodeChildren(document.body);
	document.body.appendChild(CreateNavigator());
	document.body.appendChild(CreateAdminPanelNavigator());
	document.body.appendChild(document.createElement("br"));
	function CreateSetupForm(Name,type,Desc)
	{
		var utype=type;
		if(utype=="button"){type="input";}
		if(utype=="submit"){type="input";}
		if(utype=="reset"){type="input";}
		if(utype=="text"){type="input";}
		if(utype=="password"){type="input";}
		if(utype=="radio"){type="input";}
		if(utype=="checkbox"){type="input";}
		if(utype=="color"){type="input";}
		if(utype=="date"){type="input";}
		if(utype=="datetime-local"){type="input";}
		if(utype=="email"){type="input";}
		if(utype=="month"){type="input";}
		if(utype=="number"){type="input";}
		if(utype=="range"){type="input";}
		if(utype=="search"){type="input";}
		if(utype=="tel"){type="input";}
		if(utype=="time"){type="input";}
		if(utype=="url"){type="input";}
		if(utype=="week"){type="input";}
		if(utype=="file"){type="input";}
		if(utype=="select"){type="select";}
		t=utype.charAt(0).toUpperCase()+utype.slice(1);
		var form=document.createElement("form");
		form.id=Name+"Form";
		form.target="_blank";
		form.action="";
		form.method="POST";
		form.onsubmit=function(){return false;};
		var label=document.createElement("label");
		label.id=Name+"Label";
		label.appendChild(document.createTextNode(Desc));
		label.appendChild(document.createElement("br"));
		form.appendChild(label);
		narf=document.createElement(type);
		narf.id=Name+t;
		if(utype!=type){narf.type=utype;}
		label.appendChild(narf);
		var submit=document.createElement("input");
		submit.id=Name+"Submit";
		submit.type="submit";
		submit.value="Set";
		form.appendChild(submit);
		return {
			Form: form,
			Label: label,
			Input: narf,
			Submit: submit
		};
	}
	var obj;
	obj=CreateSetupForm("Timezone","select","Local Timezone:");
	MakeRequired(obj.Label);
	var TimezoneInput=obj.Input;
	var TimezoneForm=obj.Form;
	document.body.appendChild(TimezoneForm);
	var BlankTimezoneOption=document.createElement("option");
	BlankTimezoneOption.value="";
	BlankTimezoneOption.appendChild(document.createTextNode(""));
	TimezoneInput.appendChild(BlankTimezoneOption);
	TimezoneForm.onsubmit=function()
	{
		var Timezone=TimezoneInput.value;
		if(Timezone=="")
		{
			OverlayMessage("You must select a valid timezone.");
			return false;
		}
		var q="Command=SetTimezone&Timezone="+encodeURIComponent(Timezone);
		var WaitObj=OverlayWait();
		RunAjax(q,function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0!="SetTimezoneReply")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			var narf1=narf.shift();
			if(narf1=="UnAuth")
			{
				OverlayMessage("You are not authorized to perform that action.");
				return;
			}
			if(narf1=="Invalid")
			{
				OverlayMessage("The server reported that an invalid command was sent.");
				return;
			}
			if(narf1=="InputInvalid")
			{
				OverlayMessage("Unable to reconcile selected/entered timezone.");
				return;
			}
			if(narf1=="QueryError")
			{
				OverlayMessage("The server reported that a query error occurred.");
				return;
			}
			if(narf1!="Success")
			{
				var error="";
				if(narf1!="")error=" {"+decodeURIComponent(narf1)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			OverlayMessage("Timezone configuration set.",function(){location.reload();});
		});
		return false;
	};
	document.body.appendChild(document.createElement("br"));
	obj=CreateSetupForm("WebJockeyIP","text","WebJockey IP:");
	MakeRequired(obj.Label);
	var WebJockeyIPInput=obj.Input;
	var WebJockeyIPForm=obj.Form;
	document.body.appendChild(WebJockeyIPForm);
	WebJockeyIPForm.onsubmit=function()
	{
		WebJockeyIP=WebJockeyIPInput.value;
		cookieCreate("IP",WebJockeyIP,365);
		CommonWebJockeyAIURL="IP="+WebJockeyIP+"&Port="+WebJockeyPort;
		OverlayMessage("IP Address set.");
		return false;
	};
	WebJockeyIPInput.value=WebJockeyIP;
	document.body.appendChild(document.createElement("br"));
	obj=CreateSetupForm("WebJockeyPort","number","WebJockey Port:");
	MakeRequired(obj.Label);
	var WebJockeyPortInput=obj.Input;
	var WebJockeyPortForm=obj.Form;
	WebJockeyPortInput.min=1;
	WebJockeyPortInput.max=65535;
	document.body.appendChild(WebJockeyPortForm);
	WebJockeyPortForm.onsubmit=function()
	{
		WebJockeyPort=WebJockeyPortInput.value;
		cookieCreate("Port",WebJockeyPort,365);
		CommonWebJockeyAIURL="IP="+WebJockeyIP+"&Port="+WebJockeyPort;
		OverlayMessage("Port set.");
		return false;
	};
	WebJockeyPortInput.value=WebJockeyPort;

	var CurrentTimezone="";
	var WaitObj=OverlayWait();
	MultiRunAjax(new Array({query: "Command=GetTimezone",func: function(){
		var narf=this.responseText;
		narf=narf.split("\r\n");
		var narf0=narf.shift();
		if(narf0=="GetTimezoneReply")
		{
			var narf1=narf.shift();
			if(narf1=="Success")
			{
				CurrentTimezone=decodeURIComponent(narf.shift());
			}
		}
	}},{query: "Command=GetAllTimezones", func: function(){
		var narf=this.responseText;
		narf=narf.split("\r\n");
		var narf0=narf.shift();
		if(narf0=="GetAllTimezonesReply")
		{
			var narf1=narf.shift();
			if(narf1=="Success")
			{
				var c=narf.shift()*1+0;
				for(var i=0;i<c;i++)
				{
					var tt=narf.shift();
					var opt=document.createElement("option");
					opt.value=decodeURIComponent(tt);
					opt.appendChild(document.createTextNode(opt.value));
					TimezoneInput.appendChild(opt);
				}
			}
		}
	}}),function(){
		try{WaitObj.Close();}catch(err){OverlayWaitClose();}
		TimezoneInput.value=CurrentTimezone;
	});
}

function DisplayAdminPanel()
{
	ClearNodeChildren(document.body);
	document.body.appendChild(CreateNavigator());
	document.body.appendChild(CreateAdminPanelNavigator());
}

function DisplayDebugPanel()
{
	ClearNodeChildren(document.body);
	document.body.appendChild(CreateNavigator());
	document.body.appendChild(CreateAdminPanelNavigator());
	document.body.appendChild(CreateServerPanelNavigator());
	document.body.appendChild(document.createElement("hr"));
	var EvalJTextButton=document.createElement("button");
	EvalJTextButton.appendChild(document.createTextNode("Eval(JavaScript)"));
	document.body.appendChild(EvalJTextButton);
	EvalJTextButton.onclick=function(){DisplayJavaScriptDebugWindow();};
	var ManualCSSButton=document.createElement("button");
	ManualCSSButton.appendChild(document.createTextNode("Manual CSS"));
	document.body.appendChild(ManualCSSButton);
	ManualCSSButton.onclick=function(){DisplayManualCSSWindow();};
}

function DisplayManualCommandPanel()
{
	ClearNodeChildren(document.body);
	document.body.appendChild(CreateNavigator());
	document.body.appendChild(CreateAdminPanelNavigator());
	document.body.appendChild(CreateServerPanelNavigator());
	document.body.appendChild(document.createElement("br"));
	var ManualForm=document.createElement("form");
	ManualForm.id="ManualForm";
	ManualForm.target="_blank";
	ManualForm.action="";
	ManualForm.method="POST";
	document.body.appendChild(ManualForm);
	var LayoutTable=document.createElement("table");
	LayoutTable.id="LayoutTable";
	var LayoutTableTR=document.createElement("tr");
	LayoutTableTR.id="LayoutTableTR";
	LayoutTable.appendChild(LayoutTableTR);
	var LayoutTableInputTD=document.createElement("td");
	LayoutTableInputTD.id="LayoutTableInputTD";
	LayoutTableTR.appendChild(LayoutTableInputTD);
	var LayoutTableResultTD=document.createElement("td");
	LayoutTableResultTD.id="LayoutTableResultTD";
	LayoutTableTR.appendChild(LayoutTableResultTD);
	ManualForm.appendChild(LayoutTable);
	var CommandLabel=document.createElement("label");
	MakeRequired(CommandLabel);
	CommandLabel.id="CommandLabel";
	LayoutTableInputTD.appendChild(CommandLabel);
	LayoutTableInputTD.appendChild(document.createElement("br"));
	LayoutTableInputTD.appendChild(document.createElement("br"));
	var CommandInput=document.createElement("input");
	CommandInput.id="CommandInput";
	CommandInput.type="text";
	CommandLabel.appendChild(CommandInput);
	CommandLabel.appendChild(document.createTextNode(" Command to send."));
	var ParametersLabel=document.createElement("label");
	ParametersLabel.id="ParametersLabel";
	LayoutTableInputTD.appendChild(ParametersLabel);
	ParametersLabel.appendChild(document.createTextNode("Parameters in the form of Name=Value pairs on each line.  Do not include the command."));
	ParametersLabel.appendChild(document.createElement("br"));
	var ParametersTextArea=document.createElement("textarea");
	ParametersTextArea.id="ParametersTextArea";
	ParametersTextArea.autocomplete="off";
	ParametersTextArea.autocorrect="off";
	ParametersTextArea.autocapitalize="off";
	ParametersTextArea.spellcheck=false;
	ParametersTextArea.rows=20;
	ParametersTextArea.cols=50;
	ParametersTextArea.wrap="off";
	ParametersLabel.appendChild(ParametersTextArea);
	LayoutTableInputTD.appendChild(document.createElement("br"));
	var SubmitButton=document.createElement("input");
	SubmitButton.id="SubmitButton";
	SubmitButton.type="submit";
	SubmitButton.value="Send";
	LayoutTableInputTD.appendChild(SubmitButton);
	LayoutTableInputTD.appendChild(document.createTextNode("\u00a0"));
	var EncodeSelectedButton=document.createElement("input");
	EncodeSelectedButton.id="EncodeSelectedButton";
	EncodeSelectedButton.type="button";
	EncodeSelectedButton.value="URI-Encode Selected";
	EncodeSelectedButton.ParametersTextArea=ParametersTextArea;
	LayoutTableInputTD.appendChild(EncodeSelectedButton);
	LayoutTableInputTD.appendChild(document.createTextNode("\u00a0"));
	EncodeSelectedButton.onclick=function()
	{
		var ParametersTextArea=this.ParametersTextArea;
		ParametersTextArea.focus();
		var Sel=getInputSelectionText(ParametersTextArea);
		Sel=encodeURIComponent(Sel);
		replaceSelectedText(ParametersTextArea,Sel);
	};
	var EncryptSelectedButton=document.createElement("input");
	EncryptSelectedButton.id="EncryptSelectedButton";
	EncryptSelectedButton.type="button";
	EncryptSelectedButton.value="Encrypt Selected";
	EncryptSelectedButton.ParametersTextArea=ParametersTextArea;
	LayoutTableInputTD.appendChild(EncryptSelectedButton);
	EncryptSelectedButton.onclick=function()
	{
		var ParametersTextArea=this.ParametersTextArea;
		ParametersTextArea.focus();
		var Sel=getInputSelectionText(ParametersTextArea);
		RSAEncryptText(Sel,function(encrypted){
			if(encrypted!=null)
			{
				replaceSelectedText(ParametersTextArea,encrypted);
			}
			else
			{
				OverlayMessage("Unable to encrypt sensitive information before sending to server. Please try again.",CallDumpEncryptionKeys);
			}
		});
	};
	var ResultLabel=document.createElement("label");
	ResultLabel.id="ResultLabel";
	LayoutTableResultTD.appendChild(ResultLabel);
	ResultLabel.appendChild(document.createTextNode("Result:"));
	ResultLabel.appendChild(document.createElement("br"));
	var ResultTextArea=document.createElement("textarea");
	ResultTextArea.id="ResultTextArea";
	ResultTextArea.autocomplete="off";
	ResultTextArea.autocorrect="off";
	ResultTextArea.autocapitalize="off";
	ResultTextArea.spellcheck=false;
	ResultTextArea.rows=20;
	ResultTextArea.cols=50;
	ResultTextArea.wrap="off";
	ResultLabel.appendChild(ResultTextArea);
	ManualForm.onsubmit=function()
	{
		var Command=encodeURIComponent(CommandInput.value);
		if(Command=="")
		{
			OverlayMessage("The command input cannot be blank!");
			return false;
		}
		var UnparsedParameters=ParametersTextArea.value;
		var params="";
		if(UnparsedParameters!="")
		{
			var temp=UnparsedParameters.split("\r\n");
			temp=temp.join("\n");
			temp=temp.split("\r");
			temp=temp.join("\n");
			temp=temp.split("\n");
			var temp1=new Array();
			while(temp.length>0)
			{
				var p=temp.shift();
				if(p=="")continue;
				p=p.split("=");
				if(p.length<2){OverlayMessage("Malformed parameter, missing value.");return false;}
				if(p[0]=="")continue;
				var Param=p.shift();
				var Value=p.join("=");
				var y=new Array();
				y.push(Param);
				y.push(Value);
				temp1.push(y);
			}
			while(temp1.length>0)
			{
				var y=temp1.shift();
				if(params!=""){params+="&";}
				params+=y[0]+"="+encodeURIComponent(y[1]);
			}
		}
		var q="Command="+Command;
		if(params!="")
		{
			q+="&"+params;
		}
		ResultTextArea.value="Please wait...";
		RunAjax(q,function(){
			var narf=Ajax.responseText;
			narf=narf.split("\r\n");
			narf=narf.join("\n");
			ResultTextArea.value=narf;
			if(narf.indexOf("RSAError"))
			{
				var WaitObj=OverlayWait();
				CallDumpEncryptionKeys(function(){
					try{WaitObj.Close();}catch(err){OverlayWaitClose();}
				});
			}
		});
		return false;
	}
	CommandInput.focus();
}

function CreateServerPanelNavigator()
{
	var obj=document.createElement("span");
	obj.id="ServerNavigatorSpan";
	var NavServerManualCommandButton=document.createElement("input");
	NavServerManualCommandButton.id="NavServerManualCommandButton";
	NavServerManualCommandButton.type="button";
	NavServerManualCommandButton.value="Manual Command";
	NavServerManualCommandButton.onclick=function(){DisplayManualCommandPanel();};
	SetNavigateProp(NavServerManualCommandButton,"Manual");
	obj.appendChild(NavServerManualCommandButton);
	var NavServerDebugButton=document.createElement("input");
	NavServerDebugButton.id="NavServerDebugButton";
	NavServerDebugButton.type="button";
	NavServerDebugButton.value="Debug";
	NavServerDebugButton.onclick=function(){DisplayDebugPanel();};
	SetNavigateProp(NavServerDebugButton,"Debug","IsDebugger");
	obj.appendChild(NavServerDebugButton);
	obj.appendChild(document.createElement("br"));
	SetNavigateProp(obj,"Server");
	return obj;
}

function DisplayServerPanel()
{
	ClearNodeChildren(document.body);
	document.body.appendChild(CreateNavigator());
	document.body.appendChild(CreateAdminPanelNavigator());
	document.body.appendChild(CreateServerPanelNavigator());
}

function DisplayTopmost()
{
	ClearNodeChildren(document.body);
	document.body.appendChild(CreateNavigator());
	var location=window.location.hash;
	location=location.split("#");
	location.shift();
	location=location.join("");
	location=location.split("&");
	if(location!="")
	{
		LastNavigatorObject.NavigateTo(location);
	}
}

function DisplaySearchPanel()
{
	ClearNodeChildren(document.body);
	document.body.appendChild(CreateNavigator());
	document.body.appendChild(document.createElement("br"));
	var DJSearchForm=document.createElement("form");
	var DJSearchForm=document.createElement("form");
	DJSearchForm.id="DJSearchForm";
	DJSearchForm.target="_blank";
	DJSearchForm.action="";
	DJSearchForm.method="POST";
	DJSearchForm.onsubmit=function(){return false;};
	document.body.appendChild(DJSearchForm);
	var label=document.createElement("label");
	label.appendChild(document.createTextNode("Words:"));
	label.appendChild(document.createElement("br"));
	MakeRequired(label);
	DJSearchForm.appendChild(label);
	var SearchEdit=document.createElement("input");
	SearchEdit.type="text";
	SearchEdit.id="SearchEdit";
	SearchEdit.name="SearchEdit";
	label.appendChild(SearchEdit);
	var StartSearchButton=document.createElement("input");
	StartSearchButton.id="StartSearchButton";
	StartSearchButton.name="StartSearchButton";
	StartSearchButton.type="submit";
	StartSearchButton.value="Search";
	DJSearchForm.appendChild(StartSearchButton);
	document.body.appendChild(document.createElement("br"));
	var ListSpan=document.createElement("span");
	ListSpan.id="ListSpan";
	ListSpan.className="ListSpan";
	document.body.appendChild(ListSpan);
	function DisplaySearchPanelExecuteSearch(callback)
	{
		var Callback=callback;
		var Words=SearchEdit.value;
		if(Words=="")
		{
			OverlayMessage("Search words field cannot be blank.");
			return;
		}
		var q="Command=Search&"+WebJockeyParameterize(Words);
		RunAjax(q,function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0!="SearchListing")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			ClearNodeChildren(ListSpan);
			var table=document.createElement("table");
			ListSpan.appendChild(table);
			var tbody=document.createElement("tbody");
			table.appendChild(tbody);
			while(narf[0]!=undefined && narf[0]!="" && narf[0]!="EndSearchListing")
			{
				var ID=narf.shift();
				var Title=decodeURIComponent(narf.shift());
				var Length=parseInt(narf.shift());
				var tr=document.createElement("tr");
				tbody.appendChild(tr);
				var td;
				td=document.createElement("td");
				tr.appendChild(td);
				var InfoButton=document.createElement("button");
				InfoButton.type="button";
				InfoButton.appendChild(document.createTextNode("Info"));
				InfoButton.SongID=ID;
				InfoButton.onclick=function()
				{
					var ID=this.SongID;
					OverlayFileInfo(ID);
				};
				td.appendChild(InfoButton);
				td=document.createElement("td");
				tr.appendChild(td);
				var DJRequestButton=document.createElement("button");
				DJRequestButton.type="text";
				DJRequestButton.appendChild(document.createTextNode("DJ Request"));
				DJRequestButton.SongID=ID;
				DJRequestButton.onclick=function()
				{
					var ID=this.SongID;
					var q="Command=DJ:Request&"+WebJockeyParameterize("IP\r\n"+ID);
					var WaitObj=OverlayWait();
					RunAjax(q,function(){
						try{WaitObj.Close();}catch(err){OverlayWaitClose();};
						var narf=this.responseText;
						narf=narf.split("\r\n");
						var narf0=narf.shift();
						if(narf0!="DJ:RequestReply")
						{
							var error="";
							if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
							var c=narf.length;
							for(var i=0;i<c-1;i++)
							{
								if(narf[i]=="")continue;
								error+=" {"+decodeURIComponent(narf[i])+"}";
							}
							OverlayMessage("The server responded with an unknown error reply."+error);
							return;
						}
						var narf1=narf.shift();
						if(narf1=="RequestUnAuth")
						{
							OverlayMessage("The requested entry is outside the allowed path.");
							return;
						}
						if(narf1=="AlreadyNowPlaying")
						{
							OverlayMessage("The requested entry is already playing or is already next to be played.");
							return;
						}
						if(narf1=="NotFound")
						{
							OverlayMessage("The requested entry was not found.");
							return;
						}
						if(narf1!="RequestDone")
						{
							var error="";
							if(narf1!="")error=" {"+decodeURIComponent(narf1)+"}";
							var c=narf.length;
							for(var i=0;i<c-1;i++)
							{
								if(narf[i]=="")continue;
								error+=" {"+decodeURIComponent(narf[i])+"}";
							}
							OverlayMessage("The server responded with an unknown error reply."+error);
							return;
						}
						OverlayMessage("The requested entry has been queued.",function(){WJLastID="";});
					});
				};
				td.appendChild(DJRequestButton);
				td=document.createElement("td");
				tr.appendChild(td);
				var RequestButton=document.createElement("button");
				RequestButton.type="button";
				RequestButton.appendChild(document.createTextNode("Request"));
				RequestButton.SongID=ID;
				RequestButton.onclick=function()
				{
					var ID=this.SongID;
					var q="Command=Request&"+WebJockeyParameterize("IP\r\n"+ID);
					var WaitObj=OverlayWait();
					RunAjax(q,function(){
						try{WaitObj.Close();}catch(err){OverlayWaitClose();};
						var narf=this.responseText;
						narf=narf.split("\r\n");
						var narf0=narf.shift();
						if(narf0!="RequestReply")
						{
							var error="";
							if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
							var c=narf.length;
							for(var i=0;i<c-1;i++)
							{
								if(narf[i]=="")continue;
								error+=" {"+decodeURIComponent(narf[i])+"}";
							}
							OverlayMessage("The server responded with an unknown error reply."+error);
							return;
						}
						var narf1=narf.shift();
						if(narf1=="MaxIPRequests")
						{
							OverlayMessage("Maximum allowed per-visitor requests reached.");
							return;
						}
						if(narf1=="AlreadyRequestedPlayed")
						{
							OverlayMessage("The requested entry has already been requested or is currently playing.");
							return;
						}
						if(narf1=="AlreadyPlayedOrQueued")
						{
							OverlayMessage("The requested entry is either already playing or is already next to be played.");
							return;
						}
						if(narf1=="RequestIDError")
						{
							OverlayMessage("The requested entry ID was not found.");
							return;
						}
						if(narf1=="MaxTotalRequests")
						{
							OverlayMessage("The maximum number of requests for all visitors has been reached.");
							return;
						}
						if(narf1=="RequestFormatError")
						{
							OverlayMessage("The server responded that an malformed request was received.");
							return;
						}
						if(narf1!="Queued")
						{
							var error="";
							if(narf1!="")error=" {"+decodeURIComponent(narf1)+"}";
							var c=narf.length;
							for(var i=0;i<c-1;i++)
							{
								if(narf[i]=="")continue;
								error+=" {"+decodeURIComponent(narf[i])+"}";
							}
							OverlayMessage("The server responded with an unknown error reply."+error);
							return;
						}
						OverlayMessage("The requested entry has been queued.",function(){WJLastID="";});
					});
				};
				td.appendChild(RequestButton);
				td=document.createElement("td");
				tr.appendChild(td);
				Title=Title.split(" ");
				Title=Title.join("\xA0");
				td.appendChild(document.createTextNode(Title));
				td=document.createElement("td");
				tr.appendChild(td);
				td.appendChild(document.createTextNode("["+ID+"]"));
				td=document.createElement("td");
				td.style.textAlign="right";
				tr.appendChild(td);
				td.appendChild(document.createTextNode(formatTimeDisp(Length)));
			}
		});
	}
	DJSearchForm.onsubmit=function(){DisplaySearchPanelExecuteSearch(null);return false;};
}

function DisplayBrowsePanel()
{
	ClearNodeChildren(document.body);
	document.body.appendChild(CreateNavigator());
	document.body.appendChild(document.createElement("br"));
	var DrivesSpan=document.createElement("span");
	document.body.appendChild(DrivesSpan);
	document.body.appendChild(document.createElement("br"));
	var DJBrowseAddressForm=document.createElement("form");
	DJBrowseAddressForm.id="DJBrowseAddressForm";
	DJBrowseAddressForm.target="_blank";
	DJBrowseAddressForm.action="";
	DJBrowseAddressForm.method="POST";
	DJBrowseAddressForm.onsubmit=function(){return false;};
	document.body.appendChild(DJBrowseAddressForm);
	var DJBrowseAddressEdit=document.createElement("input");
	DJBrowseAddressEdit.id="DJBrowseAddressEdit";
	DJBrowseAddressEdit.name="DJBrowseAddressEdit";
	DJBrowseAddressEdit.type="text";
	DJBrowseAddressEdit.value=LastOpenedDirectory;
	DJBrowseAddressEdit.style.width="36em";
	DJBrowseAddressForm.appendChild(DJBrowseAddressEdit);
	var DJBrowseFilterEdit=document.createElement("input");
	DJBrowseFilterEdit.id="DJBrowseFilterEdit";
	DJBrowseFilterEdit.name="DJBrowseFilterEdit";
	DJBrowseFilterEdit.type="text";
	DJBrowseAddressForm.appendChild(DJBrowseFilterEdit);
	var DJBrowseAddressButton=document.createElement("input");
	DJBrowseAddressButton.name="DJBrowseAddressButton";
	DJBrowseAddressButton.id="DJBrowseAddressButton";
	DJBrowseAddressButton.type="submit";
	DJBrowseAddressButton.value="Update";
	DJBrowseAddressButton.onclick=function()
	{
		DisplayBrowsePanelUpdateBrowseList(null);
	};
	DJBrowseAddressForm.appendChild(DJBrowseAddressButton);
	document.body.appendChild(document.createElement("br"));
	var FoldersSpan=document.createElement("span");
	FoldersSpan.id="FoldersSpan";
	FoldersSpan.className="FoldersSpan";
	document.body.appendChild(FoldersSpan);
	document.body.appendChild(document.createElement("br"));
	document.body.appendChild(document.createElement("br"));
	var ListSpan=document.createElement("span");
	ListSpan.id="ListSpan";
	ListSpan.className="ListSpan";
	document.body.appendChild(ListSpan);
	function DisplayBrowsePanelDisplayFileSelectWindow(File)
	{
		var Window=CreateWindow("File Selection",function(){return false;});
		document.body.appendChild(Window);
		var TFile=File.split(" ");
		TFile=TFile.join("\xA0");
		Window.appendChild(document.createTextNode(TFile));
		Window.appendChild(document.createElement("br"));
		Window.SelectedFile=File;
		var FileSelectDialogQueuePlaylistButton=document.createElement("button");
		FileSelectDialogQueuePlaylistButton.type="button";
		FileSelectDialogQueuePlaylistButton.appendChild(document.createTextNode("Queue\xA0Playlist"));
		FileSelectDialogQueuePlaylistButton.Window=Window;
		FileSelectDialogQueuePlaylistButton.onclick=function()
		{
			var Window=this.Window;
			var File=Window.SelectedFile;
			Window.WindowCloseButton.onclick.call(Window.WindowCloseButton);
			var NavMainButton=document.getElementById("NavMainButton");
			if(NavMainButton)
			{
				NavMainButton.onclick.call(NavMainButton);
				var DJQueuePlaylistEdit=document.getElementById("DJQueuePlaylistEdit");
				if(DJQueuePlaylistEdit)
				{
					DJQueuePlaylistEdit.value=File;
				}
			}
			return false;
		};
		Window.appendChild(FileSelectDialogQueuePlaylistButton);
		var FileSelectDialogDJRequestButton=document.createElement("button");
		FileSelectDialogDJRequestButton.type="button";
		FileSelectDialogDJRequestButton.appendChild(document.createTextNode("DJ\xA0Request"));
		FileSelectDialogDJRequestButton.Window=Window;
		FileSelectDialogDJRequestButton.onclick=function()
		{
			var Window=this.Window;
			var File=Window.SelectedFile;
			Window.WindowCloseButton.onclick.call(Window.WindowCloseButton);
			var NavRequestsButton=document.getElementById("NavRequestsButton");
			if(NavRequestsButton)
			{
				NavRequestsButton.onclick.call(NavRequestsButton);
				var DJRequestFileEdit=document.getElementById("DJRequestFileEdit");
				if(DJRequestFileEdit)
				{
					DJRequestFileEdit.value=File;
				}
			}
			return false;
		};
		Window.appendChild(FileSelectDialogDJRequestButton);
		var FileSelectDialogStopSetsProgramButton=document.createElement("button");
		FileSelectDialogStopSetsProgramButton.type="button";
		FileSelectDialogStopSetsProgramButton.appendChild(document.createTextNode("Stop Sets Program"));
		FileSelectDialogStopSetsProgramButton.Window=Window;
		FileSelectDialogStopSetsProgramButton.onclick=function()
		{
			var Window=this.Window;
			var File=Window.SelectedFile;
			Window.WindowCloseButton.onclick.call(Window.WindowCloseButton);
			var NavStopSetsProgramButton=document.getElementById("NavStopSetsProgramButton");
			if(NavStopSetsProgramButton)
			{
				NavStopSetsProgramButton.onclick.call(NavStopSetsProgramButton);
				var DJStopSetsProgramEdit=document.getElementById("DJStopSetsProgramEdit");
				if(DJStopSetsProgramEdit)
				{
					DJStopSetsProgramEdit.value=File;
				}
			}
			return false;
		};
		Window.appendChild(FileSelectDialogStopSetsProgramButton);
		var FileSelectDialogStopSetsButton=document.createElement("button");
		FileSelectDialogStopSetsButton.type="button";
		FileSelectDialogStopSetsButton.appendChild(document.createTextNode("Stop Sets"));
		FileSelectDialogStopSetsButton.Window=Window;
		FileSelectDialogStopSetsButton.onclick=function()
		{
			var Window=this.Window;
			var File=Window.SelectedFile;
			Window.WindowCloseButton.onclick.call(Window.WindowCloseButton);
			var NavStopSetsButton=document.getElementById("NavStopSetsButton");
			if(NavStopSetsButton)
			{
				NavStopSetsButton.onclick.call(NavStopSetsButton);
				var DJStopSetEdit=document.getElementById("DJStopSetEdit");
				if(DJStopSetEdit)
				{
					DJStopSetEdit.value=File;
				}
			}
			return false;
		};
		Window.appendChild(FileSelectDialogStopSetsButton);
		var FileSelectDialogAddStopSetItemButton=document.createElement("button");
		FileSelectDialogAddStopSetItemButton.type="button";
		FileSelectDialogAddStopSetItemButton.appendChild(document.createTextNode("Add\xA0StopSet\xA0Item"));
		FileSelectDialogAddStopSetItemButton.Window=Window;
		FileSelectDialogAddStopSetItemButton.onclick=function()
		{
			var Window=this.Window;
			var File=Window.SelectedFile;
			Window.WindowCloseButton.onclick.call(Window.WindowCloseButton);
			var NavStopSetsButton=document.getElementById("NavStopSetsButton");
			if(NavStopSetsButton)
			{
				NavStopSetsButton.onclick.call(NavStopSetsButton);
				var DJAddStopSetItemEdit=document.getElementById("DJAddStopSetItemEdit");
				if(DJAddStopSetItemEdit)
				{
					DJAddStopSetItemEdit.value=File;
				}
			}
			return false;
		};
		Window.appendChild(FileSelectDialogAddStopSetItemButton);
		var FileSelectDialogFileInfoButton=document.createElement("button");
		FileSelectDialogFileInfoButton.type="button";
		FileSelectDialogFileInfoButton.appendChild(document.createTextNode("Information"));
		FileSelectDialogFileInfoButton.Window=Window;
		FileSelectDialogFileInfoButton.onclick=function()
		{
			var File=this.Window.SelectedFile;
			OverlayFileInfo(File);
		};
		Window.appendChild(FileSelectDialogFileInfoButton);
		var div=document.createElement("div");
		div.style.textAlign="right";
		Window.appendChild(div);
		var CloseButton=document.createElement("button");
		CloseButton.type="button";
		CloseButton.appendChild(document.createTextNode("Close"));
		CloseButton.Window=Window;
		CloseButton.onclick=function()
		{
			var Window=this.Window;
			Window.WindowCloseButton.onclick.call(Window.WindowCloseButton);
			return false;
		};
		div.appendChild(CloseButton);
	}
	function DisplayBrowsePanelDriveButtonClick()
	{
		var DriveLetter=this.DriveLeter;
		DJBrowseAddressEdit.value=DriveLetter+":";
		DisplayBrowsePanelUpdateBrowseList(null);
	}
	function DisplayBrowsePanelPathButtonClick()
	{
		var BrowsePath=ProcessPath(this.BrowsePath);
		var CurPath=ProcessPath(DJBrowseAddressEdit.value);
		if(BrowsePath==CurPath)return;
		DJBrowseAddressEdit.value=BrowsePath;
		DisplayBrowsePanelUpdateBrowseList(null);
	}
	function DisplayBrowsePanelFolderButtonClick()
	{
		var SelectDirectory=ProcessPath(this.SelectDirectory);
		var CurPath=ProcessPath(DJBrowseAddressEdit.value);
		DJBrowseAddressEdit.value=CurPath+"\\"+SelectDirectory;
		DisplayBrowsePanelUpdateBrowseList(null);
	}
	function DisplayBrowsePanelFileSelectClick()
	{
		var CurPath=ProcessPath(DJBrowseAddressEdit.value);
		DisplayBrowsePanelDisplayFileSelectWindow(CurPath+"\\"+this.SelectFile);
	}
	function DisplayBrowsePanelRefreshDrives(callback)
	{
		var Callback=callback;
		var q=CommonWebJockeyAIURL+"&Command=DJ:DrivesList";
		var WaitObj=OverlayWait();
		RunAjax(q,function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0!="DJ:DrivesListing")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			ClearNodeChildren(DrivesSpan);
			while(narf[0]!=undefined && narf[0]!="" && narf[0]!="DJ:DrivesEndListing")
			{
				var Drive=decodeURIComponent(narf.shift());
				var button=document.createElement("button");
				button.DriveLeter=Drive;
				button.type="button";
				button.appendChild(document.createTextNode(Drive+":"));
				button.onclick=DisplayBrowsePanelDriveButtonClick;
				DrivesSpan.appendChild(button);
			}
			if(Callback)
			{
				Callback();
			}
		},getAjaxIFace());
	}
	function DisplayBrowsePanelUpdateBrowseList(callback)
	{
		var Callback=callback;
		var Address=DJBrowseAddressEdit.value;
		var Filter=DJBrowseFilterEdit.value;
		LastOpenedDirectory=Address;
		LastUsedFilter=Filter;
		cookieCreate("LastOpenedDirectory",LastOpenedDirectory,365);
		cookieCreate("LastUsedFilter",LastUsedFilter,365);
		var q="Command=DJ:Browse";
		if(Address!="" && Filter!="")
		{
			q+="&"+WebJockeyParameterize(Address+"\r\n"+Filter);
		}
		else if(Address!="")
		{
			q+="&"+WebJockeyParameterize(Address);
		}
		else if(Filter!="")
		{
			q+="&"+WebJockeyParameterize(Filter);
		}
		else q=CommonWebJockeyAIURL+"&"+q;
		var WaitObj=OverlayWait();
		RunAjax(q,function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0!="DJ:BrowseReply")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error,function(){ClearNodeChildren(ListSpan);});
				return;
			}
			var narf1=narf.shift();
			if(narf1=="UnAuth")
			{
				ClearNodeChildren(ListSpan);
				OverlayMessage("The specified path/resource is outside the allowed range.",function(){
					DisplayBrowsePanelAuthRangeBrowse(null);
				});
				return;
			}
			if(narf1=="NotFound")
			{
				OverlayMessage("The specified path/resource was not found.",function(){ClearNodeChildren(ListSpan);});
				return;
			}
			if(narf1!="BrowseListing")
			{
				var error="";
				if(narf1!="")error=" {"+decodeURIComponent(narf1)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error,function(){ClearNodeChildren(ListSpan);});
				return;
			}
			var p=ProcessPath(Address);
			ClearNodeChildren(FoldersSpan);
			ClearNodeChildren(ListSpan);
			p=p.split("\\");
			var IsFirstBPB=true;
			var BPDL=" *";
			while(p.length>0)
			{
				var pp=p.join("\\");
				var button=document.createElement("button");
				button.BrowsePath=pp;
				button.appendChild(document.createTextNode(p[p.length-1]+BPDL));
				button.onclick=DisplayBrowsePanelPathButtonClick;
				FoldersSpan.insertBefore(button,FoldersSpan.firstChild);
				if(IsFirstBPB)
				{
					IsFirstBPB=false;
					BPDL=" <--";
				}
				p.pop();
			}
			var table=document.createElement("table");
			ListSpan.appendChild(table);
			var tbody=document.createElement("tbody");
			table.appendChild(tbody);
			while(narf[0]!=undefined && narf[0]!="" && !(narf[0]=="BrowseEndListing" && narf[1]==""))
			{
				var Type=narf.shift();
				var Name=decodeURIComponent(narf.shift());
				TName=Name.split(" ");
				TName=TName.join("\xA0");
				var tr=document.createElement("tr");
				tbody.appendChild(tr);
				var td;
				td=document.createElement("td");
				tr.appendChild(td);
				if(Type=="D" || Type=="LD")
				{
					td.appendChild(document.createTextNode("Directory-->"));
				}
				else
				{
					var button=document.createElement("button");
					button.type="button";
					button.SelectFile=Name;
					button.appendChild(document.createTextNode("Select"));
					button.onclick=DisplayBrowsePanelFileSelectClick;
					td.appendChild(button);
				}
				td=document.createElement("td");
				tr.appendChild(td);
				if(Type=="D" || Type=="LD")
				{
					var button=document.createElement("button");
					button.type="button";
					button.SelectDirectory=Name;
					button.appendChild(document.createTextNode(TName));
					button.onclick=DisplayBrowsePanelFolderButtonClick;
					td.appendChild(button);
				}
				else
				{
					td.appendChild(document.createTextNode(TName));
				}
			}
			if(Callback)
			{
				Callback();
			}
		},getAjaxIFace());
	}
	function DisplayBrowsePanelAuthRangeBrowse(callback)
	{
		var Callback=callback;
		var WaitObj=OverlayWait();
		RunAjax(CommonWebJockeyAIURL+"&Command=DJ:AuthBrowsePath",function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0!="DJ:AuthBrowsePathReply")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error,function(){ClearNodeChildren(ListSpan);});
				return;
			}
			var AuthPath=decodeURIComponent(narf.shift());
			if(AuthPath!=undefined && AuthPath!="")
			{
				DJBrowseAddressEdit.value=AuthPath;
				DisplayBrowsePanelUpdateBrowseList(Callback);
				return;
			}
			if(Callback)
			{
				Callback();
			}
		});
	}
	DisplayBrowsePanelRefreshDrives(function(){
		DisplayBrowsePanelUpdateBrowseList(null);
	});
}

function DisplayStopSetsPanel()
{
	ClearNodeChildren(document.body);
	document.body.appendChild(CreateNavigator());
	document.body.appendChild(document.createElement("br"));
	var DJClearStopSetButton=document.createElement("button");
	DJClearStopSetButton.id="DJClearStopSetButton";
	DJClearStopSetButton.name="DJClearStopSetButton";
	DJClearStopSetButton.type="button";
	DJClearStopSetButton.appendChild(document.createTextNode("Clear StopSet"));
	DJClearStopSetButton.onclick=function()
	{
		var q=CommonWebJockeyAIURL+"&Command=DJ:ClearStopSet";
		var WaitObj=OverlayWait();
		RunAjax(q,function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0!="DJ:ClearStopSetAck")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			OverlayMessage("The command to clear the current stop set is processing.",function(){
				WJLastID="";
			});
		});
	};
	document.body.appendChild(DJClearStopSetButton);
	document.body.appendChild(document.createElement("br"));
	var DJStopSetForm=document.createElement("form");
	DJStopSetForm.id="DJStopSetForm";
	DJStopSetForm.target="_blank";
	DJStopSetForm.action="";
	DJStopSetForm.method="POST";
	DJStopSetForm.onsubmit=function(){return false;};
	document.body.appendChild(DJStopSetForm);
	var DJStopSetEdit=document.createElement("input");
	DJStopSetEdit.id="DJStopSetEdit";
	DJStopSetEdit.name="DJStopSetEdit";
	DJStopSetEdit.type="edit";
	DJStopSetEdit.style.width="39em";
	DJStopSetForm.appendChild(DJStopSetEdit);
	var DJStopSetButton=document.createElement("input");
	DJStopSetButton.id="DJStopSetButton";
	DJStopSetButton.name="DJStopSetButton";
	DJStopSetButton.type="submit";
	DJStopSetButton.value="StopSet";
	DJStopSetForm.appendChild(DJStopSetButton);
	DJStopSetButton.onclick=function()
	{
		if(DJStopSetEdit.value=="")
		{
			OverlayMessage("File name parameter cannot be blank.");
			return;
		}
		var q="Command=DJ:StopSet&"+WebJockeyParameterize(encodeURIComponent(DJStopSetEdit.value));
		var WaitObj=OverlayWait();
		RunAjax(q,function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0=="DJ:StopSetUnAuth")
			{
				OverlayMessage("The supplied file is outside the authorized filesystem range.");
				return;
			}
			if(narf0!="DJ:StopSetAck")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			DisplayStopSetsPanelRefreshStopSetHistorySelect(function(){OverlayMessage("StopSet request accepted.",function(){
				WJLastID="";
			});});
		});
	};
	DJStopSetForm.appendChild(document.createElement("br"));
	var DJStopSetHistoryRemoveButton=document.createElement("input");
	DJStopSetHistoryRemoveButton.id="DJStopSetHistoryRemoveButton";
	DJStopSetHistoryRemoveButton.name="DJStopSetHistoryRemoveButton";
	DJStopSetHistoryRemoveButton.type="button";
	DJStopSetHistoryRemoveButton.value="Remove History";
	DJStopSetForm.appendChild(DJStopSetHistoryRemoveButton);
	DJStopSetHistoryRemoveButton.onclick=function()
	{
		if(DJStopSetSelect.value=="")
		{
			OverlayMessage("File name cannot be blank.");
			return;
		}
		var f=encodeURIComponent(DJStopSetSelect.value);
		var q="Command=DJ:RemoveStopSetFileHistoryItem&"+WebJockeyParameterize(f);
		var WaitObj=OverlayWait();
		RunAjax(q,function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0!="DJ:RemoveStopSetFileHistoryItemReply")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			var narf1=narf.shift();
			if(narf1=="NotFound")
			{
				OverlayMessage("The history item was not found.");
				DisplayMainPanelRefreshPlaylistSelect(null);
				return;
			}
			if(narf1=="FormatError")
			{
				OverlayMessage("The command was invalid or malformed.");
				return;
			}
			if(narf1!="Done")
			{
				var error="";
				if(narf1!="")error=" {"+decodeURIComponent(narf1)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			DisplayStopSetsPanelRefreshStopSetHistorySelect(function(){OverlayMessage("History entry removed successfully.");});
		});
	};
	var DJStopSetSelect=document.createElement("select");
	DJStopSetSelect.id="DJStopSetSelect";
	DJStopSetSelect.name="DJStopSetSelect";
	DJStopSetForm.appendChild(DJStopSetSelect);
	var DJStopSetSelectBlankOption=document.createElement("option");
	DJStopSetSelectBlankOption.appendChild(document.createTextNode(""));
	DJStopSetSelectBlankOption.value="";
	DJStopSetSelect.appendChild(DJStopSetSelectBlankOption);
	DJStopSetSelect.onchange=function()
	{
		DJStopSetEdit.value=this.value;
	};
	document.body.appendChild(document.createElement("br"));
	var DJAddStopSetItemForm=document.createElement("form");
	DJAddStopSetItemForm.id="DJAddStopSetItemForm";
	DJAddStopSetItemForm.target="_blank";
	DJAddStopSetItemForm.action="";
	DJAddStopSetItemForm.method="POST";
	DJAddStopSetItemForm.onsubmit=function(){return false;};
	document.body.appendChild(DJAddStopSetItemForm);
	var DJAddStopSetItemEdit=document.createElement("input");
	DJAddStopSetItemEdit.id="DJAddStopSetItemEdit";
	DJAddStopSetItemEdit.name="DJAddStopSetItemEdit";
	DJAddStopSetItemEdit.type="edit";
	DJAddStopSetItemEdit.style.width="39em";
	DJAddStopSetItemForm.appendChild(DJAddStopSetItemEdit);
	var DJAddStopSetItemButton=document.createElement("input");
	DJAddStopSetItemButton.id="DJAddStopSetItemButton";
	DJAddStopSetItemButton.name="DJAddStopSetItemButton";
	DJAddStopSetItemButton.type="submit";
	DJAddStopSetItemButton.value="Add StopSet Item";
	DJAddStopSetItemForm.appendChild(DJAddStopSetItemButton);
	DJAddStopSetItemButton.onclick=function()
	{
		if(DJAddStopSetItemEdit.value=="")
		{
			OverlayMessage("File name parameter cannot be blank.");
			return;
		}
		var q="Command=DJ:AddStopSetItem&"+WebJockeyParameterize(encodeURIComponent(DJAddStopSetItemEdit.value));
		var WaitObj=OverlayWait();
		RunAjax(q,function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0=="DJ:AddStopSetItemUnAuth")
			{
				OverlayMessage("The supplied file is outside the authorized filesystem range.");
				return;
			}
			if(narf0!="DJ:AddStopSetItemAck")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			DisplayStopSetsPanelRefreshAddStopSetItemHistorySelect(function(){OverlayMessage("AddStopSetItem request accepted.",function(){
				WJLastID="";
			});});
		});
	};
	DJAddStopSetItemForm.appendChild(document.createElement("br"));
	var DJAddStopSetItemHistoryRemoveButton=document.createElement("input");
	DJAddStopSetItemHistoryRemoveButton.id="DJAddStopSetItemHistoryRemoveButton";
	DJAddStopSetItemHistoryRemoveButton.name="DJAddStopSetItemHistoryRemoveButton";
	DJAddStopSetItemHistoryRemoveButton.type="button";
	DJAddStopSetItemHistoryRemoveButton.value="Remove History";
	DJAddStopSetItemForm.appendChild(DJAddStopSetItemHistoryRemoveButton);
	DJAddStopSetItemHistoryRemoveButton.onclick=function()
	{
		if(DJAddStopSetItemSelect.value=="")
		{
			OverlayMessage("File name cannot be blank.");
			return;
		}
		var f=encodeURIComponent(DJAddStopSetItemSelect.value);
		var q="Command=DJ:RemoveStopSetItemHistoryItem&"+WebJockeyParameterize(f);
		var WaitObj=OverlayWait();
		RunAjax(q,function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0!="DJ:RemoveStopSetItemHistoryItemReply")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			var narf1=narf.shift();
			if(narf1=="NotFound")
			{
				OverlayMessage("The history item was not found.");
				DisplayMainPanelRefreshPlaylistSelect(null);
				return;
			}
			if(narf1=="FormatError")
			{
				OverlayMessage("The command was invalid or malformed.");
				return;
			}
			if(narf1!="Done")
			{
				var error="";
				if(narf1!="")error=" {"+decodeURIComponent(narf1)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			DisplayStopSetsPanelRefreshAddStopSetItemHistorySelect(function(){OverlayMessage("History entry removed successfully.");});
		});
	};
	var DJAddStopSetItemSelect=document.createElement("select");
	DJAddStopSetItemSelect.id="DJAddStopSetItemSelect";
	DJAddStopSetItemSelect.name="DJAddStopSetItemSelect";
	DJAddStopSetItemForm.appendChild(DJAddStopSetItemSelect);
	var DJAddStopSetItemSelectBlankOption=document.createElement("option");
	DJAddStopSetItemSelectBlankOption.appendChild(document.createTextNode(""));
	DJAddStopSetItemSelectBlankOption.value="";
	DJAddStopSetItemSelect.appendChild(DJAddStopSetItemSelectBlankOption);
	DJAddStopSetItemSelect.onchange=function()
	{
		DJAddStopSetItemEdit.value=this.value;
	};
	document.body.appendChild(document.createElement("br"));
	var ListSpan=document.createElement("span");
	ListSpan.id="ListSpan";
	ListSpan.className="ListSpan";
	document.body.appendChild(ListSpan);
	function DisplayStopSetsPanelRefreshStopSetHistorySelect(callback)
	{
		var Callback=callback;
		var q=CommonWebJockeyAIURL+"&Command=DJ:StopSetFileHistoryList";
		var WaitObj=OverlayWait();
		RunAjax(q,function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0!="DJ:StopSetFileHistoryListing")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			ClearNodeChildren(DJStopSetSelect);
			DJStopSetSelect.appendChild(DJStopSetSelectBlankOption);
			while(narf[0]!=undefined && narf[0]!="" && narf[0]!="DJ:StopSetFileHistoryEndListing")
			{
				var Title=decodeURIComponent(narf.shift());
				var option=document.createElement("option")
				option.value=Title;
				option.appendChild(document.createTextNode(Title));
				DJStopSetSelect.appendChild(option);
			}
			if(Callback)
			{
				Callback();
			}
		},getAjaxIFace());
	}
	function DisplayStopSetsPanelRefreshAddStopSetItemHistorySelect(callback)
	{
		var Callback=callback;
		var q=CommonWebJockeyAIURL+"&Command=DJ:StopSetItemHistoryList";
		var WaitObj=OverlayWait();
		RunAjax(q,function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0!="DJ:StopSetItemHistoryListing")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			ClearNodeChildren(DJAddStopSetItemSelect);
			DJAddStopSetItemSelect.appendChild(DJAddStopSetItemSelectBlankOption);
			while(narf[0]!=undefined && narf[0]!="" && narf[0]!="DJ:StopSetItemHistoryEndListing")
			{
				var Title=decodeURIComponent(narf.shift());
				var option=document.createElement("option")
				option.value=Title;
				option.appendChild(document.createTextNode(Title));
				DJAddStopSetItemSelect.appendChild(option);
			}
			if(Callback)
			{
				Callback();
			}
		},getAjaxIFace());
	}
	function DisplayStopSetsPanelSongChanged()
	{
		var q=CommonWebJockeyAIURL+"&Command=DJ:StopSetList";
		var WaitObj=OverlayWait();
		RunAjax(q,function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0!="DJ:StopSetListing")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			var i=1;
			ClearNodeChildren(ListSpan);
			var table=document.createElement("table");
			ListSpan.appendChild(table);
			var tbody=document.createElement("tbody");
			table.appendChild(tbody);
			while(narf[0]!=undefined && narf[0]!="" && narf[0]!="DJ:StopSetEndListing")
			{
				var File=decodeURIComponent(narf.shift());
				var Title=decodeURIComponent(narf.shift());
				var Length=parseInt(narf.shift());
				var tr=document.createElement("tr");
				tbody.appendChild(tr);
				var td;
				td=document.createElement("td");
				tr.appendChild(td);
				td.appendChild(document.createTextNode(i+".\xA0"));
				td=document.createElement("td");
				tr.appendChild(td);
				td.setAttribute("nowrap","nowrap");
				td.appendChild(document.createTextNode(Title));
				td=document.createElement("td");
				tr.appendChild(td);
				td.setAttribute("nowrap","nowrap");
				td.appendChild(document.createTextNode(formatTimeDisp(Length)+"\xA0"));
				td=document.createElement("td");
				tr.appendChild(td);
				td.setAttribute("nowrap","nowrap");
				td.appendChild(document.createTextNode(File));
				i++;
			}
		},getAjaxIFace());
	}
	DisplayStopSetsPanelRefreshStopSetHistorySelect(function(){
		DisplayStopSetsPanelRefreshAddStopSetItemHistorySelect(function(){
			SongChangeCallback=DisplayStopSetsPanelSongChanged;
			DisplayStopSetsPanelSongChanged();
		});
	});
}

function DisplayStopSetsProgramPanel()
{
	ClearNodeChildren(document.body);
	document.body.appendChild(CreateNavigator());
	document.body.appendChild(document.createElement("br"));
	var DJStopSetsProgramForm=document.createElement("form");
	DJStopSetsProgramForm.id="StopSetsProgramForm";
	DJStopSetsProgramForm.target="_blank";
	DJStopSetsProgramForm.action="";
	DJStopSetsProgramForm.method="POST";
	DJStopSetsProgramForm.onsubmit=function(){return false;};
	document.body.appendChild(DJStopSetsProgramForm);
	var DJStopSetsProgramEdit=document.createElement("input");
	DJStopSetsProgramEdit.id="DJStopSetsProgramEdit";
	DJStopSetsProgramEdit.name="DJStopSetsProgramEdit";
	DJStopSetsProgramEdit.style.width="39em";
	DJStopSetsProgramForm.appendChild(DJStopSetsProgramEdit);
	var DJStopSetsProgramButton=document.createElement("input");
	DJStopSetsProgramButton.id="DJStopSetsProgramButton";
	DJStopSetsProgramButton.name="DJStopSetsProgramButton";
	DJStopSetsProgramButton.type="submit";
	DJStopSetsProgramButton.value="Stop Sets Program";
	DJStopSetsProgramForm.appendChild(DJStopSetsProgramButton);
	DJStopSetsProgramForm.appendChild(document.createElement("br"));
	var DJStopSetsProgramRemoveHistoryButton=document.createElement("input");
	DJStopSetsProgramRemoveHistoryButton.id="DJStopSetsProgramRemoveHistoryButton";
	DJStopSetsProgramRemoveHistoryButton.name="DJStopSetsProgramRemoveHistoryButton";
	DJStopSetsProgramRemoveHistoryButton.type="button";
	DJStopSetsProgramRemoveHistoryButton.value="Remove History";
	DJStopSetsProgramRemoveHistoryButton.onclick=function()
	{
		var File=DJStopSetsProgramSelect.value;
		if(File=="")
		{
			OverlayMessage("You must first select a history item to remove.");
			return;
		}
		var q=CommonWebJockeyAIURL+"&Command=DJ:RemoveStopSetsProgramHistoryItem&Param1="+encodeURIComponent(File);
		var WaitObj=OverlayWait();
		RunAjax(q,function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0!="DJ:RemoveStopSetsProgramHistoryItemReply")
			{
					var error="";
					if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
					var c=narf.length;
					for(var i=0;i<c-1;i++)
					{
						if(narf[i]=="")continue;
						error+=" {"+decodeURIComponent(narf[i])+"}";
					}
					OverlayMessage("The server responded with an unknown error reply."+error);
					return;
			}
			var narf1=narf.shift();
			if(narf1=="NotFound")
			{
				OverlayMessage("The history item was not found.");
				return;
			}
			if(narf1=="FormatError")
			{
				OverlayMessage("The server reported that the command was formated improperly.");
				return;
			}
			if(narf1!="Done")
			{
				var error="";
				if(narf1!="")error=" {"+decodeURIComponent(narf1)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			DisplayStopSetsProgramPanelRefreshProgramSelect(function(){
				OverlayMessage("History item removal processed.");
			});
		});
	};
	DJStopSetsProgramForm.appendChild(DJStopSetsProgramRemoveHistoryButton);
	var DJStopSetsProgramSelect=document.createElement("select");
	DJStopSetsProgramSelect.id="DJStopSetsProgramSelect";
	DJStopSetsProgramSelect.name="DJStopSetsProgramSelect";
	DJStopSetsProgramForm.appendChild(DJStopSetsProgramSelect);
	DJStopSetsProgramSelectBlankOption=document.createElement("option");
	DJStopSetsProgramSelectBlankOption.value="";
	DJStopSetsProgramSelectBlankOption.appendChild(document.createTextNode(""));
	DJStopSetsProgramSelect.onchange=function()
	{
		DJStopSetsProgramEdit.value=DJStopSetsProgramSelect.value;
	};
	DJStopSetsProgramSelect.appendChild(DJStopSetsProgramSelectBlankOption);
	function DisplayStopSetsProgramPanelRefreshProgramSelect(callback)
	{
		var Callback=callback;
		var q=CommonWebJockeyAIURL+"&Command=DJ:StopSetsProgramHistoryList";
		var WaitObj=OverlayWait();
		RunAjax(q,function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0!="DJ:StopSetsProgramHistoryListing")
			{
					var error="";
					if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
					var c=narf.length;
					for(var i=0;i<c-1;i++)
					{
						if(narf[i]=="")continue;
						error+=" {"+decodeURIComponent(narf[i])+"}";
					}
					OverlayMessage("The server responded with an unknown error reply."+error);
					return;
			}
			ClearNodeChildren(DJStopSetsProgramSelect);
			DJStopSetsProgramSelect.appendChild(DJStopSetsProgramSelectBlankOption);
			while(narf[0]!=undefined && narf[0]!="" && narf[0]!="DJ:StopSetsProgramHistoryEndListing")
			{
				var file=decodeURIComponent(narf.shift());
				var tfile=file.split(" ");
				tfile=tfile.join("\xA0");
				var option=document.createElement("option");
				option.value=file;
				option.appendChild(document.createTextNode(tfile));
				DJStopSetsProgramSelect.appendChild(option);
			}
			if(Callback)
			{
				Callback();
			}
		},getAjaxIFace());
	}
	function DisplayStopSetsProgramPanelFormSubmit(callback)
	{
		var Callback=callback;
		var File=DJStopSetsProgramEdit.value;
		if(File=="")
		{
			OverlayMessage("The Stop Sets Program file field cannot be blank.");
			return;
		}
		var q="Command=DJ:LoadStopSetsProgram&"+WebJockeyParameterize(encodeURIComponent(File));
		var WaitObj=OverlayWait();
		RunAjax(q,function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0=="DJ:LoadStopSetsProgramUnAuth")
			{
				OverlayMessage("The selected Stop Sets Program file is outside the allowed range.");
				return;
			}
			if(narf0!="DJ:LoadStopSetsProgramAck")
			{
					var error="";
					if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
					var c=narf.length;
					for(var i=0;i<c-1;i++)
					{
						if(narf[i]=="")continue;
						error+=" {"+decodeURIComponent(narf[i])+"}";
					}
					OverlayMessage("The server responded with an unknown error reply."+error);
					return;
			}
			DisplayStopSetsProgramPanelRefreshProgramSelect(function(){
				OverlayMessage("Stop Sets Program command is now processing.");
				if(Callback)
				{
					Callback();
				}
			});
		});
	}
	DisplayStopSetsProgramPanelRefreshProgramSelect(null);
	DJStopSetsProgramForm.onsubmit=function()
	{
		DisplayStopSetsProgramPanelFormSubmit(null);
		return false;
	};
}

function DisplayRequestsPanel()
{
	ClearNodeChildren(document.body);
	document.body.appendChild(CreateNavigator());
	document.body.appendChild(document.createElement("br"));
	var DJPurgeRequestsButton=document.createElement("button");
	DJPurgeRequestsButton.id="DJPurgeRequestsButton";
	DJPurgeRequestsButton.name="DJPurgeRequestsButton";
	DJPurgeRequestsButton.type="button";
	DJPurgeRequestsButton.appendChild(document.createTextNode("Purge Requests"));
	DJPurgeRequestsButton.onclick=function()
	{
		var q=CommonWebJockeyAIURL+"&Command=DJ:PurgeRequests";
		var WaitObj=OverlayWait();
		RunAjax(q,function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0!="DJ:PurgeRequestsDone")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			OverlayMessage("The command to purge requests was completed successfully.",function(){WJLastID="";});
		});
	};
	document.body.appendChild(DJPurgeRequestsButton);
	var DJPurgeOpenRequestsButton=document.createElement("button");
	DJPurgeOpenRequestsButton.id="DJPurgeOpenRequestsButton";
	DJPurgeOpenRequestsButton.name="DJPurgeOpenRequestsButton";
	DJPurgeOpenRequestsButton.type="button";
	DJPurgeOpenRequestsButton.appendChild(document.createTextNode("Purge Open Requests"));
	DJPurgeOpenRequestsButton.onclick=function()
	{
		var q=CommonWebJockeyAIURL+"&Command=DJ:PurgeOpenRequests";
		var WaitObj=OverlayWait();
		RunAjax(q,function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0!="DJ:PurgeOpenRequestsDone")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			OverlayMessage("The command to purge open requests was completed successfully.",function(){WJLastID="";});
		});
	};
	document.body.appendChild(DJPurgeOpenRequestsButton);
	document.body.appendChild(document.createElement("br"));
	var DJRequestFileForm=document.createElement("form");
	DJRequestFileForm.id="DJRequestFileForm";
	DJRequestFileForm.target="_blank";
	DJRequestFileForm.action="";
	DJRequestFileForm.method="POST";
	DJRequestFileForm.onsubmit=function(){return false;};
	document.body.appendChild(DJRequestFileForm);
	var DJRequestFileEdit=document.createElement("input");
	DJRequestFileEdit.id="DJRequestFileEdit";
	DJRequestFileEdit.name="DJRequestFileEdit";
	DJRequestFileEdit.type="edit";
	DJRequestFileEdit.style.width="39em";
	DJRequestFileForm.appendChild(DJRequestFileEdit);
	var DJRequestFileButton=document.createElement("input");
	DJRequestFileButton.id="DJRequestFileButton";
	DJRequestFileButton.name="DJRequestFileButton";
	DJRequestFileButton.type="submit";
	DJRequestFileButton.value="DJ Request";
	DJRequestFileForm.appendChild(DJRequestFileButton);
	DJRequestFileButton.onclick=function()
	{
		if(DJRequestFileEdit.value=="")
		{
			OverlayMessage("File name parameter cannot be blank.");
			return;
		}
		var q="Command=DJ:Request&"+WebJockeyParameterize("IP\r\n"+encodeURIComponent(DJRequestFileEdit.value));
		var WaitObj=OverlayWait();
		RunAjax(q,function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0=="DJ:RequestUnAuth")
			{
				OverlayMessage("The supplied file is outside the authorized filesystem range.");
				return;
			}
			if(narf0=="DJ:RequestError")
			{
				OverlayMessage("An error occurred while attempting to access the supplied playlist file.");
				return;
			}
			if(narf0!="DJ:RequestReply")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			var narf1=narf.shift();
			if(narf1=="RequestUnAuth")
			{
				OverlayMessage("The request is outside the allowed authorized range.");
				return;
			}
			if(narf1=="AlreadyNowPlaying")
			{
				OverlayMessage("The requested entry is already playing.");
				return;
			}
			if(narf1=="NotFound")
			{
				OverlayMessage("The requested entry was not found.");
				return;
			}
			if(narf1!="RequestDone")
			{
				var error="";
				if(narf1!="")error=" {"+decodeURIComponent(narf1)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			DisplayRequestsPanelRefreshRequestFileSelect(function(){
				OverlayMessage("DJ Request accepted.",function(){
					WJLastID="";
				});
			});
		});
	};
	DJRequestFileForm.appendChild(document.createElement("br"));
	var DJRequestFileHistoryRemoveButton=document.createElement("input");
	DJRequestFileHistoryRemoveButton.id="DJRequestFileHistoryRemoveButton";
	DJRequestFileHistoryRemoveButton.name="DJRequestFileHistoryRemoveButton";
	DJRequestFileHistoryRemoveButton.type="button";
	DJRequestFileHistoryRemoveButton.value="Remove History";
	DJRequestFileForm.appendChild(DJRequestFileHistoryRemoveButton);
	DJRequestFileHistoryRemoveButton.onclick=function()
	{
		var f=encodeURIComponent(DJRequestFileSelect.value);
		var q="Command=DJ:RemoveRequestHistoryItem&"+WebJockeyParameterize(f);
		var WaitObj=OverlayWait();
		RunAjax(q,function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0!="DJ:RemoveRequestHistoryItemReply")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			var narf1=narf.shift();
			if(narf1=="NotFound")
			{
				OverlayMessage("The history item was not found.");
				DisplayMainPanelRefreshPlaylistSelect(null);
				return;
			}
			if(narf1=="FormatError")
			{
				OverlayMessage("The command was invalid or malformed.");
				return;
			}
			if(narf1!="Done")
			{
				var error="";
				if(narf1!="")error=" {"+decodeURIComponent(narf1)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			DisplayRequestsPanelRefreshRequestFileSelect(function(){OverlayMessage("History entry removed successfully.");});
		});
	};
	var DJRequestFileSelect=document.createElement("select");
	DJRequestFileSelect.id="DJRequestFileSelect";
	DJRequestFileSelect.name="DJRequestFileSelect";
	DJRequestFileForm.appendChild(DJRequestFileSelect);
	var DJRequestFileSelectBlankOption=document.createElement("option");
	DJRequestFileSelectBlankOption.appendChild(document.createTextNode(""));
	DJRequestFileSelectBlankOption.value="";
	DJRequestFileSelect.appendChild(DJRequestFileSelectBlankOption);
	DJRequestFileSelect.onchange=function()
	{
		DJRequestFileEdit.value=this.value;
	};
	document.body.appendChild(document.createElement("br"));
	var ListSpan=document.createElement("span");
	ListSpan.id="ListSpan";
	ListSpan.className="ListSpan";
	document.body.appendChild(ListSpan);
	function DisplayRequestsPanelRefreshRequestFileSelect(callback)
	{
		var Callback=callback;
		var WaitObj=OverlayWait();
		var q=CommonWebJockeyAIURL+"&Command=DJ:RequestHistoryList";
		RunAjax(q,function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0!="DJ:RequestHistoryListing")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				if(Callback){Callback();}
				return;
			}
			ClearNodeChildren(DJRequestFileSelect);
			DJRequestFileSelect.appendChild(DJRequestFileSelectBlankOption);
			var tt=narf.shift();
			while(tt!="DJ:RequestHistoryEndListing")
			{
				var option=document.createElement("option");
				option.value=tt;
				option.appendChild(document.createTextNode(tt));
				DJRequestFileSelect.appendChild(option);
				tt=narf.shift();
			}
			if(Callback){Callback();}
		},getAjaxIFace());
	}
	function DisplayRequestsPanelSongChanged()
	{
		var q=CommonWebJockeyAIURL+"&Command=DJ:RequestsList";
		var WaitObj=OverlayWait();
		RunAjax(q,function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0!="DJ:RequestsListing")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			ClearNodeChildren(ListSpan);
			var TIDs=new Array(0);
			var table=document.createElement("table");
			ListSpan.appendChild(table);
			var tbody=document.createElement("tbody");
			table.appendChild(tbody);
			var i=0;
			while(narf[0]!=undefined && narf[0]!="" && narf[0]!="DJ:RequestsEndListing")
			{
				var ID=narf.shift();
				var IP=narf.shift();
				var Time=parseInt(narf.shift());
				var Title=decodeURIComponent(narf.shift());
				TIDs[i]=ID;
				var tr=document.createElement("tr");
				tbody.appendChild(tr);
				var td;
				td=document.createElement("td");
				tr.appendChild(td);
				td.appendChild(document.createTextNode((i+1)+".\xA0"));
				td=document.createElement("td");
				tr.appendChild(td);
				var button=document.createElement("button");
				button.appendChild(document.createTextNode("Info"));
				button.SongID=ID;
				td.appendChild(button);
				button.onclick=function()
				{
					var ID=this.SongID;
					OverlayFileInfo(ID);
				};
				td=document.createElement("td");
				td.setAttribute("nowrap","nowrap");
				tr.appendChild(td);
				Title=Title.split(" ");
				Title=Title.join("\xA0");
				td.appendChild(document.createTextNode(Title));
				td=document.createElement("td");
				td.setAttribute("nowrap","nowrap");
				tr.appendChild(td);
				td.appendChild(document.createTextNode("["+ID+"]"));
				td=document.createElement("td");
				td.setAttribute("nowrap","nowrap");
				tr.appendChild(td);
				td.appendChild(document.createTextNode(IP));
			}
		},getAjaxIFace());
	}
	DisplayRequestsPanelRefreshRequestFileSelect(function(){
		SongChangeCallback=DisplayRequestsPanelSongChanged;
		DisplayRequestsPanelSongChanged();
	});
}

function DisplayMainPanel()
{
	ClearNodeChildren(document.body);
	document.body.appendChild(CreateNavigator());
	document.body.appendChild(document.createElement("br"));
	var DJPurgePlayedButton=document.createElement("button");
	DJPurgePlayedButton.id="DJPurgePlayedButton";
	DJPurgePlayedButton.type="button";
	DJPurgePlayedButton.appendChild(document.createTextNode("Purge Played"));
	document.body.appendChild(DJPurgePlayedButton);
	DJPurgePlayedButton.onclick=function()
	{
		var WaitObj=OverlayWait();
		RunAjax("Command=DJ:PurgePlayed",function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0!="DJ:PurgePlayedDone")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			OverlayMessage("Recently played history has been purged.",function(){WJLastID="";});
		});
	};
	var DJShuffleListButton=document.createElement("button");
	DJShuffleListButton.id="DJShuffleListButton";
	DJShuffleListButton.type="button";
	DJShuffleListButton.appendChild(document.createTextNode("Shuffle List"));
	document.body.appendChild(DJShuffleListButton);
	DJShuffleListButton.onclick=function()
	{
		var WaitObj=OverlayWait();
		RunAjax("Command=DJ:ShuffleList",function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0!="DJ:ShuffleListAck")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			OverlayMessage("Acknowledgement of the command to shuffle the current playlist received.",function(){WJLastID="";});
		});
	};
	var DJSkipNowButton=document.createElement("button");
	DJSkipNowButton.id="DJSkipNowButton";
	DJSkipNowButton.type="button";
	DJSkipNowButton.appendChild(document.createTextNode("Skip Now"));
	document.body.appendChild(DJSkipNowButton);
	DJSkipNowButton.onclick=function()
	{
		var WaitObj=OverlayWait();
		RunAjax("Command=NowPlaying",function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0!="NowPlayingReply")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			var ID=narf.shift();
			var q="Command=DJ:SkipNow&"+WebJockeyParameterize("127.0.0.1\r\n"+ID);
			var WaitObj=OverlayWait();
			RunAjax(q,function(){
				try{WaitObj.Close();}catch(err){OverlayWaitClose();}
				var narf=this.responseText;
				narf=narf.split("\r\n");
				var narf0=narf.shift();
				if(narf0!="DJ:SkipNowReply")
				{
					var error="";
					if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
					var c=narf.length;
					for(var i=0;i<c-1;i++)
					{
						if(narf[i]=="")continue;
						error+=" {"+decodeURIComponent(narf[i])+"}";
					}
					OverlayMessage("The server responded with an unknown error reply."+error);
					return;
				};
				var narf1=narf.shift();
				if(narf1=="NotPlaying")
				{
					OverlayMessage("The entry is no longer playing.");
					return;
				}
				if(narf1=="SkipVoteIDError")
				{
					OverlayMessage("The entry is not present in the current list.");
					return;
				}
				if(narf1!="SkipNowAccepted")
				{
					var error="";
					if(narf1!="")error=" {"+decodeURIComponent(narf1)+"}";
					var c=narf.length;
					for(var i=0;i<c-1;i++)
					{
						if(narf[i]=="")continue;
						error+=" {"+decodeURIComponent(narf[i])+"}";
					}
					OverlayMessage("The server responded with an unknown error reply."+error);
					return;
				}
				OverlayMessage("The command to skip the current list entry has been accepted.");
			});
		});
	};
	document.body.appendChild(document.createElement("br"));
	var DJSeekForm=document.createElement("form");
	DJSeekForm.id="DJSeekForm";
	DJSeekForm.target="_blank";
	DJSeekForm.action="";
	DJSeekForm.method="POST";
	DJSeekForm.onsubmit=function(){return false;};
	document.body.appendChild(DJSeekForm);
	var DJSeekEdit=document.createElement("input");
	DJSeekEdit.id="DJSeekEdit";
	DJSeekEdit.name="DJSeekEdit";
	DJSeekEdit.type="number";
	DJSeekEdit.step="0.1";
	DJSeekEdit.value=cookieRead("SeekToTime");
	DJSeekEdit.onchange=function()
	{
		var SeekToTime=parseFloat(DJSeekEdit.value);
		if(isNaN(SeekToTime))
		{
			return;
		}
		cookieCreate("SeekToTime",DJSeekEdit.value,365);
	};
	DJSeekForm.appendChild(DJSeekEdit);
	var DJSeekButton=document.createElement("input");
	DJSeekButton.id="DJSeekButton";
	DJSeekButton.name="DJSeekButton";
	DJSeekButton.type="submit";
	DJSeekButton.value="Seek";
	DJSeekForm.appendChild(DJSeekButton);
	function DisplayMainPanelDJSeekGo()
	{
		var WaitObj=OverlayWait();
		var SeekToTime=parseFloat(DJSeekEdit.value);
		if(isNaN(SeekToTime))
		{
			OverlayMessage("The entered value is invalid for the command.");
			return;
		}
		RunAjax("Command=DJ:SeekToTime&"+WebJockeyParameterize(DJSeekEdit.value),function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0!="DJ:SeekToTimeAck")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			OverlayMessage("Acknowledgement of the command to seek the currently playing entry received.");
		});
	}
	DJSeekForm.onsubmit=function(){DisplayMainPanelDJSeekGo();return false;};
	document.body.appendChild(document.createElement("br"));
	var DJQueuePlaylistForm=document.createElement("form");
	DJQueuePlaylistForm.id="DJQueuePlaylistForm";
	DJQueuePlaylistForm.target="_blank";
	DJQueuePlaylistForm.action="";
	DJQueuePlaylistForm.method="POST";
	DJQueuePlaylistForm.onsubmit=function(){return false;};
	document.body.appendChild(DJQueuePlaylistForm);
	var DJQueuePlaylistEdit=document.createElement("input");
	DJQueuePlaylistEdit.id="DJQueuePlaylistEdit";
	DJQueuePlaylistEdit.name="DJQueuePlaylistEdit";
	DJQueuePlaylistEdit.type="edit";
	DJQueuePlaylistEdit.style.width="39em";
	DJQueuePlaylistForm.appendChild(DJQueuePlaylistEdit);
	var DJQueuePlaylistButton=document.createElement("input");
	DJQueuePlaylistButton.id="DJQueuePlaylistButton";
	DJQueuePlaylistButton.name="DJQueuePlaylistButton";
	DJQueuePlaylistButton.type="submit";
	DJQueuePlaylistButton.value="Queue Playlist";
	DJQueuePlaylistForm.appendChild(DJQueuePlaylistButton);
	DJQueuePlaylistButton.onclick=function()
	{
		if(DJQueuePlaylistEdit.value=="")
		{
			OverlayMessage("File name parameter cannot be blank.");
			return;
		}
		var q="Command=DJ:QueuePlaylist&"+WebJockeyParameterize(encodeURIComponent(DJQueuePlaylistEdit.value));
		var WaitObj=OverlayWait();
		RunAjax(q,function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0=="DJ:QueuePlaylistUnAuth")
			{
				OverlayMessage("The supplied playlist file is outside the authorized filesystem range.");
				return;
			}
			if(narf0=="DJ:QueuePlaylistError")
			{
				OverlayMessage("An error occurred while attempting to access the supplied playlist file.");
				return;
			}
			if(narf0!="DJ:QueuePlaylistSent")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			DisplayMainPanelRefreshPlaylistSelect(function(){OverlayMessage("Received successful acknowledgement, the playlist file will be processed.",function(){WJLastID="";});});
		});
	};
	DJQueuePlaylistForm.appendChild(document.createElement("br"));
	var DJQueuePlaylistHistoryRemoveButton=document.createElement("input");
	DJQueuePlaylistHistoryRemoveButton.id="DJQueuePlaylistHistoryRemoveButton";
	DJQueuePlaylistHistoryRemoveButton.name="DJQueuePlaylistHistoryRemoveButton";
	DJQueuePlaylistHistoryRemoveButton.type="button";
	DJQueuePlaylistHistoryRemoveButton.value="Remove History";
	DJQueuePlaylistForm.appendChild(DJQueuePlaylistHistoryRemoveButton);
	DJQueuePlaylistHistoryRemoveButton.onclick=function()
	{
		var f=encodeURIComponent(DJQueuePlaylistSelect.value);
		var q="Command=DJ:RemovePlaylistHistoryItem&"+WebJockeyParameterize(f);
		var WaitObj=OverlayWait();
		RunAjax(q,function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0!="DJ:RemovePlaylistHistoryItemReply")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			var narf1=narf.shift();
			if(narf1=="NotFound")
			{
				OverlayMessage("The history item was not found.");
				DisplayMainPanelRefreshPlaylistSelect(null);
				return;
			}
			if(narf1=="FormatError")
			{
				OverlayMessage("The command was invalid or malformed.");
				return;
			}
			if(narf1!="Done")
			{
				var error="";
				if(narf1!="")error=" {"+decodeURIComponent(narf1)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			DisplayMainPanelRefreshPlaylistSelect(function(){OverlayMessage("History entry removed successfully.");});
		});
	};
	var DJQueuePlaylistSelect=document.createElement("select");
	DJQueuePlaylistSelect.id="DJQueuePlaylistSelect";
	DJQueuePlaylistSelect.name="DJQueuePlaylistSelect";
	DJQueuePlaylistForm.appendChild(DJQueuePlaylistSelect);
	var DJQueuePlaylistSelectBlankOption=document.createElement("option");
	DJQueuePlaylistSelectBlankOption.appendChild(document.createTextNode(""));
	DJQueuePlaylistSelectBlankOption.value="";
	DJQueuePlaylistSelect.appendChild(DJQueuePlaylistSelectBlankOption);
	DJQueuePlaylistSelect.onchange=function()
	{
		DJQueuePlaylistEdit.value=this.value;
	};
	function DisplayMainPanelRefreshPlaylistSelect(callback)
	{
		var Callback=callback;
		var WaitObj=OverlayWait();
		var q=CommonWebJockeyAIURL+"&Command=DJ:PlaylistHistoryList";
		RunAjax(q,function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0!="DJ:PlaylistHistoryListing")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				if(Callback){Callback();}
				return;
			}
			ClearNodeChildren(DJQueuePlaylistSelect);
			DJQueuePlaylistSelect.appendChild(DJQueuePlaylistSelectBlankOption);
			var tt=narf.shift();
			while(tt!="DJ:PlaylistHistoryEndListing")
			{
				var option=document.createElement("option");
				option.value=tt;
				option.appendChild(document.createTextNode(tt));
				DJQueuePlaylistSelect.appendChild(option);
				tt=narf.shift();
			}
			if(Callback){Callback();}
		},getAjaxIFace());
	}
	document.body.appendChild(document.createElement("br"));
	var ListSpan=document.createElement("span");
	ListSpan.id="ListSpan";
	ListSpan.className="ListSpan";
	document.body.appendChild(ListSpan);
	function DisplayMainPanelSongChanged()
	{
		var WaitObj=OverlayWait();
		RunAjax(CommonWebJockeyAIURL+"&Command=DJ:Played",function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0!="DJ:PlayedListing")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				ClearNodeChildren(ListSpan);
				return;
			}
			delete LastWJPlayedIDs;
			delete LastWJPlayedIPs;
			delete LastWJPlayedTimes;
			LastWJPlayedIDs=new Array(0);
			LastWJPlayedIPs=new Array(0);
			LastWJPlayedTimes=new Array(0);
			var n=narf[0];
			var i=0;
			while(n!=undefined && n!="DJ:PlayedEndListing")
			{
				var ID=narf.shift();
				var IP=narf.shift();
				var Time=parseInt(narf.shift());
				n=narf[0];
				LastWJPlayedIDs[i]=ID;
				LastWJPlayedIPs[i]=IP;
				LastWJPlayedTimes[i]=Time;
				i++;
			}
			var WaitObj=OverlayWait();
			RunAjax(CommonWebJockeyAIURL+"&Command=List",function(){
				try{WaitObj.Close();}catch(err){OverlayWaitClose();}
				var narf=this.responseText;
				narf=narf.split("\r\n");
				var narf0=narf.shift();
				if(narf0!="Listing")
				{
					var error="";
					if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
					var c=narf.length;
					for(var i=0;i<c-1;i++)
					{
						if(narf[i]=="")continue;
						error+=" {"+decodeURIComponent(narf[i])+"}";
					}
					OverlayMessage("The server responded with an unknown error reply."+error);
					ClearNodeChildren(ListSpan);
					return;
				}
				delete LastWJListIDs;
				delete LastWJListTimes;
				delete LastWJListTitles;
				LastWJListIDs=new Array(0);
				LastWJListTimes=new Array(0);
				LastWJListTitles=new Array(0);
				var n=narf[0];
				var i=0;
				while(n!=undefined && n!="EndListing")
				{
					var ID=narf.shift();
					var Title=decodeURIComponent(narf.shift());
					var Time=parseInt(narf.shift());
					LastWJListIDs[i]=ID;
					LastWJListTimes[i]=Time;
					LastWJListTitles[i]=Title;
					n=narf[0];
					i++;
				}
				ClearNodeChildren(ListSpan);
				var BPWJDJCPtable=document.createElement("table");
				BPWJDJCPtable.id="BPWJDJCPtable";
				BPWJDJCPtable.className="BPWJDJCPtable";
				ListSpan.appendChild(BPWJDJCPtable);
				var tbody=document.createElement("tbody");
				BPWJDJCPtable.appendChild(tbody);
				var l=LastWJListIDs.length;
				for(var i=0;i<l;i++)
				{
					var ds=LastWJListTitles[i].split(" ");
					ds=ds.join("\xA0");
					var ID=LastWJListIDs[i];
					t=formatTimeDisp(LastWJListTimes[i]);
					var tr=document.createElement("tr");
					tbody.appendChild(tr);
					var td=document.createElement("td");
					tr.appendChild(td);
					var DJFileInfoButton=document.createElement("button");
					DJFileInfoButton.type="button";
					DJFileInfoButton.SongID=ID;
					DJFileInfoButton.appendChild(document.createTextNode("Info"));
					DJFileInfoButton.onclick=function()
					{
						var ID=this.SongID;
						OverlayFileInfo(ID);
						return false;
					};
					td.appendChild(DJFileInfoButton);
					td=document.createElement("td");
					tr.appendChild(td);
					var DJRequestButton=document.createElement("button");
					DJRequestButton.type="button";
					DJRequestButton.SongID=ID;
					DJRequestButton.appendChild(document.createTextNode("DJ Request"));
					DJRequestButton.onclick=function()
					{
						var ID=this.SongID;
						var q="Command=DJ:Request&"+WebJockeyParameterize("IP\r\n"+ID);
						var WaitObj=OverlayWait();
						RunAjax(q,function(){
							try{WaitObj.Close();}catch(err){OverlayWaitClose();};
							var narf=this.responseText;
							narf=narf.split("\r\n");
							var narf0=narf.shift();
							if(narf0!="DJ:RequestReply")
							{
								var error="";
								if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
								var c=narf.length;
								for(var i=0;i<c-1;i++)
								{
									if(narf[i]=="")continue;
									error+=" {"+decodeURIComponent(narf[i])+"}";
								}
								OverlayMessage("The server responded with an unknown error reply."+error);
								return;
							}
							var narf1=narf.shift();
							if(narf1=="RequestUnAuth")
							{
								OverlayMessage("The requested entry is outside the allowed path.");
								return;
							}
							if(narf1=="AlreadyNowPlaying")
							{
								OverlayMessage("The requested entry is already playing or is already next to be played.");
								return;
							}
							if(narf1=="NotFound")
							{
								OverlayMessage("The requested entry was not found.");
								return;
							}
							if(narf1!="RequestDone")
							{
								var error="";
								if(narf1!="")error=" {"+decodeURIComponent(narf1)+"}";
								var c=narf.length;
								for(var i=0;i<c-1;i++)
								{
									if(narf[i]=="")continue;
									error+=" {"+decodeURIComponent(narf[i])+"}";
								}
								OverlayMessage("The server responded with an unknown error reply."+error);
								return;
							}
							OverlayMessage("The requested entry has been queued.",function(){WJLastID="";});
						});
					};
					td.appendChild(DJRequestButton);
					td=document.createElement("td");
					tr.appendChild(td);
					var RequestButton=document.createElement("button");
					RequestButton.type="button";
					RequestButton.SongID=ID;
					RequestButton.onclick=function()
					{
						var ID=this.SongID;
						var q="Command=Request&"+WebJockeyParameterize("IP\r\n"+ID);
						var WaitObj=OverlayWait();
						RunAjax(q,function(){
							try{WaitObj.Close();}catch(err){OverlayWaitClose();};
							var narf=this.responseText;
							narf=narf.split("\r\n");
							var narf0=narf.shift();
							if(narf0!="RequestReply")
							{
								var error="";
								if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
								var c=narf.length;
								for(var i=0;i<c-1;i++)
								{
									if(narf[i]=="")continue;
									error+=" {"+decodeURIComponent(narf[i])+"}";
								}
								OverlayMessage("The server responded with an unknown error reply."+error);
								return;
							}
							var narf1=narf.shift();
							if(narf1=="MaxIPRequests")
							{
								OverlayMessage("Maximum allowed per-visitor requests reached.");
								return;
							}
							if(narf1=="AlreadyRequestedPlayed")
							{
								OverlayMessage("The requested entry has already been requested or is currently playing.");
								return;
							}
							if(narf1=="AlreadyPlayedOrQueued")
							{
								OverlayMessage("The requested entry is either already playing or is already next to be played.");
								return;
							}
							if(narf1=="RequestIDError")
							{
								OverlayMessage("The requested entry ID was not found.");
								return;
							}
							if(narf1=="MaxTotalRequests")
							{
								OverlayMessage("The maximum number of requests for all visitors has been reached.");
								return;
							}
							if(narf1=="RequestFormatError")
							{
								OverlayMessage("The server responded that an malformed request was received.");
								return;
							}
							if(narf1!="Queued")
							{
								var error="";
								if(narf1!="")error=" {"+decodeURIComponent(narf1)+"}";
								var c=narf.length;
								for(var i=0;i<c-1;i++)
								{
									if(narf[i]=="")continue;
									error+=" {"+decodeURIComponent(narf[i])+"}";
								}
								OverlayMessage("The server responded with an unknown error reply."+error);
								return;
							}
							OverlayMessage("The requested entry has been queued.",function(){WJLastID="";});
						});
					};
					RequestButton.appendChild(document.createTextNode("Request"));
					if(LastWJPlayedIDs.indexOf(ID)>-1)
					{
						RequestButton.disabled=true;
					}
					td.appendChild(RequestButton);
					td=document.createElement("td");
					tr.appendChild(td);
					td.appendChild(document.createTextNode((i+1)+".\xA0"));
					td=document.createElement("td");
					td.setAttribute("nowrap","nowrap");
					tr.appendChild(td);
					td.appendChild(document.createTextNode(ds));
					td=document.createElement("td");
					tr.appendChild(td);
					td.appendChild(document.createTextNode(ID));
					td=document.createElement("td");
					tr.appendChild(td);
					td.appendChild(document.createTextNode(t));
				}
			},getAjaxIFace());
		},getAjaxIFace());
	}
	DisplayMainPanelRefreshPlaylistSelect(function(){
		//WJLastID="";
		//WJLastTime=-2;
		SongChangeCallback=DisplayMainPanelSongChanged;
		DisplayMainPanelSongChanged();
	});
}

function DisplayLogin()
{
	ClearNodeChildren(document.body);
	var LoginForm=document.createElement("form");
	LoginForm.id="LoginForm";
	LoginForm.target="_blank";
	LoginForm.action="";
	LoginForm.method="POST";
	LoginForm.onsubmit=function(){return false;};
	document.body.appendChild(LoginForm);
	LoginForm.appendChild(document.createTextNode("Please login."));
	LoginForm.appendChild(document.createElement("br"));
	var LoginTable=document.createElement("table");
	LoginTable.id="LoginTable";
	LoginForm.appendChild(LoginTable);
	var tr=document.createElement("tr");
	LoginTable.appendChild(tr);
	var td=document.createElement("td");
	tr.appendChild(td);
	td.appendChild(document.createTextNode("Password:"));
	td=document.createElement("td");
	tr.appendChild(td);
	Label=document.createElement("label");
	td.appendChild(Label);
	MakeRequired(Label);
	var LoginPasswordInput=document.createElement("input");
	LoginPasswordInput.id="LoginPasswordInput";
	LoginPasswordInput.name="LoginPasswordInput";
	LoginPasswordInput.type="password";
	MakeRequired(LoginPasswordInput);
	Label.appendChild(LoginPasswordInput);
	tr=document.createElement("tr");
	LoginTable.appendChild(tr);
	td=document.createElement("td");
	td.colSpan="2";
	td.style.textAlign="right";
	tr.appendChild(td);
	var LoginSubmitButton=document.createElement("input");
	LoginSubmitButton.id="LoginSubmitButton";
	LoginSubmitButton.name="LoginSubmitButton";
	LoginSubmitButton.type="submit";
	LoginSubmitButton.value="Login";
	td.appendChild(LoginSubmitButton);
	LoginForm.onsubmit=function()
	{
		var LoginPassword=LoginPasswordInput.value;
		if(LoginPassword=="")
		{
			OverlayMessage("Login information missing.  Please complete all fields displayed.");
			return false;
		}
		var Pass=encodeURIComponent(LoginPassword);
		var WaitObj=OverlayWait();
		RSAEncryptText(Pass,function(encrypted){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			LoginPasswordInput.focus();
			if(encrypted==null)
			{
				OverlayMessage("Unable to encrypt account credentials before sending to server.  Please try again.",function(){
					CallDumpEncryptionKeys();
				});
			}
			var q="Command=DJ:LoginS&Pass="+encodeURIComponent(encrypted);
			var WaitObj=OverlayWait();
			RunAjax(q,function(){
				try{WaitObj.Close();}catch(err){OverlayWaitClose();};
				var narf=this.responseText;
				narf=narf.split("\r\n");
				var narf0=narf.shift();
				if(narf0=="Invalid")
				{
					OverlayMessage("The server reported that an invalid command was sent.");
					return;
				}
				if(narf0=="RSAError")
				{
					OverlayMessage("The server reported that it was unable to decrypt the authentication token.  Please try again.",CallDumpEncryptionKeys);
					return;
				}
				if(narf0=="MissingParams")
				{
					OverlayMessage("The server reported that the request is missing required parameters/fields.");
					return;
				}
				if(narf0=="Unauth")
				{
					OverlayMessage("Unable to login.  Invalid credentials.");
					return;
				}
				if(narf0!="Auth")
				{
					var error="";
					if(narf1!="")error=" {"+decodeURIComponent(narf1)+"}";
					var c=narf.length;
					for(var i=0;i<c-1;i++)
					{
						if(narf[i]=="")continue;
						error+=" {"+decodeURIComponent(narf[i])+"}";
					}
					OverlayMessage("The server responded with an unknown error reply."+error);
					return;
				}
				CheckStatus();
			});
		});
		return false;
	};
	LoginPasswordInput.focus();
}


function CheckStatus()
{
	ClearNodeChildren(document.body);
	var WaitObj=OverlayWait();
	RunAjax("Command=DJ:Login",function(){
		try{WaitObj.Close();}catch(err){OverlayWaitClose();};
		var narf=this.responseText;
		narf=narf.split("\r\n");
		var narf0=narf.shift();
		if(narf0=="Auth")
		{
			DisplayTopmost();return;
		}
		if(narf0=="Unauth")
		{
			DisplayLogin();return;
		}
		var error="";
		if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
		var c=narf.length;
		for(var i=0;i<c-1;i++)
		{
			if(narf[i]=="")continue;
			error+=" {"+decodeURIComponent(narf[i])+"}";
		}
		OverlayMessage("The server responded with an unknown error reply."+error);
		return;
	});
}

function randString()
{
	var text="";
	var possible="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	for(var i=0;i<20;i++)
	{
		text+=possible.charAt(Math.floor(Math.random()*possible.length));
	}
	return text;
}

function ProcessImage(imageDataURI,completionFunc)
{
	var ImageOrig=document.createElement("img");
	ImageOrig.completionFunc=completionFunc;
	ImageOrig.onload=function()
	{
		var Canvas=document.createElement("canvas");
		Canvas.width=80;
		Canvas.height=80;
		var Context=Canvas.getContext("2d");
		var width=this.width;
		var height=this.height;
		var completionFunc=this.completionFunc;
		if(width<=80 && height<=80)
		{
			if(completionFunc)
			{
				completionFunc(this.src);
			}
			return;
		}
		var SelectionLength=width;
		if(width>height)SelectionLength=height;
		var offsetX=0;
		var offsetY=0;
		if(width>SelectionLength)
		{
			offsetX=Math.floor((width-SelectionLength)/2);
		}
		else if(height>SelectionLength)
		{
			offsetY=Math.floor((height-SelectionLength)/2);
		}
		Context.drawImage(this,offsetX,offsetY,SelectionLength,SelectionLength,0,0,80,80);
		if(completionFunc)
		{
			completionFunc(Canvas.toDataURL("image/gif"));
		}
	};
	ImageOrig.onerror=function()
	{
		var completionFunc=this.completionFunc;
		if(completionFunc){completionFunc(null);}
	}
	ImageOrig.src=imageDataURI;
}

function ConvertImageToPNG(imageDataURI,completionFunc)
{
	var ImageOrig=new Image();
	ImageOrig.completionFunc=completionFunc;
	ImageOrig.onload=function()
	{
		var completionFunc=this.completionFunc;
		var width=this.width;
		var height=this.height;
		var Canvas=document.createElement("canvas");
		Canvas.width=width;
		Canvas.height=height;
		var Context=Canvas.getContext("2d");
		Context.drawImage(this,0,0,width,height);
		if(completionFunc)
		{
			completionFunc(Canvas.toDataURL("image/png",1));
		}
	};
	ImageOrig.onerror=function()
	{
		var completionFunc=this.completionFunc;
		if(completionFunc)
		{
			completionFunc(null);
		}
	};
	ImageOrig.src=imageDataURI;
}

function ReadFileInputFileReaderOnLoad()
{
	var onFileRead=this.ReadFileInputOnFileRead;
	onFileRead(this.result);
}
function ReadFileInput(FileInputElement,onFileRead)
{
	try
	{
		var reader=new FileReader();
		reader.ReadFileInputOnFileRead=onFileRead;
		reader.onload=ReadFileInputFileReaderOnLoad;
		reader.readAsDataURL(FileInputElement.files[0]);
	}
	catch(e)
	{
		onFileRead(null)
	}
}
var lasthash=null;
function nullHashChange()
{
	window.onhashchange=onHashChange;
}
function onHashChange()
{
	var location=window.location.hash;
	if(location=="#" || location=="")
	{
		if(lasthash!=null)
		{
			DisplayTopmost();
		}
		lasthash=null;
		return;
	}
	location=location.split("#");
	location.shift();
	location=location.join("");
	location=location.split("&");
	if(lasthash)
	{
		if(lasthash[lasthash.length-1]==location[location.length-1])
		{
			lasthash=location;
			return;
		}
	}
	lasthash=location;
	if(LastNavigatorObject!=null)
	{
		LastNavigatorObject.NavigateTo(location);
	}
}
function onBodyLoad()
{
	Ajax=getAjaxIFace();
	var LL=window.location;
	var host=LL.host;
	var prot=LL.protocol;
	var path=LL.pathname;
	var search=LL.search;
	var hash=LL.hash;
	if(hash!="" && hash!="#")
	{
		if(hash.indexOf("?")>-1)
		{
			var gg=hash.split("?");
			hash=gg.shift();
			gg=gg.join("?");
			search="?"+gg;
			cookieCreate("LastSearch",search,365);
			window.location.href=prot+"//"+host+path+search+hash;
			return;
		}
	}
	if(search!="" && search!="?")
	{
		window.location.href=prot+"//"+host+path+hash;
		cookieCreate("LastSearch",search,365);
		return;
	}
	LastSearch=cookieRead("LastSearch");
	cookieErase("LastSearch");
	window.onhashchange=onHashChange;
	var IP=cookieRead("IP");
	var Port=cookieRead("Port");
	var p=cookieRead("LastOpenedDirectory");
	var f=cookieRead("LastUsedFilter");
	var s=cookieRead("SeekToTime");
	if(IP=="" || IP==null){IP=WebJockeyIP;}else{WebJockeyIP=IP;}
	if(Port=="" || Port==null){Port=WebJockeyPort;}else{WebJockeyPort=Port;}
	if(p=="" || p==null){p=LastOpenedDirectory;}else{LastOpenedDirectory=p;}
	if(f=="" || f==null){f=LastUsedFilter;}else{LastUsedFilter=f;}
	if(s=="" || s==null){s=SeekToTime;}else{SeekToTime=s;}
	cookieCreate("IP",IP,365);
	cookieCreate("Port",Port,365);
	cookieCreate("LastOpenedDirectory",LastOpenedDirectory,365);
	cookieCreate("LastUsedFilter",LastUsedFilter,365);
	cookieCreate("SeekToTime",SeekToTime,365);

	
	CommonWebJockeyAIURL="IP="+WebJockeyIP+"&Port="+WebJockeyPort;
	if(Ajax!=null)
	{
		CheckStatus();
	}
}

function OverlayFileInfo(IDorFile)
{
	var Window=OverlayModalDialogWindow("File Information",function(DoApply){return false;})//Return function parameter false=canceled, return true to cancel close;
	Window.style.top="0px";
	Window.style.left="0px";
	var OverlayModalDialogWindowDiv=Window.OverlayModalDialogWindowDiv;
	OverlayModalDialogWindowDiv.style.overflow="auto";
	OverlayModalDialogWindowDiv.style.minWidth="100%";
	OverlayModalDialogWindowDiv.style.minHeight="1005";
	function OverlayFileInfoBuildInput(Parent,Caption,Type,InputType,ID,ReadOnly)
	{
		var label=document.createElement("label");
		label.id=ID+"Label";
		Parent.appendChild(label);
		var input=document.createElement(Type);
		input.style.width="300px";
		input.id=ID+"Input";
		if(InputType)
		{
			input.type=InputType;
		}
		if(ReadOnly)
		{
			input.setAttribute("readonly","");
		}
		input.onchange=function()
		{
			this.Changed=true;
		};
		input.Changed=false;
		label.appendChild(input);
		label.appendChild(document.createTextNode("\xA0"));
		label.appendChild(document.createTextNode(Caption));
		return input;
	}
	var FileInfoDiv=document.createElement("div");
	FileInfoDiv.appendChild(document.createTextNode(IDorFile));
	FileInfoDiv.style.display="inline-block";
	FileInfoDiv.style.borderTop="1px solid #F0F0F0";
	FileInfoDiv.style.borderLeft="1px solid #F0F0F0";
	FileInfoDiv.style.borderRight="1px solid #909090";
	FileInfoDiv.style.borderBottom="1px solid #909090";
	FileInfoDiv.style.fontWeight="bold";
	Window.appendChild(FileInfoDiv);
	var table=document.createElement("table");
	table.className="BPWJDJCPFileInfoTable";
	table.id="BPWJDJCPFileInfoTable";
	Window.appendChild(table);
	var tbody=document.createElement("tbody");
	table.appendChild(tbody);
	var tr=document.createElement("tr");
	tbody.appendChild(tr);
	var lhtd=document.createElement("td");
	tr.appendChild(lhtd);
	var rhtd=document.createElement("td");
	tr.appendChild(rhtd);
	tr=document.createElement("tr");
	tbody.appendChild(tr);
	var bttd=document.createElement("td");
	bttd.setAttribute("colspan","2");
	bttd.style.textAlign="right";
	tr.appendChild(bttd);
	var TitleInput=OverlayFileInfoBuildInput(lhtd,"Title","input","text","Title",false);
	lhtd.appendChild(document.createElement("br"));
	var ArtistInput=OverlayFileInfoBuildInput(lhtd,"Artist","input","text","Artist",false);
	lhtd.appendChild(document.createElement("br"));
	var AlbumInput=OverlayFileInfoBuildInput(lhtd,"Album","input","text","Album",false);
	lhtd.appendChild(document.createElement("br"));
	var YearInput=OverlayFileInfoBuildInput(lhtd,"Year","input","text","Year",false);
	lhtd.appendChild(document.createElement("br"));
	var GenreInput=OverlayFileInfoBuildInput(lhtd,"Genre","input","text","Genre",false);
	lhtd.appendChild(document.createElement("br"));
	var BPMInput=OverlayFileInfoBuildInput(lhtd,"B.P.M.","input","text","B.P.M.",false);
	lhtd.appendChild(document.createElement("br"));
	var LengthInput=OverlayFileInfoBuildInput(lhtd,"Length","input","text","Length",true);
	lhtd.appendChild(document.createElement("br"));
	var TypeInput=OverlayFileInfoBuildInput(lhtd,"Type","input","text","Type",true);
	lhtd.appendChild(document.createElement("br"));
	var TrackInput=OverlayFileInfoBuildInput(lhtd,"Track","input","text","Track",false);
	lhtd.appendChild(document.createElement("br"));
	var FamilyInput=OverlayFileInfoBuildInput(lhtd,"Family","input","text","Family",true);
	lhtd.appendChild(document.createElement("br"));
	var GainInput=OverlayFileInfoBuildInput(lhtd,"Gain","input","text","Gain",true);
	lhtd.appendChild(document.createElement("br"));
	var BitrateInput=OverlayFileInfoBuildInput(lhtd,"Bitrate","input","text","Bitrate",true);
	lhtd.appendChild(document.createElement("br"));
	var VBRInput=OverlayFileInfoBuildInput(lhtd,"VBR","input","text","VBR",true);
	lhtd.appendChild(document.createElement("br"));
	var StereoInput=OverlayFileInfoBuildInput(lhtd,"Stereo","input","text","Stereo",true);
	lhtd.appendChild(document.createElement("br"));
	var TrackGainInput=OverlayFileInfoBuildInput(lhtd,"Track ReplayGain","input","text","TrackGain",false);
	lhtd.appendChild(document.createElement("br"));
	var AlbumGainInput=OverlayFileInfoBuildInput(lhtd,"Album ReplayGain","input","text","AlbumGain",false);
	lhtd.appendChild(document.createElement("br"));
	var StreamTitleInput=OverlayFileInfoBuildInput(lhtd,"Stream Title","input","text","StreamTitle",true);
	lhtd.appendChild(document.createElement("br"));
	var StreamURLInput=OverlayFileInfoBuildInput(lhtd,"Stream URL","input","text","StreamURL",true);
	lhtd.appendChild(document.createElement("br"));
	var StreamNameInput=OverlayFileInfoBuildInput(lhtd,"Stream Name","input","text","StreamName",true);
	lhtd.appendChild(document.createElement("br"));
	var StreamTypeInput=OverlayFileInfoBuildInput(lhtd,"Stream Type","input","text","StreamType",true);
	lhtd.appendChild(document.createElement("br"));
	var CommentsInput=OverlayFileInfoBuildInput(lhtd,"Comments","textarea",null,"Comments",false);
	CommentsInput.style.width="306px";
	CommentsInput.style.height="110px";
	CommentsInput.setAttribute("wrap","off");
	var FormatLabel=document.createElement("label");
	rhtd.appendChild(FormatLabel);
	FormatLabel.appendChild(document.createTextNode("Format\xA0Information:"));
	FormatLabel.appendChild(document.createElement("br"));
	var FormatTextArea=document.createElement("textarea");
	FormatTextArea.setAttribute("rows","17");
	FormatTextArea.setAttribute("cols","50");
	FormatTextArea.setAttribute("wrap","off");
	FormatTextArea.setAttribute("readonly","");
	FormatLabel.appendChild(FormatTextArea);
	var OKButton=document.createElement("button");
	OKButton.type="button";
	OKButton.appendChild(document.createTextNode("OK"));
	OKButton.Window=Window;
	OKButton.onclick=function()
	{
		var Window=this.Window;
		Window.WindowCloseButton.onclick.call(Window.WindowCloseButton);
		return false;
	};
	bttd.appendChild(OKButton);
	var q;
	if(IDorFile && IDorFile!="")
	{
		q="Command=DJ:FileInfo&"+WebJockeyParameterize(encodeURIComponent(IDorFile));
	}
	else
	{
		q=CommonWebJockeyAIURL+"&Command=DJ:FileInfo";
	}
	var WaitObj=OverlayWait();
	RunAjax(q,function(){
		try{WaitObj.Close();}catch(err){OverlayWaitClose();}
		var narf=this.responseText;
		narf=narf.split("\r\n");
		var narf0=narf.shift();
		if(narf0=="FileInfoFormatError")
		{
			OverlayMessage("Command missing required parameter(s).");
			return;
		}
		if(narf0!="DJ:FileInfoListing")
		{
			var error="";
			if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
			var c=narf.length;
			for(var i=0;i<c-1;i++)
			{
				if(narf[i]=="")continue;
				error+=" {"+decodeURIComponent(narf[i])+"}";
			}
			OverlayMessage("The server responded with an unknown error reply."+error);
			return;
		}
		var IHS=new Object;
		var IHV=new Object;
		while(narf[0]!=undefined && narf[0]!="" && narf[0]!="DJ:FileInfoEndListing")
		{
			var Field=narf.shift();
			var Status=narf.shift();
			var Data=decodeURIComponent(narf.shift());
			var d="x"+Field;
			IHS[d]=Status;
			IHV[d]=Data;
		}
		function ufnE(obj,IHS,t)
		{
			if(obj==null || obj==undefined)return;
			if(IHS==null || IHS==undefined)
			{
				obj.disabled="disabled";
				obj.value="Unsupported";
				obj.className+="Disabled";
			}
			else if(IHS=="unsupported")
			{
				obj.disabled="disabled";
				obj.value="Unsupported";
				obj.className+="Disabled";
			}
			else if(IHS=="blank")
			{
				obj.value="";
			}
			else
			{
				obj.value=t;
			}
		}
		if(IHS["xfile"])
		{
			var t=IHV["xfile"];
			t=t.split(" ");
			t=t.join("\xA0");
			ClearNodeChildren(FileInfoDiv);
			FileInfoDiv.appendChild(document.createTextNode(t));
		}
		ufnE(TitleInput,IHS["xtitle"],IHV["xtitle"]);
		ufnE(ArtistInput,IHS["xartist"],IHV["xartist"]);
		ufnE(AlbumInput,IHS["xalbum"],IHV["xalbum"]);
		ufnE(YearInput,IHS["xyear"],IHV["xyear"]);
		ufnE(GenreInput,IHS["xgenre"],IHV["xgenre"]);
		ufnE(BPMInput,IHS["xbpm"],IHV["xbpm"]);
		ufnE(LengthInput,IHS["xlength"],formatTimeDisp(Math.round(IHV["xlength"]*1/1000)));
		ufnE(TypeInput,IHS["xtype"],IHV["xtype"]);
		ufnE(TrackInput,IHS["xtrack"],IHV["xtrack"]);
		ufnE(FamilyInput,IHS["xfamily"],IHV["xfamily"]);
		ufnE(GainInput,IHS["xgain"],IHV["xgain"]);
		ufnE(BitrateInput,IHS["xbitrate"],IHV["xbitrate"]);
		ufnE(VBRInput,IHS["xvbr"],IHV["xvbr"]);
		ufnE(StereoInput,IHS["xstereo"],IHV["xstereo"]);
		ufnE(TrackGainInput,IHS["xreplaygain_track_gain"],IHV["xreplaygain_track_gain"]);
		ufnE(AlbumGainInput,IHS["xreplaygain_album_gain"],IHV["xreplaygain_album_gain"]);
		ufnE(StreamTitleInput,IHS["xstreamtitle"],IHV["xstreamtitle"]);
		ufnE(StreamURLInput,IHS["xstreamurl"],IHV["xstreamurl"]);
		ufnE(StreamNameInput,IHS["xstreamname"],IHV["xstreamname"]);
		ufnE(StreamTypeInput,IHS["xstreamtype"],IHV["xstreamtype"]);
		ufnE(CommentsInput,IHS["xcomment"],IHV["xcomment"]);
		ufnE(FormatTextArea,IHS["xformatinformation"],IHV["xformatinformation"]);
	});
}

var OverlayTextAreaWindowDiv=null;
function OverlayTextAreaWindow(Title,Text,ReturnFunc)//callback function with single parameter of text area contents or [false] if aborted.
{
	if(!ReturnFunc)return;
	if(OverlayTextAreaWindowDiv)
	{
		if(OverlayTextAreaWindowDiv.ReturnFunc)
		{
			OverlayTextAreaWindowDiv.ReturnFunc.call(OverlayTextAreaWindowDiv,false);
		}
		ClearNodeChildren(OverlayTextAreaWindowDiv);
		if(OverlayTextAreaWindowDiv.parentNode)
		{
			OverlayTextAreaWindowDiv.parentNode.removeChild(OverlayTextAreaWindowDiv);
		}
		delete OverlayTextAreaWindowDiv;
		OverlayTextAreaWindowDiv=null;
	}
	OverlayTextAreaWindowDiv=document.createElement("div");
	OverlayTextAreaWindowDiv.tabIndex=0;
	OverlayTextAreaWindowDiv.id="OverlayTextAreaWindowDiv";
	OverlayTextAreaWindowDiv.className="OverlayTextAreaWindowDiv";
	OverlayTextAreaWindowDiv.ReturnFunc=ReturnFunc;
	if(!Title || Title=="")Title="Text Entry";
	var TextAreaWindow=CreateWindow(Title,function(){
		if(OverlayTextAreaWindowDiv.ReturnFunc)
		{
			OverlayTextAreaWindowDiv.ReturnFunc.call(OverlayTextAreaWindowDiv,false);
		}
		ClearNodeChildren(OverlayTextAreaWindowDiv);
		if(OverlayTextAreaWindowDiv.parentNode)
		{
			OverlayTextAreaWindowDiv.parentNode.removeChild(OverlayTextAreaWindowDiv);
		}
		delete OverlayTextAreaWindowDiv;
		OverlayTextAreaWindowDiv=null;
	});
	var WindowTitleBar=TextAreaWindow.WindowTitleBar;
	TextAreaWindow.style.textAlign="left";
	TextAreaWindow.OverlayTextAreaWindowDiv=OverlayTextAreaWindowDiv;
	TextAreaWindow.WindowTitleBar.removeChild(TextAreaWindow.WindowStickyButton);
	TextAreaWindow.CurText=Text;
	TextAreaWindow.Callback=ReturnFunc;
	var Form=document.createElement("form");
	Form.target="_blank";
	Form.action="";
	Form.method="POST";
	Form.onsubmit=function(){return false;};
	TextAreaWindow.Form=Form;
	TextAreaWindow.appendChild(Form);
	Form.TextAreaWindow=TextAreaWindow;
	var TextArea=document.createElement("textarea");
	TextArea.Form=Form;
	Form.TextArea=TextArea;
	TextArea.value=Text;
	Form.appendChild(TextArea);
	TextAreaWindow.TextArea=TextArea;
	TextArea.style.width="20em";
	TextArea.style.height="20em";
	TextArea.style.whiteSpace="pre";
	TextArea.style.overflow="auto";
	TextArea.onkeydown=function(e)
	{
		if(e.keyCode==9 || e.which==9)
		{
			e.preventDefault();
			var s = this.selectionStart;
			this.value = this.value.substring(0,this.selectionStart) + "\t" + this.value.substring(this.selectionEnd);
			this.selectionEnd = s+1;
		}
	};
	var DialogButtonsDiv=document.createElement("div");
	DialogButtonsDiv.style.width="100%";
	DialogButtonsDiv.style.textAlign="right";
	Form.appendChild(DialogButtonsDiv);
	var CancelButton=document.createElement("input");
	CancelButton.type="button";
	CancelButton.value="Cancel";
	CancelButton.TextAreaWindow=TextAreaWindow;
	DialogButtonsDiv.appendChild(CancelButton);
	CancelButton.onclick=function()
	{
		var TextAreaWindow=this.TextAreaWindow;
		TextAreaWindow.WindowCloseButton.onclick.call(TextAreaWindow.WindowCloseButton);
	};
	var OKButton=document.createElement("input");
	OKButton.type="submit";
	OKButton.value="OK";
	OKButton.TextAreaWindow=TextAreaWindow;
	TextAreaWindow.OKButton=OKButton;
	DialogButtonsDiv.appendChild(OKButton);
	OverlayTextAreaWindowDiv.appendChild(TextAreaWindow);
	document.body.insertBefore(OverlayTextAreaWindowDiv,null);
	Form.onsubmit=function()
	{
		var TextAreaWindow=this.TextAreaWindow;
		var OverlayTextAreaWindowDiv=TextAreaWindow.OverlayTextAreaWindowDiv;
		var ReturnFunc=OverlayTextAreaWindowDiv.ReturnFunc;
		var Text=TextAreaWindow.TextArea.value;
		ClearNodeChildren(OverlayTextAreaWindowDiv);
		if(OverlayTextAreaWindowDiv.parentNode)
		{
			OverlayTextAreaWindowDiv.parentNode.removeChild(OverlayTextAreaWindowDiv);
		}
		ReturnFunc.call(OverlayTextAreaWindowDiv,Text);
		delete OverlayTextAreaWindowDiv;
		OverlayTextAreaWindowDiv=null;
		return false;
	};
}

if (!document.getScroll) {
	document.getScroll = function() {
		if (window.pageYOffset != undefined) {
			return [pageXOffset, pageYOffset];
		} else {
			var sx, sy, d = document,
				r = d.documentElement,
				b = d.body;
			sx = r.scrollLeft || b.scrollLeft || 0;
			sy = r.scrollTop || b.scrollTop || 0;
			return [sx, sy];
		}
	}
}

function addXMLRequestCallback(callback){
    var oldSend, i;
    if( XMLHttpRequest.callbacks ) {
        // we've already overridden send() so just add the callback
        XMLHttpRequest.callbacks.push( callback );
    } else {
        // create a callback queue
        XMLHttpRequest.callbacks = [callback];
        // store the native send()
        oldSend = XMLHttpRequest.prototype.send;
        // override the native send()
        XMLHttpRequest.prototype.send = function(){
            // process the callback queue
            // the xhr instance is passed into each callback but seems pretty useless
            // you can't tell what its destination is or call abort() without an error
            // so only really good for logging that a request has happened
            // I could be wrong, I hope so...
            // EDIT: I suppose you could override the onreadystatechange handler though
            for( i = 0; i < XMLHttpRequest.callbacks.length; i++ ) {
                XMLHttpRequest.callbacks[i]( this , arguments );
            }
            // call the native send()
            oldSend.apply(this, arguments);
        }
    }
}
addXMLRequestCallback( function( xhr , arguments ) {
	/*if(StarWebPrintDevice!="")
	{
		if(arguments.length>0)
		{
			if(typeof(arguments[0])==='string')
			{
				if(arguments[0].indexOf("<StarWebPrint")==0)
				{
					xhr.setRequestHeader('X-StarWebPRNT-Device',encodeURIComponent(StarWebPrintDevice));
				}
			}
		}
	}*/
});
var EvalTXT=null;
function DisplayJavaScriptDebugWindow()
{
	var JavaScriptDebugWindow=CreateWindow("eval(txt)",function(){});
	var JTextAreaLabel=document.createElement("label");
	JavaScriptDebugWindow.appendChild(JTextAreaLabel);
	var JTextArea=document.createElement("textarea");
	JTextArea.style.width="20em";
	JTextArea.style.height="20em";
	JTextArea.style.whiteSpace="pre";
	JTextArea.style.overflow="auto";
	JTextArea.setAttribute("spellcheck","false");
	JTextArea.onkeydown=function(event)
	{
		if(event.keyCode===9)
		{
			var v=this.value,s=this.selectionStart,e=this.selectionEnd;
			this.value=v.substring(0, s)+'\t'+v.substring(e);
			this.selectionStart=this.selectionEnd=s+1;
			return false;
		};
	}
	JTextArea.appendChild(document.createTextNode("https://www.w3schools.com/html/html5_webworkers.asp"));
	JTextArea.id="JTextArea";
	if(EvalTXT!=null)
	{
		JTextArea.value=EvalTXT;
	}
	JTextAreaLabel.appendChild(JTextArea);
	JTextAreaLabel.appendChild(document.createElement("br"));
	var JTextAreaButton=document.createElement("button");
	JTextAreaButton.appendChild(document.createTextNode("Run"));
	JTextAreaLabel.appendChild(JTextAreaButton);
	var JTextAreaOutDiv=document.createElement("div");
	JTextAreaOutDiv.id="JTextAreaOutDiv";
	JTextAreaButton.onclick=function()
	{
		var JText=JTextArea.value;
		try{
			EvalTXT=JText;
			eval(JText);
		}
		catch(e)
		{
			OverlayMessage(e.message);
		}
	};
	document.body.insertBefore(JavaScriptDebugWindow,document.body.firstChild);
}
var ManualCSSLink=null;
function DisplayManualCSSWindow()
{
	var ManualCSSWindow=CreateWindow("Manual CSS",function(){});
	var CSSTextArea=document.createElement("textarea");
	CSSTextArea.style.width="20em";
	CSSTextArea.style.height="20em";
	CSSTextArea.style.whiteSpace="pre";
	CSSTextArea.style.overflow="auto";
	CSSTextArea.onkeydown=function(e)
	{
		if(e.keyCode==9 || e.which==9)
		{
			e.preventDefault();
			var s = this.selectionStart;
			this.value = this.value.substring(0,this.selectionStart) + "\t" + this.value.substring(this.selectionEnd);
			this.selectionEnd = s+1;
		}
	};
	var src="";
	if(ManualCSSLink!=null)
	{
		src=ManualCSSLink.href;
	}
	ManualCSSWindow.appendChild(CSSTextArea);
	ManualCSSWindow.appendChild(document.createElement("br"));
	if(src!="")
	{
		src=src.split("base64,");
		src.shift();
		src=src.join("");
		src=atob(src);
		CSSTextArea.value=src;
	}
	var ManualCSSApplyButton=document.createElement("button");
	ManualCSSApplyButton.appendChild(document.createTextNode("Apply"));
	ManualCSSWindow.appendChild(ManualCSSApplyButton);
	document.body.insertBefore(ManualCSSWindow,document.body.firstChild);
	ManualCSSApplyButton.CSSTextArea=CSSTextArea;
	ManualCSSApplyButton.onclick=function()
	{
		if(ManualCSSLink==null)
		{
			var head=document.querySelector('head');
			ManualCSSLink=document.createElement("link");
			ManualCSSLink.setAttribute("rel","stylesheet");
			ManualCSSLink.setAttribute("type","text/css");
			head.appendChild(ManualCSSLink);
		}
		CSSTextArea=this.CSSTextArea;
		var src="data:text/css;base64,"+btoa(CSSTextArea.value);
		ManualCSSLink.href=src;
		var allIFrames=document.getElementsByTagName("iframe");
		var c=allIFrames.length;
		for(var i=0;i<c;i++)
		{
			var IFrame=allIFrames[i];
			var head=IFrame.contentWindow.document.head;
			var IFrameDocument=IFrame.contentWindow.document;
			var link=IFrameDocument.getElementById("ManualCSS");
			if(link==null)
			{
				link=IFrameDocument.createElement("link");
				link.id="ManualCSS";
				head.appendChild(link);
				link.setAttribute("rel","stylesheet");
				link.setAttribute("type","text/css");
			}
			link.href=src;
		}
	};
}

var OverlayModalDialogWindowDiv=null;
function OverlayModalDialogWindow(Caption,ReturnFunc)//Return function parameter false=canceled, return true to cancel close;
{
	if(!ReturnFunc)return null;
	if(OverlayModalDialogWindowDiv)
	{
		if(OverlayModalDialogWindowDiv.ReturnFunc)
		{
			OverlayModalDialogWindowDiv.ReturnFunc.call(OverlayModalDialogWindowDiv,false);
		}
		ClearNodeChildren(OverlayModalDialogWindowDiv);
		if(OverlayModalDialogWindowDiv.parentNode)
		{
			OverlayModalDialogWindowDiv.parentNode.removeChild(OverlayModalDialogWindowDiv);
		}
		delete OverlayModalDialogWindowDiv;
		OverlayModalDialogWindowDiv=null;
	}
	OverlayModalDialogWindowDiv=document.createElement("div");
	OverlayModalDialogWindowDiv.tabIndex=0;
	OverlayModalDialogWindowDiv.id="OverlayModalDialogWindowDiv";
	OverlayModalDialogWindowDiv.className="OverlayModalDialogWindowDiv";
	OverlayModalDialogWindowDiv.ReturnFunc=ReturnFunc;
	var ModalDialogWindow=CreateWindow(Caption,function(){
		var temp=this.OverlayModalDialogWindowDiv;
		var ReturnFunc=temp.ReturnFunc;
		if(ReturnFunc.call(this,false)){return true;}
		ClearNodeChildren(temp);
		if(temp.parentNode)
		{
			temp.parentNode.removeChild(temp);
		}
		if(temp==OverlayModalDialogWindowDiv)
		{
			delete temp;
			temp=null;
			OverlayModalDialogWindowDiv=null;
		}
	});
	ModalDialogWindow.OverlayModalDialogWindowDiv=OverlayModalDialogWindowDiv;
	var WindowTitleBar=ModalDialogWindow.WindowTitleBar;
	ModalDialogWindow.style.textAlign="left";
	ModalDialogWindow.OverlayModalDialogWindowDiv=OverlayModalDialogWindowDiv;
	ModalDialogWindow.WindowTitleBar.removeChild(ModalDialogWindow.WindowStickyButton);
	OverlayModalDialogWindowDiv.appendChild(ModalDialogWindow);
	document.body.insertBefore(OverlayModalDialogWindowDiv,null);
	ModalDialogWindow.focus();
	return ModalDialogWindow;
}

var OverlayBrowseForServerFolderDiv=null;
function OverlayBrowseForServerFolder(StartPath,ReturnFunc)//callback function with single parameter to put into input box or [false] if aborted.
{
	if(!ReturnFunc)return;
	if(OverlayBrowseForServerFolderDiv)
	{
		if(OverlayBrowseForServerFolderDiv.ReturnFunc)
		{
			OverlayBrowseForServerFolderDiv.ReturnFunc.call(OverlayBrowseForServerFolderDiv,false);
		}
		ClearNodeChildren(OverlayBrowseForServerFolderDiv);
		if(OverlayBrowseForServerFolderDiv.parentNode)
		{
			OverlayBrowseForServerFolderDiv.parentNode.removeChild(OverlayBrowseForServerFolderDiv);
		}
		delete OverlayBrowseForServerFolderDiv;
		OverlayBrowseForServerFolderDiv=null;
	}
	OverlayBrowseForServerFolderDiv=document.createElement("div");
	OverlayBrowseForServerFolderDiv.tabIndex=0;
	OverlayBrowseForServerFolderDiv.id="OverlayBrowseForServerFolderDiv";
	OverlayBrowseForServerFolderDiv.className="OverlayBrowseForServerFolderDiv";
	OverlayBrowseForServerFolderDiv.ReturnFunc=ReturnFunc;
	var BrowseFolderWindow=CreateWindow("Browse for folder...",function(){
		if(OverlayBrowseForServerFolderDiv.ReturnFunc)
		{
			OverlayBrowseForServerFolderDiv.ReturnFunc.call(OverlayBrowseForServerFolderDiv,false);
		}
		ClearNodeChildren(OverlayBrowseForServerFolderDiv);
		if(OverlayBrowseForServerFolderDiv.parentNode)
		{
			OverlayBrowseForServerFolderDiv.parentNode.removeChild(OverlayBrowseForServerFolderDiv);
		}
		delete OverlayBrowseForServerFolderDiv;
		OverlayBrowseForServerFolderDiv=null;
	});
	var WindowTitleBar=BrowseFolderWindow.WindowTitleBar;
	BrowseFolderWindow.WindowIcon.src=FolderSrc;
	BrowseFolderWindow.style.textAlign="left";
	BrowseFolderWindow.OverlayBrowseForServerFolderDiv=OverlayBrowseForServerFolderDiv;
	BrowseFolderWindow.WindowTitleBar.removeChild(BrowseFolderWindow.WindowStickyButton);
	BrowseFolderWindow.CurPath=StartPath;
	BrowseFolderWindow.Callback=ReturnFunc;
	var Form=document.createElement("form");
	Form.target="_blank";
	Form.action="";
	Form.method="POST";
	Form.onsubmit=function(){return false;};
	BrowseFolderWindow.Form=Form;
	BrowseFolderWindow.appendChild(Form);
	Form.BrowseFolderWindow=BrowseFolderWindow;
	var PathDiv=document.createElement("div");
	BrowseFolderWindow.PathDiv=PathDiv;
	PathDiv.className="BrowseFolderWindowPathDiv";
	Form.appendChild(PathDiv);
	Form.appendChild(document.createElement("br"));
	var ItemsDiv=document.createElement("div");
	BrowseFolderWindow.ItemsDiv=ItemsDiv;
	ItemsDiv.className="BrowseFolderWindowItemsDiv";
	Form.appendChild(ItemsDiv);
	function BrowseFolderWindowRefreshItemsDisplay(BrowseFolderWindow)
	{
		var CurPath=BrowseFolderWindow.CurPath;
		var q=CommonWebJockeyAIURL+"&Command=FolderBrowse&Path="+encodeURIComponent(CurPath);
		var WaitObj=OverlayWait();
		RunAjax(q,function(){
			try{WaitObj.Close();}catch(err){OverlayWaitClose();}
			var narf=this.responseText;
			narf=narf.split("\r\n");
			var narf0=narf.shift();
			if(narf0!="FolderBrowseReply")
			{
				var error="";
				if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			var narf1=narf.shift();
			if(narf1=="Invalid")
			{
				OverlayMessage("The server reported that an invalid command was sent.");
				return;
			}
			if(narf1=="UnAuth")
			{
				OverlayMessage("You are not authorized to perform that activity.",function(){BrowseFolderWindow.WindowCloseButton.onclick.call(BrowseFolderWindow.WindowCloseButton);});
				return;
			}
			if(narf1=="NotFound")
			{
				OverlayMessage("Not found.",function(){
					if(BrowseFolderWindow.PathDiv.childElementCount<1)
					{
						BrowseFolderWindow.CurPath="../";
						BrowseFolderWindowRefreshItemsDisplay(BrowseFolderWindow);
					}
				});
				return;
			}
			if(narf1=="Protected")
			{
				OverlayMessage("To protect the integrity of the server, browsing the install path is prohibited.",function(){
					if(BrowseFolderWindow.PathDiv.childElementCount<1)
					{
						BrowseFolderWindow.CurPath="../";
						BrowseFolderWindowRefreshItemsDisplay(BrowseFolderWindow);
					}
				});
				return;
			}
			if(narf1!="Success")
			{
				var error="";
				if(narf1!="")error=" {"+decodeURIComponent(narf1)+"}";
				var c=narf.length;
				for(var i=0;i<c-1;i++)
				{
					if(narf[i]=="")continue;
					error+=" {"+decodeURIComponent(narf[i])+"}";
				}
				OverlayMessage("The server responded with an unknown error reply."+error);
				return;
			}
			var PathHash=narf.shift();
			PathHash=encoded_hash_map(PathHash);
			var Path=decodeURIComponent(PathHash['Path']);
			BrowseFolderWindow.CurPath=Path;
			BrowseFolderWindowUpdatePath(BrowseFolderWindow);
			ClearNodeChildren(ItemsDiv);
			var c=parseInt(narf.shift());
			for(var i=0;i<c;i++)
			{
				var Item=narf.shift();
				Item=encoded_hash_map(Item);
				var IsFolder=Item['Type']=="Folder";
				var Name=Item['Name'];
				Name=decodeURIComponent(Name);
				var ItemButton=document.createElement("button");
				ItemButton.type="button";
				ItemButton.Path=Path;
				ItemButton.Name=Name;
				ItemButton.BrowseFolderWindow=BrowseFolderWindow;
				ItemButton.IsFolder=IsFolder;
				ItemButton.onclick=BrowseFolderWindowItemButtonClick;
				if(IsFolder)
				{
					var img=document.createElement("img");
					img.style.width="1em";
					img.style.height="1em";
					img.src=FolderSrc;
					ItemButton.appendChild(img);
					ItemButton.appendChild(document.createTextNode("Browse"));
				}
				else
				{
					var img=document.createElement("img");
					img.style.width="1em";
					img.style.height="1em";
					img.src=FileSrc;
					ItemButton.appendChild(img);
					ItemButton.appendChild(document.createTextNode("Select"));
				}
				ItemsDiv.appendChild(ItemButton);
				ItemsDiv.appendChild(document.createTextNode(Name));
				ItemsDiv.appendChild(document.createElement("br"));
			}
			ItemsDiv.scrollLeft=0;
			ItemsDiv.scrollTop=0;
		});
	}
	function BrowseFolderWindowItemButtonClick()
	{
		var BrowseFolderWindow=this.BrowseFolderWindow;
		var Path=this.Path;
		var Name=this.Name;
		var IsFolder=this.IsFolder;
		if(IsFolder)
		{
			BrowseFolderWindow.CurPath=Path+"/"+Name;
			BrowseFolderWindowRefreshItemsDisplay(BrowseFolderWindow);
		}
		else
		{
			BrowseFolderWindow.CurPath=Path+"/"+Name;
			BrowseFolderWindowRefreshItemsDisplay(BrowseFolderWindow);
		}
	}
	function BrowseFolderWindowPathButtonClick()
	{
		this.BrowseFolderWindow.CurPath=this.Path;
		BrowseFolderWindowRefreshItemsDisplay(this.BrowseFolderWindow);
	}
	function BrowseFolderWindowUpdatePath(BrowseFolderWindow)
	{
		var CurPath=BrowseFolderWindow.CurPath;
		var PathDiv=BrowseFolderWindow.PathDiv;
		ClearNodeChildren(PathDiv);
		CurPath=CurPath.split("/");
		var c=CurPath.length;
		if(c==2 && CurPath[1]=="")
		{
			CurPath.pop();
			if(CurPath[0]=="")
			{
				CurPath[0]="/";
			}
			c=1;
		}
		var Path="";
		for(var i=0;i<c;i++)
		{
			var pp=CurPath[i];
			if(Path!=""){Path+="/";}
			Path+=pp;
			var PathButton=document.createElement("button");
			PathButton.type="button";
			PathButton.appendChild(document.createTextNode(pp));
			PathButton.Path=Path;
			PathButton.BrowseFolderWindow=BrowseFolderWindow;
			PathButton.onclick=BrowseFolderWindowPathButtonClick;
			PathDiv.appendChild(PathButton);
		}
		PathDiv.scrollLeft=PathDiv.scrollWidth;
	}
	var DialogButtonsDiv=document.createElement("div");
	DialogButtonsDiv.style.width="100%";
	DialogButtonsDiv.style.textAlign="right";
	DialogButtonsDiv.style.marginTop="2px";
	Form.appendChild(DialogButtonsDiv);
	var CreateFolderButton=document.createElement("input");
	CreateFolderButton.type="button";
	CreateFolderButton.value="New Folder";
	CreateFolderButton.BrowseFolderWindow=BrowseFolderWindow;
	BrowseFolderWindow.CreateFolderButton=CreateFolderButton;
	DialogButtonsDiv.appendChild(CreateFolderButton);
	var CancelButton=document.createElement("input");
	CancelButton.type="button";
	CancelButton.value="Cancel";
	CancelButton.BrowseFolderWindow=BrowseFolderWindow;
	BrowseFolderWindow.CancelButton=CancelButton;
	DialogButtonsDiv.appendChild(CancelButton);
	CancelButton.onclick=function()
	{
		var BrowseFolderWindow=this.BrowseFolderWindow;
		BrowseFolderWindow.WindowCloseButton.onclick.call(BrowseFolderWindow.WindowCloseButton);
	};
	var OKButton=document.createElement("input");
	OKButton.type="submit";
	OKButton.value="OK";
	OKButton.BrowseFolderWindow=BrowseFolderWindow;
	BrowseFolderWindow.OKButton=OKButton;
	DialogButtonsDiv.appendChild(OKButton);
	OverlayBrowseForServerFolderDiv.appendChild(BrowseFolderWindow);
	document.body.insertBefore(OverlayBrowseForServerFolderDiv,null);
	CreateFolderButton.onclick=function()
	{
		var CreateFolderButton=this;
		var BrowseFolderWindow=this.BrowseFolderWindow;
		var OKButton=BrowseFolderWindow.OKButton;
		var CancelButton=BrowseFolderWindow.CancelButton;
		var PathDiv=BrowseFolderWindow.PathDiv;
		var ItemsDiv=BrowseFolderWindow.ItemsDiv;
		OKButton.style.visibility="hidden";
		CancelButton.style.visibility="hidden";
		CreateFolderButton.style.visibility="hidden";
		ItemsDiv.style.visibility="hidden";
		ClearNodeChildren(PathDiv);
		var NewPathInput=document.createElement("input");
		var NewPathOKButton=document.createElement("input");
		NewPathOKButton.type="button";
		NewPathOKButton.value="Create";
		var NewPathCancelButton=document.createElement("input");
		NewPathCancelButton.type="button";
		NewPathCancelButton.value="Cancel";
		PathDiv.appendChild(NewPathInput);
		PathDiv.appendChild(NewPathOKButton);
		PathDiv.appendChild(NewPathCancelButton);
		NewPathCancelButton.onclick=function()
		{
			OKButton.style.visibility="";
			CancelButton.style.visibility="";
			CreateFolderButton.style.visibility="";
			ItemsDiv.style.visibility="";
			ClearNodeChildren(PathDiv);
			BrowseFolderWindowUpdatePath(BrowseFolderWindow);
		};
		NewPathOKButton.onclick=function()
		{
			if(NewPathInput.value=="")
			{
				OverlayMessage("The new folder name cannot be blank.");
				return;
			}
			var q=CommonWebJockeyAIURL+"&Command=FolderCreate&Path="+encodeURIComponent(BrowseFolderWindow.CurPath)+"&NewFolderName="+encodeURIComponent(NewPathInput.value);
			var WaitObj=OverlayWait();
			RunAjax(q,function(){
				try{WaitObj.Close();}catch(err){OverlayWaitClose();}
				var narf=this.responseText;
				narf=narf.split("\r\n");
				var narf0=narf.shift();
				if(narf0!="FolderCreateReply")
				{
					var error="";
					if(narf0!="")error=" {"+decodeURIComponent(narf0)+"}";
					var c=narf.length;
					for(var i=0;i<c-1;i++)
					{
						if(narf[i]=="")continue;
						error+=" {"+decodeURIComponent(narf[i])+"}";
					}
					OverlayMessage("The server responded with an unknown error reply."+error);
					return;
				}
				var narf1=narf.shift();
				if(narf1=="Invalid")
				{
					OverlayMessage("The server reported that an invalid command was sent.");
					return;
				}
				if(narf1=="UnAuth")
				{
					OverlayMessage("You are not authorized to perform that activity.",function(){BrowseFolderWindow.WindowCloseButton.onclick.call(BrowseFolderWindow.WindowCloseButton);});
					return;
				}
				if(narf1=="NotFound")
				{
					OverlayMessage("Not found.");
					return;
				}
				if(narf1=="Protected")
				{
					OverlayMessage("To protect the integrity of the server, modifying the install path is prohibited.",function(){
					});
					return;
				}
				if(narf1=="AlreadyExists")
				{
					OverlayMessage("Filesystem element by that name already exists.");
					return;
				}
				if(narf1=="Failed")
				{
					OverlayMessage("The server reported that it was unable to create the new folder.");
					return;
				}
				if(narf1!="Success")
				{
					var error="";
					if(narf1!="")error=" {"+decodeURIComponent(narf1)+"}";
					var c=narf.length;
					for(var i=0;i<c-1;i++)
					{
						if(narf[i]=="")continue;
						error+=" {"+decodeURIComponent(narf[i])+"}";
					}
					OverlayMessage("The server responded with an unknown error reply."+error);
					return;
				}
				NewPathCancelButton.onclick.call(NewPathCancelButton);
				BrowseFolderWindow.CurPath+="/"+NewPathInput.value;
				BrowseFolderWindowRefreshItemsDisplay(BrowseFolderWindow);
			});
		};
	};
	Form.onsubmit=function()
	{
		var BrowseFolderWindow=this.BrowseFolderWindow;
		var OverlayBrowseForServerFolderDiv=BrowseFolderWindow.OverlayBrowseForServerFolderDiv;
		var ReturnFunc=OverlayBrowseForServerFolderDiv.ReturnFunc;
		var CurPath=BrowseFolderWindow.CurPath;
		ClearNodeChildren(OverlayBrowseForServerFolderDiv);
		if(OverlayBrowseForServerFolderDiv.parentNode)
		{
			OverlayBrowseForServerFolderDiv.parentNode.removeChild(OverlayBrowseForServerFolderDiv);
		}
		OverlayBrowseForServerFolderDiv=null;
		ReturnFunc.call(OverlayBrowseForServerFolderDiv,CurPath);
		delete OverlayBrowseForServerFolderDiv;
		return false;
	};
	BrowseFolderWindowRefreshItemsDisplay(BrowseFolderWindow);
}

function DisplayIFrameSrc(Title,IRI,Width,Height)
{
	var Window=CreateWindow(Title,function(){});
	var IFrame=document.createElement("iframe");
	IFrame.style.width=Width;
	IFrame.style.height=Height;
	Window.appendChild(IFrame);
	IFrame.src=IRI;
	document.body.appendChild(Window);
}

function getInputSelection(el) {
    var start = 0, end = 0, normalizedValue, range,
        textInputRange, len, endRange;

    if (typeof el.selectionStart == "number" && typeof el.selectionEnd == "number") {
        start = el.selectionStart;
        end = el.selectionEnd;
    } else {
        range = document.selection.createRange();

        if (range && range.parentElement() == el) {
            len = el.value.length;
            normalizedValue = el.value.replace(/\r\n/g, "\n");

            // Create a working TextRange that lives only in the input
            textInputRange = el.createTextRange();
            textInputRange.moveToBookmark(range.getBookmark());

            // Check if the start and end of the selection are at the very end
            // of the input, since moveStart/moveEnd doesn't return what we want
            // in those cases
            endRange = el.createTextRange();
            endRange.collapse(false);

            if (textInputRange.compareEndPoints("StartToEnd", endRange) > -1) {
                start = end = len;
            } else {
                start = -textInputRange.moveStart("character", -len);
                start += normalizedValue.slice(0, start).split("\n").length - 1;

                if (textInputRange.compareEndPoints("EndToEnd", endRange) > -1) {
                    end = len;
                } else {
                    end = -textInputRange.moveEnd("character", -len);
                    end += normalizedValue.slice(0, end).split("\n").length - 1;
                }
            }
        }
    }

    return {
        start: start,
        end: end
    };
}

function getInputSelectionText(el){
	res=getInputSelection(el);
	return el.value.slice(res.start,res.end);
}

function replaceSelectedText(el, text) {
    var sel = getInputSelection(el), val = el.value;
    el.value = val.slice(0, sel.start) + text + val.slice(sel.end);
}

function ImageExists(URL)
{
	var img=new Image();
	img.src=URL;
	return (img.height!=0 && img.width!=0);
}

function ProcessPath(p)
{
	p=p.split("\\");
	for(var i=0;i<p.length;i++)
	{
		if(p[i]=="" || p[i]==".")
		{
			p.splice(i,1);
			i--;
		}
		if(p[i]=="..")
		{
			p.splice(i,1);
			p.splice(i-1,1);
			i-=2;
		}
	}
	p=p.join("\\");
	return p;
}

window.onload=onBodyLoad;
