	Nullsoft Embedded Window Example (06/09/2022)

v1.2 of this plugin has been compiled with MSVC 2010 Express
	Original by Daren Owen (aka: DrO)
	Updated by Leonard W. Bogard (aka: thinktink)


v1.1 of this plugin has been built against the 5.55 SDK.
For the plugin to be built correctly it assumes the source
and SDK files are setup in the following locations:

<gen_embedwnd>
<Agave>\<Language>
<sdk>\<winamp>
<Wasabi>

The source has been annotated where possible but if there
are any issues or items requiring better clarificiation
then please post in the associated Winamp forum thread.

