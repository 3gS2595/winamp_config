#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDD_CHILD                               102
#define IDC_ASTATICTEXT                         1000
#define IDC_ABUTTON                             1001
#define IDC_ANEDITBOX                           1002
#define IDC_ACOMBOBOX                           1003
#define IDC_ALISTVIEW                           1004
#define IDS_NULLSOFT_LANG_EXAMPLE               40000
#define IDS_DO_YOU_ALSO_WANT_TO_REMOVE_SETTINGS 40001
#define IDS_EMBED_WND_TITLE                     40002
#define IDS_EXAMPLE_MENU_STRING                 40003
#define IDS_ABOUT_STRING                        40004
