#include <windows.h>
#include <stdlib.h>
#include "resource.h"

#include "gen.h"
#include "wa_ipc.h"
#include "gen_mbapi.h"

#include "configproc.h"

BOOL CALLBACK ConfigProc(HWND hwndDlg,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	static char szUrl[4096];
	static char szCodePage[8];
	switch (uMsg)
	{
		case WM_INITDIALOG:
		{
	       SetWindowText(hwndDlg,cszDescription);

			if (mbapi.mbStatus != MBS_READY)
			{

				DoCheckIES();

				switch (mbapi.mbStatus)
				{
					case MBS_NOTINITED:
						if (MessageBox(hwndDlg, "The minibrowser has not been opened yet. \nDo you want to open?", cszDescription, MB_YESNO | MB_ICONEXCLAMATION) == IDYES)
							SendMessage(plugin.hwndParent, WM_COMMAND, ID_MENU_NOWPLAYING, 0);
						break;
					case MBS_OPENING:
						if (MessageBox(hwndDlg, "Please wait until the minibrowser opens and try again.", cszDescription, MB_RETRYCANCEL) == IDRETRY)
						{
							SendMessage(plugin.hwndParent, WM_COMMAND, ID_MENU_NOWPLAYING, 0);
							DoCheckIES();
						}
						break;
					default:;
				}

				if (mbapi.mbStatus != MBS_READY)
				{
					MessageBox(hwndDlg, "Please wait until the minibrower opens and try opening this config window again.", cszDescription, MB_OK);
					EndDialog(hwndDlg,0);
					return FALSE;
				}
			}
			
			OnIpcGetMbUrl(szUrl);
			SetWindowText(GetDlgItem(hwndDlg, IDC_URL), szUrl);
			PostMessage(GetDlgItem(hwndDlg, IDC_MBBLOCK),BM_SETCHECK, (mbapi.bIsBlocked)?BST_CHECKED:BST_UNCHECKED, 0);
			wsprintf(szCodePage, "%d", mbapi.nCodePage);
			SetWindowText(GetDlgItem(hwndDlg, IDC_CODEPAGE), szCodePage);

			PostMessage(GetDlgItem(hwndDlg, IDC_VISITLASTURL),BM_SETCHECK, (mbapi.bVisitLastURL)?BST_CHECKED:BST_UNCHECKED, 0);

			return TRUE;
		}

		case WM_COMMAND:
		{
			switch (LOWORD(wParam)) {
			case IDC_NAVIGATE:
				if (HIWORD(wParam) == BN_CLICKED)
				{
					GetWindowText(GetDlgItem(hwndDlg, IDC_URL), szUrl, 4095);
					OnIpcMbOpen(szUrl);
				}
				break;

			case IDC_MBBLOCK:
				if (mbapi.bIsBlocked)
					mbapi.bIsBlocked=false;
				else
					mbapi.bIsBlocked=true;
				break;

			case IDC_VISITLASTURL:
				if (mbapi.bVisitLastURL)
					mbapi.bVisitLastURL=false;
				else
					mbapi.bVisitLastURL=true;
				break;

			case IDOK:
			case IDCANCEL:
				SendMessage(hwndDlg, WM_CLOSE, 0, 0);
				break;

			}

			return FALSE;
		}
		case WM_CLOSE :
			GetWindowText(GetDlgItem(hwndDlg, IDC_CODEPAGE), szCodePage, 7);
			mbapi.nCodePage=atoi(szCodePage);
			EndDialog(hwndDlg, 0);
			return FALSE;

		default:;
 	}
	return FALSE;
}
