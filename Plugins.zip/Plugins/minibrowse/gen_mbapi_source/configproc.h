#ifndef __CONFIGPROC_H__
#define __CONFIGPROC_H__

#include <windows.h>

BOOL CALLBACK ConfigProc(HWND hwndDlg,UINT uMsg,WPARAM wParam,LPARAM lParam);


#endif // __CONFIGPROC_H__