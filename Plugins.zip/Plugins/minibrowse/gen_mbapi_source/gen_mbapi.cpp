

#include <windows.h>
#include "resource.h"

#include "gen.h"
#include "wa_ipc.h"

#include "gen_mbapi.h"
#include "configproc.h"
#include "mbdialog.h"

// Global variables

winampGeneralPurposePlugin plugin = {
  GPPHDR_VER,
  (char *)cszDescription, // Plug-in description 
  &init,
  &config, 
  &quit,
  NULL,
  NULL
}; 

const FINDWINDOWCHAINSTRUCT aFindWindowChain[] = {
	{ NULL, "Media Library" },
	{ "BaseWindow_RootWnd", "Winamp Library" },
	{ "Winamp Gen", "Winamp Library" },
	{ (LPCTSTR)32770, NULL },
	{ (LPCTSTR)32770, NULL },
	{ "HTMLControl", "HTMLControl" },
	{ "Shell Embedding", NULL },
	{ "Shell DocObject View", NULL },
	{ "Internet Explorer_Server", NULL },
	{ NULL, NULL}
};
#define MLMODERNSKINSTART	0	// Modern skin starts the chain (NULL, Media Library)
#define MLCLASSICSKINSTART  2	// Classic skin starts the chain (Winamp Gen, Winamp Library)
#define MBDIALOGCHAINGOBACK	4	// the second #32770

const char *cszDescription = PLUGIN_DESC;
const char *cszPluginName = PLUGIN_NAME;

MBAPISTRUCT mbapi;

LPARAM IPC_IS_MBAPI_ABSENT = -1;	// Invalid value.. do not use -1 on your plugin if you are a developer

// Winamp General Plugin basic interface functions

int init()
{
	// Initialize global variables
	if (SendMessage(plugin.hwndParent,WM_WA_IPC,0,IPC_GETVERSION) < 0x5022)
	{
		// If Winamp version is under 5.22, this plugin will malfunction.
		MessageBox(plugin.hwndParent, "This plugin is not intended to use with Winamp under 5.21.\nIt will remove from the plugin list.", cszDescription, MB_OK | MB_ICONEXCLAMATION);
		mbapi.bIsEnabled=false;
		return 1;
	}
	else if (!DoesNowPlayingExist())
	{
		// If "Now Playing" plguin is not installed, this plugin does not work.
		MessageBox(plugin.hwndParent, "\"Now Playing\" feature is not installed. Please reinstall Winamp Full version or higher with the feature.", cszDescription, MB_OK | MB_ICONEXCLAMATION);
		mbapi.bIsEnabled=false;
		return 1;
	}
	else
		mbapi.bIsEnabled=true;
	
	mbapi.bIsBlocked=false;
	mbapi.lpWinampProc=NULL;
	mbapi.hwndMBDialog=NULL;
	mbapi.lpMBDialogProc=NULL;
	mbapi.hmenuMBPopup=NULL;
	mbapi.hwndIES=NULL;
	mbapi.spWebBrowser=NULL;
	mbapi.nCodePage=CP_ACP;	// default ansi codepage;

	InitializeCriticalSection(&(mbapi.csMutex));
	mbapi.mbStatus = MBS_NOTINITED;
	mbapi.bIsRequested = false;

	GetIniFilePath(plugin.hwndParent, mbapi.szIniPath, MAX_PATH);
	ZeroMemory(mbapi.szRequestedURL, 4096);

	ReadSetting();

	// Register IPC_IS_MBAPI_ABSENT (thanks to DrO and Benski)
	IPC_IS_MBAPI_ABSENT = SendMessage(plugin.hwndParent,WM_WA_IPC,(WPARAM)&cszPluginName,IPC_REGISTER_WINAMP_IPCMESSAGE);


	// Request visiting if the setting says to do so
	if (mbapi.bVisitLastURL)
		mbapi.bIsRequested=true;

	// Subclass winamp WinProc
	mbapi.lpWinampProc=(WNDPROC)SetWindowLong(plugin.hwndParent,GWL_WNDPROC,(LONG)WinampSubclassProc);

	if (!mbapi.lpWinampProc)	// Error on subclassing
	{
		MessageBox(plugin.hwndParent, "Winamp subclassing failed", cszDescription, MB_OK | MB_ICONEXCLAMATION);
		mbapi.bIsEnabled=false;
		return 1;
	}
	
	return 0;
}
void config()
{
	if (mbapi.bIsEnabled)
		DialogBox(plugin.hDllInstance, MAKEINTRESOURCE(IDD_CONFIG), plugin.hwndParent, ConfigProc);
	else
		MessageBox(plugin.hwndParent, "This plugin is disabled because an error occurred while the plugin initializes, or this Winamp version is under 5.22.", cszDescription, MB_OK);
}
void quit()
{
	LONG lRes=NULL;
	if (mbapi.bIsEnabled)
		WriteSetting();

	if (mbapi.hmenuMBPopup)
		DestroyMenu(mbapi.hmenuMBPopup);

	lRes=GetWindowLong(plugin.hwndParent,GWL_WNDPROC);
	if (lRes == (LONG)WinampSubclassProc) {
		SetWindowLong(plugin.hwndParent,GWL_WNDPROC,(LONG)mbapi.lpWinampProc);	// Thanks for DrO
		mbapi.lpWinampProc = NULL;
	}
}

winampGeneralPurposePlugin * winampGetGeneralPurposePlugin() {
  return &plugin; 
}

// Subclass procedures

LRESULT CALLBACK WinampSubclassProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	if (!mbapi.bIsEnabled)
		return CallWindowProc(mbapi.lpWinampProc,hwnd,message,wParam,lParam);

	switch (message) {
		case WM_WA_IPC:
			if (
				((IPC_MBOPEN <= lParam) && (lParam <= IPC_MBOPENREAL))	||	// IPC_MBOPEN - IPC_MBOPENREAL
				(lParam == IPC_MBCMD) ||	// IPC_MBCMD
				((IPC_MBURL <= lParam) && (lParam <= IPC_MBGETDEFURL))	// IPC_MBURL - IPC_MBGETDEFURL
				)
			{
				// Main Minibrowser IPC calls	
				return OnMbIpcCall(hwnd, message, wParam, lParam);
			}

			if (lParam == IPC_IS_MBAPI_ABSENT)
				return FALSE;	// mbapi exists! (thanks to DrO and Benski)

			switch(lParam)
			{
				case IPC_ISWNDVISIBLE :
					if (wParam == IPC_GETWND_MB)
					{
						if (mbapi.hwndIES)
							return IsWindowVisible(mbapi.hwndIES);
						else
							return FALSE;
					}
					break;
				
				case IPC_GETWND:
					if (wParam == IPC_GETWND_MB)
						return (LRESULT)mbapi.hwndIES;	// Well, this is the best bit I can guess..

					break;
				
				default:;	// This is not a mbapi-related IPC call.
			}
			break;

		case WM_TIMER:
			OnWmTimer(hwnd, message, wParam, lParam);
			// WM_TIMER is not the message for this plugin;
			// it just uses this message and let Winamp proceeds this message.
			break;

		case WM_COMMAND:
			if ( (LOWORD(wParam) == WINAMP_OPTIONS_MINIBROWSER) ||
				(MB_FWD <= LOWORD(wParam)) && (LOWORD(wParam) <= MB_OPENLOC) ||
				(LOWORD(wParam) == MB_UPDATE)
				)
				return OnWmCommand(hwnd, wParam, lParam);
			break;


		default:;	// All other messages : pass to Winamp
	}
	return CallWindowProc(mbapi.lpWinampProc,hwnd,message,wParam,lParam);
}

LRESULT OnMbIpcCall(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	LRESULT lRes=0;
	DoCheckIES();

	switch(lParam)	// lParam : IPC id code
	{
		case IPC_MBOPEN :
		case IPC_MBURL :	// sets the URL - sounds the same as IPC_MBOPEN
			lRes= OnIpcMbOpen((const char *) wParam);
			break;
			
		case IPC_GETMBURL :
		case IPC_MBGETCURURL :	// copies the current URL - sounds the same as IPC_GETMBURL
			lRes= OnIpcGetMbUrl((char *) wParam);
			break;
			
		case IPC_MBBLOCK :
			lRes= OnIpcMbBlock((BOOL) wParam);
			break;

		case IPC_MBOPENREAL :
			lRes= OnIpcMbOpenReal((const char *) wParam);
			break;
		case IPC_MBCMD :
			lRes= OnIpcMbCmd((const windowCommand *)wParam);
			break;
		case IPC_MBGETDESC :
			// no .lks support on this version
			break;
		case IPC_MBCHECKLOCFILE :
			// no idea what this does
			break;
		case IPC_MBREFRESH :
			lRes = OnIpcMbRefresh();
			break;
		case IPC_MBGETDEFURL :
			// no .lks support on this version
			break;

		default:;	// Unknown minibrowser IPC calls or some non-minibrowser calls or some NOT IMPLEMENTED YET calls.. ;)
	}	// switch(lParam)

	if (!lRes)	// if lRes is NULL, that means this message did not proceed. Let Winamp do the job.
		return CallWindowProc(mbapi.lpWinampProc,hwnd,message,wParam,lParam);
	else
		return 0;	// Normal WM_WA_IPC behavior : 0 for proceed
}

void OnWmTimer(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	DoCheckIES();

	// is there anything requested but not proceeded yet?
	if (!mbapi.bIsRequested)
		return;	// No, move along.
	
	// Yes, there is something.
	EnterCriticalSection(&(mbapi.csMutex));
	
	// double-check if it is really requested
	if (!mbapi.bIsRequested)
	{
		// false alarm
		LeaveCriticalSection(&(mbapi.csMutex));
		return;
	}

	switch (mbapi.mbStatus) {
		case MBS_NOTINITED:
			// Open the minibrowser and wait
			SendMessage(plugin.hwndParent, WM_COMMAND, ID_MENU_NOWPLAYING, 0);
			mbapi.mbStatus= MBS_OPENING;
			break;

		case MBS_READY:
			// the minibrower is already opened and ready to work
			PostMessage(plugin.hwndParent, WM_WA_IPC, (WPARAM)(mbapi.szRequestedURL), IPC_MBOPEN);

			// Finished requested job
			mbapi.bIsRequested=false;
			break;

		default:;	// Wait until the minibrowser is up
	}
	LeaveCriticalSection(&(mbapi.csMutex));
}

LRESULT OnWmCommand(HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	LRESULT lRes = 0;

	DoCheckIES();

	if (mbapi.mbStatus != MBS_READY)
		return 0;	// ignore if minibrowser is not ready

	switch(LOWORD(wParam))
	{
		case WINAMP_OPTIONS_MINIBROWSER:
			config();
			lRes=1;
			break;

		case MB_FWD:
			if (mbapi.spWebBrowser->GoForward() == S_OK) lRes=1;
			break;
		case MB_BACK:
			if (mbapi.spWebBrowser->GoBack() == S_OK) lRes=1;
			break;
		case MB_RELOAD:
			if (mbapi.spWebBrowser->Refresh() == S_OK) lRes=1;
			break;

		case MB_OPENMENU:
			SendMessage(mbapi.hwndMBDialog, WM_CONTEXTMENU, NULL, NULL);
			lRes=1;
			break;

		case MB_OPENLOC:
			SendMessage(mbapi.hwndMBDialog, WM_COMMAND, MB_OPENLOC, NULL);
			lRes=0;
			break;

		case MB_UPDATE:
			lRes=0;	// .lks not supported (and it won't be supported because the .lks download feature of Winamp site is gone)
			break;

		default:;
	}

	if (!lRes)	// if lRes is NULL, that means this message did not proceed. Let Winamp do the job.
		return CallWindowProc(mbapi.lpWinampProc,hwnd, WM_COMMAND, wParam, lParam);
	else
		return 0;	// Normal WM_COMMAND behavior : 0 for proceed

}

// Utility functions

HWND FindWindowChain(HWND hwndParent, int nChainNo)
{
	HWND hwndChild = NULL;

	if ( !aFindWindowChain[nChainNo].lpszClass && !aFindWindowChain[nChainNo].lpszWindow)
		return hwndParent;	// End of chain

	if (nChainNo == 0)	// Start chain
		hwndChild = FindWindow(aFindWindowChain[nChainNo].lpszClass, aFindWindowChain[nChainNo].lpszWindow);
	else	// Find next chain
		hwndChild = FindWindowEx(hwndParent, NULL, aFindWindowChain[nChainNo].lpszClass, aFindWindowChain[nChainNo].lpszWindow);

	if (!hwndChild)	// There is no chain. Cancel finding.
		return NULL;

	return FindWindowChain(hwndChild, nChainNo + 1);	// Move ahead
}

// This function is from MS article 249232, "How To Get IHTMLDocument2 from a HWND"
CComPtr<IHTMLDocument2> GetIHTMLDocument2(HWND hwndIES)
{
	CComPtr<IHTMLDocument2> spDoc = NULL;

	// Explicitly load MSAA so we know if it's installed
	HINSTANCE hInstOleAcc = LoadLibrary( _T("OLEACC.DLL") );
	LPFNOBJECTFROMLRESULT pfObjectFromLresult;

	if ( hInstOleAcc != NULL )
	{
		if ( hwndIES != NULL )
		{
			LRESULT lRes;
		
			UINT nMsg = RegisterWindowMessage( _T("WM_HTML_GETOBJECT") );

			SendMessageTimeout( hwndIES, nMsg, 0L, 0L, SMTO_ABORTIFHUNG, 1000, (DWORD*)&lRes );

			pfObjectFromLresult = (LPFNOBJECTFROMLRESULT) GetProcAddress( hInstOleAcc, _T("ObjectFromLresult") );
			if ( pfObjectFromLresult != NULL )
			{
				HRESULT hr;
				hr = (*(pfObjectFromLresult))( lRes, IID_IHTMLDocument2, 0, (void**)&spDoc );

				if (SUCCEEDED(hr))
				{
					CComPtr<IDispatch> spDisp;
					CComQIPtr<IHTMLWindow2> spWin;

					spDoc->get_Script( &spDisp );
					spWin = spDisp;
					spWin->get_document( &spDoc.p );
				}
				else
				{
					spDoc = NULL;
					MessageBox(plugin.hwndParent, "Warning : ObjectFromLresult failed", cszDescription, MB_OK | MB_ICONEXCLAMATION);
				}

				
			}
		} // else IE is not running
	} 
	else 
	{	// Active Accessibility is not installed
		mbapi.bIsEnabled=false;
		MessageBox(plugin.hwndParent, "Active Accessibility is not installed", cszDescription, MB_OK | MB_ICONEXCLAMATION);
	}

	FreeLibrary(hInstOleAcc);
	return spDoc;
}

// This small function is from Paul DiLascia's "C++ Q&A", June 2001 issue of MSDN Magazine.
CComPtr<IWebBrowser2> GetIWebBrowser2(CComPtr<IHTMLDocument2> pDoc)
{
	CComQIPtr<IServiceProvider> isp = pDoc;
	CComQIPtr<IWebBrowser2> iwb2;

	isp->QueryService(IID_IWebBrowserApp, IID_IWebBrowser2, (void**)&iwb2);

	return iwb2;
}

void DoCheckIES()
{
	if ( !mbapi.hwndIES || !IsWindow(mbapi.hwndIES))	// hwndIES has not been found
	{
		HWND hwndIES = NULL;

		hwndIES=FindWindowChain(NULL, MLMODERNSKINSTART);	// Assume Winamp in modern skin

		if (!hwndIES)
			hwndIES=FindWindowChain(NULL, MLCLASSICSKINSTART);	// Try Winamp in classic skin

		if (hwndIES)
		{
			mbapi.hwndIES=hwndIES;
			CComPtr<IHTMLDocument2> spDoc;
			spDoc=GetIHTMLDocument2(mbapi.hwndIES);

			if (spDoc)	// Got it!
			{
				HWND hwnd = mbapi.hwndIES;
				mbapi.spWebBrowser=GetIWebBrowser2(spDoc);

				// Find the HWND of dialog which contains IE and control buttons
				for(int i=0; i<MBDIALOGCHAINGOBACK; i++)
					hwnd=GetParent(hwnd);
				mbapi.hwndMBDialog = hwnd;
				PrepareMBDialogSubclassing(mbapi.hwndMBDialog);
				mbapi.mbStatus=MBS_READY;
			}
		}
		else if (mbapi.mbStatus == MBS_READY)
			mbapi.mbStatus = MBS_NOTINITED;
	}
}

LRESULT OnIpcMbOpen(const char *szUrl)
{
	if (!mbapi.bIsBlocked)
		return OnIpcMbOpenReal(szUrl);
	
	return 0;
}
LRESULT OnIpcGetMbUrl(char *szBuffer)
{
	LRESULT lRes=NULL;

	if (mbapi.mbStatus == MBS_READY)
	{
		CComBSTR bstrUrl;

		mbapi.spWebBrowser->get_LocationURL( &bstrUrl );

		if ( WideCharToMultiByte(mbapi.nCodePage, 0, (BSTR) bstrUrl, -1, szBuffer, 4095, NULL, NULL) )
			lRes=1;
		else
			MessageBox(plugin.hwndParent, "WideCharToMultiByte failed", cszDescription, MB_OK | MB_ICONEXCLAMATION);
	}

	return lRes;
}
LRESULT OnIpcMbBlock(BOOL value)
{
	mbapi.bIsBlocked = (value)?true:false;

	return 1;
}

LRESULT OnIpcMbOpenReal(const char *szUrl)
{
	LRESULT lRes=NULL;
	if (mbapi.mbStatus == MBS_READY)
	{
		if (szUrl)
		{

			lstrcpy(mbapi.szRequestedURL, szUrl);

			mbapi.spWebBrowser->Navigate(CComBSTR(szUrl), NULL, NULL, NULL, NULL);
		}
		else	// szUrl == NULL
			SendMessage(plugin.hwndParent, WM_COMMAND, ID_MENU_NOWPLAYING, 0);

		lRes=1;
	}
	else
	{
		EnterCriticalSection(&(mbapi.csMutex));
		
		if (mbapi.mbStatus == MBS_NOTINITED)
		{
			// Open the minibrowser and wait
			SendMessage(plugin.hwndParent, WM_COMMAND, ID_MENU_NOWPLAYING, 0);
			mbapi.mbStatus= MBS_OPENING;
		}

		if (szUrl)
		{
			lstrcpy(mbapi.szRequestedURL, szUrl);
			mbapi.bIsRequested=true;
		}

		LeaveCriticalSection(&(mbapi.csMutex));
	}
	return lRes;
}

LRESULT OnIpcMbCmd(const windowCommand *cmdMb)
{
	LRESULT lRes = 0;
	if (mbapi.mbStatus == MBS_READY)
	{

		switch(cmdMb->cmd)
		{
			case MBCMD_BACK:
				if (mbapi.spWebBrowser->GoBack() == S_OK) lRes=1;
				break;
			case MBCMD_FORWARD:
				if (mbapi.spWebBrowser->GoForward() == S_OK) lRes=1;
				break;
			case MBCMD_STOP:
				if (mbapi.spWebBrowser->Stop() == S_OK) lRes=1;
				break;
			case MBCMD_RELOAD:
				if (mbapi.spWebBrowser->Refresh() == S_OK) lRes=1;
				break;
			case MBCMD_MISC:
				// No idea what this does
				break;
		}
	}
	return lRes;
}

LRESULT OnIpcMbRefresh()
{
	LRESULT lRes;

	if (mbapi.mbStatus == MBS_READY)
	{
		if (mbapi.spWebBrowser->Refresh() == S_OK) lRes=1;
	}
	return lRes;
}

bool DoesNowPlayingExist()
{
	HANDLE hFindFile;
	char szFileName[MAX_PATH];
	WIN32_FIND_DATA findData;

	// Check ml_nowplaying.dll in Plugins directory
	GetCurrentDirectory(MAX_PATH, szFileName);
	lstrcat(szFileName, "\\Plugins\\ml_nowplaying.dll");

	hFindFile=FindFirstFile(szFileName,&findData);

	if (hFindFile == INVALID_HANDLE_VALUE)
		return false;
	
	FindClose(hFindFile);
	return true;
}

void ReadSetting()
{
	int nResult;
	
	// bIsBlocked
	nResult=GetPrivateProfileInt(cszPluginName, "IsBlocked", 0, mbapi.szIniPath);
	mbapi.bIsBlocked=(nResult)?true:false;

	// nCodePage
	nResult=GetPrivateProfileInt(cszPluginName, "CodePage", CP_ACP, mbapi.szIniPath);
	mbapi.nCodePage=nResult;

	// bVisitLastURL
	nResult=GetPrivateProfileInt(cszPluginName, "VisitLastURL", 0, mbapi.szIniPath);
	mbapi.bVisitLastURL=(nResult)?true:false;

	// RequestedURL
	GetPrivateProfileString(cszPluginName, "RequestedURL", "", mbapi.szRequestedURL, 4096, mbapi.szIniPath);

}

void WriteSetting()
{
	char szTemp[8];

	// bIsBlocked
	WritePrivateProfileString(cszPluginName, "IsBlocked", (mbapi.bIsBlocked)?"1":"0", mbapi.szIniPath);

	// nCodePage
	wsprintf(szTemp,"%d", mbapi.nCodePage);
	WritePrivateProfileString(cszPluginName, "CodePage", szTemp, mbapi.szIniPath);

	// bVisitLastURL
	WritePrivateProfileString(cszPluginName, "VisitLastURL", (mbapi.bVisitLastURL)?"1":"0", mbapi.szIniPath);

	// RequestedURL
	WritePrivateProfileString(cszPluginName, "RequestedURL", mbapi.szRequestedURL, mbapi.szIniPath);
}

inline void GetIniFilePath(HWND hwndWinamp, char *szBuffer, int nSize)
{
	// multi-user compatible version, thanks to DrO.
	// This plugin is disabled under Winamp 5.22, so IPC_GETINIFILE is already defined..
	lstrcpyn(szBuffer, (char*)SendMessage(hwndWinamp,WM_WA_IPC,0,IPC_GETINIFILE),nSize);
}