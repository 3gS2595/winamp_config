#ifndef __GEN_MBAPI_H__
#define __GEN_MBAPI_H__

#include <mshtml.h>
#include <exdisp.h>	// IWebBrowser2
#include <atlbase.h>
#include <oleacc.h>

// Program description
#define PLUGIN_DESC "Minibrowser API Support 0.7 for Winamp 5.22+";
#define PLUGIN_NAME "gen_mbapi";

extern const char *cszDescription;
extern const char *cszPluginName;

// Winamp General Plugin basic interface functions
int init();
void config();
void quit();

extern "C" 
{

__declspec(dllexport) winampGeneralPurposePlugin * winampGetGeneralPurposePlugin();

}

// defines of winamp (usually found from Spy++)
	// MENU IDs
#define ID_MENU_NOWPLAYING	53001	// I have no idea why ID_MLVIEW_NOWPLAYING is not 53001.. it is not even in wa_msgids.h

// Global variables / typedefs
typedef struct _FINDWINDOWCHAINSTRUCT {
	LPCTSTR lpszClass;
	LPCTSTR lpszWindow;
} FINDWINDOWCHAINSTRUCT;

typedef enum _MBSTATUS {
	MBS_READY = 0,	// MB is ready to work
	MBS_NOTINITED,	// MB is not inited or unknown
	MBS_OPENING		// MB is requested to open
} MBSTATUS;

typedef struct _MBAPISTRUCT {
	bool bIsEnabled;	// true if the plugin is enabled
	bool bIsBlocked;	// true if IPC_MBBLOCK is TRUE

	WNDPROC lpWinampProc;	// Original winamp WinProc for subclassing
	
	HWND hwndMBDialog;	// HWND for the dialog containing IES and naviagtion buttons
	WNDPROC lpMBDialogProc;
	HMENU hmenuMBPopup;
	HWND hwndIES;	// HWND for Internet Explorer_Server
	CComPtr<IWebBrowser2> spWebBrowser;	// Web browser controller for Internet Explorer_Server

	UINT nCodePage;

	CRITICAL_SECTION csMutex;	// a critical-section to prevent some race-conditions..
	MBSTATUS mbStatus;
	bool bIsRequested;

	bool bVisitLastURL;

	char szIniPath[MAX_PATH];
	char szRequestedURL[4096];	// Requested URL
} MBAPISTRUCT;

extern MBAPISTRUCT mbapi;
extern winampGeneralPurposePlugin plugin;

extern LPARAM IPC_IS_MBAPI_ABSENT;

// Subclass procedures

LRESULT CALLBACK WinampSubclassProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

LRESULT OnMbIpcCall(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
void OnWmTimer(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT OnWmCommand(HWND hwnd, WPARAM wParam, LPARAM lParam);

// Utility functions

HWND FindWindowChain(HWND hwndParent = NULL, int nChainNo = 0);
CComPtr<IHTMLDocument2> GetIHTMLDocument2(HWND hwndIES);
CComPtr<IWebBrowser2> GetIWebBrowser2(CComPtr<IHTMLDocument2> pDoc);

void DoCheckIES();

LRESULT OnIpcMbOpen(const char *szUrl);
LRESULT OnIpcGetMbUrl(char *szBuffer);
LRESULT OnIpcMbBlock(BOOL value);
LRESULT OnIpcMbOpenReal(const char *szUrl);
LRESULT OnIpcMbCmd(const windowCommand *cmdMb);
LRESULT OnIpcMbRefresh();

bool DoesNowPlayingExist();

void ReadSetting();
void WriteSetting();

void GetIniFilePath(HWND hwndWinamp, char *szBuffer, int nSize);

#endif // __GEN_MBAPI_H__
