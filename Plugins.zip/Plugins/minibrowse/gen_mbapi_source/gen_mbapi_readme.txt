Minibrowser API Support for Winamp 5.22+
developed by whoami (mail.whoami@gmail.com)

Current version: 0.7 (see changelog.txt for details)

Usage:
Just install this plugin and any other plugin for minibrowser. The plugin for minibrowser should work fine.

Source:
The source for this plugin will be extracted on winamp/plugin/gen_mbapi_source. If you do not need source, just delete the folder.

License:
This program is in public domain; you may distribute, modify, or (put your own action).
However, opening modified source is encouraged in the name of humanity.

This program is distributed as-is; the developer has no responsibility against
any side-effects using this program. Use it in your own risk.
