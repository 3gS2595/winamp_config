#include <windows.h>

#include "resource.h"

#include "gen.h"
#include "wa_ipc.h"

#include "gen_mbapi.h"

#include "mbdialog.h"

bool PrepareMBDialogSubclassing(HWND hwndMBDialog)
{
	WNDPROC lpMBDialogProc=NULL;
	if (!mbapi.hmenuMBPopup)
	{
		BOOL bRes;
		
		MENUITEMINFO infoMenuItem;


		// TODO : Reading and analyzing .lks file should be here

		// Create right-click context menu
		mbapi.hmenuMBPopup = CreatePopupMenu();
		
		ZeroMemory(&infoMenuItem, sizeof(MENUITEMINFO));
		infoMenuItem.cbSize=sizeof(MENUITEMINFO);
		infoMenuItem.fMask= MIIM_TYPE | MIIM_ID;

		infoMenuItem.fType= MFT_STRING;
		infoMenuItem.dwTypeData= "Open URL...";
		infoMenuItem.wID = MB_OPENLOC;

		bRes=InsertMenuItem(mbapi.hmenuMBPopup, 0, TRUE, &infoMenuItem);
		if (!bRes)
		{
			DestroyMenu(mbapi.hmenuMBPopup);
			mbapi.hmenuMBPopup=NULL;
			return false;
		}

		infoMenuItem.fMask = MIIM_TYPE;
		infoMenuItem.fType = MFT_SEPARATOR;
		InsertMenuItem(mbapi.hmenuMBPopup, 1, TRUE, &infoMenuItem);

		// TODO : Adding URLs should be here
	}

	lpMBDialogProc= (WNDPROC)GetWindowLong(hwndMBDialog, GWL_WNDPROC);
	// Subclass minibrowser WinProc
	if ( lpMBDialogProc != mbapi.lpMBDialogProc)
	{
		if (lpMBDialogProc)
		{
			mbapi.lpMBDialogProc=(WNDPROC)SetWindowLong(hwndMBDialog,GWL_WNDPROC,(LONG)MBDialogSubclassProc);
			PostMessage(plugin.hwndParent, WM_WA_IPC, IPC_CB_WND_MB, IPC_CB_ONSHOWWND);
		}
	}

	if (!mbapi.lpMBDialogProc)	// Error on subclassing
	{
		DestroyMenu(mbapi.hmenuMBPopup);
		mbapi.hmenuMBPopup=NULL;
		return false;
	}
	return true;
}

LRESULT CALLBACK MBDialogSubclassProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{

	switch(message)
	{

		case WM_CONTEXTMENU:
			TrackPopupMenu(mbapi.hmenuMBPopup, TPM_LEFTALIGN | TPM_TOPALIGN, LOWORD(lParam), HIWORD(lParam), NULL, hwnd, NULL);
			return 0;

		case WM_COMMAND:
			{
				if (LOWORD(wParam) < MB_OPENLOC)
					break;

				if (LOWORD(wParam) == MB_OPENLOC)
				{
					// Open input box
					char *pszUrl;
					pszUrl=(char *)DialogBox(plugin.hDllInstance, MAKEINTRESOURCE(IDD_INPUTURLBOX), plugin.hwndParent, InputBoxProc);

					if (pszUrl)
						OnIpcMbOpen(pszUrl);

					return 0;
				}
				// TODO : .lks URL menu command should be proceeded here

			}
			break;

		case WM_DESTROY:
			{
				WNDPROC lpMBDialogProc = mbapi.lpMBDialogProc;

				PostMessage(plugin.hwndParent, WM_WA_IPC, IPC_CB_WND_MB, IPC_CB_ONHIDEWND);

				SetWindowLong(hwnd,GWL_WNDPROC,(LONG)mbapi.lpMBDialogProc);
				mbapi.lpMBDialogProc=NULL;
				mbapi.mbStatus=MBS_NOTINITED;
				mbapi.hwndIES=NULL;
				

				return CallWindowProc(lpMBDialogProc, hwnd, message, wParam, lParam);
			}
			break;

		default:;
	}

	return CallWindowProc(mbapi.lpMBDialogProc, hwnd, message, wParam, lParam);
}

BOOL CALLBACK InputBoxProc(HWND hwndDlg,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	static char szUrl[4096];

	switch(uMsg)
	{
		case WM_INITDIALOG:
			OnIpcGetMbUrl(szUrl);
			SetWindowText(GetDlgItem(hwndDlg, IDC_URL), szUrl);

			return TRUE;

		case WM_COMMAND:
			if (LOWORD(wParam) == IDOK)
			{
				GetWindowText(GetDlgItem(hwndDlg, IDC_URL), szUrl, 4095);
				EndDialog(hwndDlg, (int) szUrl);
			}
			else if (LOWORD(wParam) == IDCANCEL)
				EndDialog(hwndDlg, NULL);
				
			break;

		default:;
	}
	return FALSE;
}