#ifndef __MBDIALOG_H__
#define __MBDIALOG_H__

	// Button IDs (for the dialog..)
#define ID_BUTTON_BACK	1001
#define ID_BUTTON_STOP	1002
#define ID_BUTTON_REFRESH	1003
#define ID_BUTTON_HOME	1004
#define ID_BUTTON_FORWARD	1005

bool PrepareMBDialogSubclassing(HWND hwndMBDialog);

LRESULT CALLBACK MBDialogSubclassProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

BOOL CALLBACK InputBoxProc(HWND hwndDlg,UINT uMsg,WPARAM wParam,LPARAM lParam);

#endif // __MBDIALOG_H__