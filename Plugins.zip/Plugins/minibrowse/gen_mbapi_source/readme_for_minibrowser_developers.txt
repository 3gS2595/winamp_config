* How to know if Minibrowser API Support is installed :
1) Check if Winamp version is 5.22+
2) Register "gen_mbapi" (plguin name) as IPC_IS_MBAPI_ABSENT (or any name you want)
3) SendMessage(winampWindow,WM_WA_IPC,0,IPC_IS_MBAPI_ABSENT) and check if the return value is 0 (or, FALSE, if you prefer)

[code]
    LPARAM IPC_IS_MBAPI_ABSENT;

    if (SendMessage(plugin.hwndParent,WM_WA_IPC,0,IPC_GETVERSION) >= 0x5022)
    {
        IPC_IS_MBAPI_ABSENT=SendMessage(plugin.hwndParent,WM_WA_IPC,(WPARAM)&"gen_mbapi",IPC_REGISTER_WINAMP_IPCMESSAGE);
        if( SendMessage(winampWindow,WM_WA_IPC,0,IPC_IS_MBAPI_ABSENT) )
        {
            // Minibrowser API Support is NOT installed
            MessageBox(plugin.hwndParent, "Error : Minibrowser API is not supported", "Error", MB_OK | MB_ICONEXCLAMATION);
            return -1;
        }
    }
    // Minibrowser API is supported (either Winamp supports natively or Minibrowser API support plugin is installed) 
[/code]

    * CAUTION : Minibrowser API registers IPC_IS_MBAPI_ABSENT while it init()s. 
                You should NOT call SendMessage(..., IPC_IS_MBAPI_ABSENT) in init().

* Current Minibrowser API Support status :
  a) WM_WA_IPC
	IPC_MBOPEN
	IPC_GETMBURL
	IPC_MBBLOCK
	IPC_MBOPENREAL
	IPC_MBURL	(works the same as IPC_MBOPEN)
	IPC_MBGETCURURL	(works the same as IPC_GETMBURL)
	IPC_MBCMD	(without MBCMD_MISC)
	IPC_MBREFRESH
	IPC_GETWND (with IPC_GETWND_MB, returns the hwnd of Internet Explorer_Server)
	IPC_ISWNDVISIBLE (with IPC_GETWND_MB)
	IPC_CB_ONSHOWWND (with IPC_CB_WND_MB)
	IPC_CB_ONHIDEWND (with IPC_CB_WND_MB)
  b) WM_COMMAND
	WINAMP_OPTIONS_MINIBROWSER (shows config dialog of this plugin)
	MB_FWD
	MB_BACK
	MB_RELOAD
	MB_OPENMENU
	MB_OPENLOC

* Current Minibrowser API NOT Support status :
  a) WM_WA_IPC
	IPC_MBGETDESC	(no .lks support)
	IPC_MBCHECKLOCFILE	(no idea what this does)
	IPC_MBGETDEFURL	(no .lks support)
	IPC_MBCMD with MBCMD_MISC	(no idea what this does)
  b) WM_COMMAND
	MB_UPDATE	(no .lks support (and it won't be supported because the .lks download feature
                         of Winamp site is gone)
