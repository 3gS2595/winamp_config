- ANNO GOTICO 79 -

Created by A.Fangueiro - XIX.

Time to build - 1 month.
Finished at 13th June 2002.

A Big Hail to all Winamp, Plugin and Skin Designers,


So here is my third skin, the successor of BLUE TROLL. 
The meaning of ANNO GOTICO 79 is a simple visual example, among so many,
of the Gothic feeling, the search for Balance.
By coincidence in time, it celebrates also the coming into my life of the one that 
Balances me, the 7 that meets 9.
Once again, I dedicate it to all dreamers, specially my Jolanta.



Antonio Fangueiro 
e-mail: leifur@clix.pt
           
adress: R. Alecrim 77  Caxinas
             4480-787 - Vila do Conde
             Portugal	


P.S. all critics are welcome.