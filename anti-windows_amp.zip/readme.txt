You have downloaded this WinAMP skin from "Timmy B's WinAMP Skins page".

webpage:  http://www.crosswinds.net/~timmybskins

email:  timmybskins@crosswinds.net

primary email:  timb1@hotmail.com

Forward all questions/queries, suggestions and submissions to one of the above email addresses.
All mail will be read and replied to.  Send only urgent messages to timb1@hotmail.com.

CREATED BY:

Name:  Timmy B
Email:  timmybskins@crosswinds.net
Webpage:  http://www.crosswinds.net/~timmybskins